$ErrorActionPreference='Stop'
$csc=Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe'
foreach($suite in @('CoreTests','ProgressionTests','RegressionTests')) {
 & $csc /nologo /target:exe "/out:$PSScriptRoot\bin\$suite.exe" "/reference:$PSScriptRoot\bin\AstraCoop.Core.dll" "$PSScriptRoot\tests\$suite.cs"
 if($LASTEXITCODE -ne 0){throw "$suite compilation failed"}
 & "$PSScriptRoot\bin\$suite.exe"
 if($LASTEXITCODE -ne 0){throw "$suite failed"}
}
