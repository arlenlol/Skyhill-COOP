"""Python 3, standard library only. One controller owns one authenticated actor."""
import argparse
import json
import pathlib
import socket
import struct
import time
import threading


class Controller:
    def __init__(self, host, port, name, password, role="player", token=None):
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self.connection_error = None
        self.socket = socket.create_connection((host, port), timeout=10)
        self.sequence = 1
        self.welcome = self.request({"Op": "join", "Version": 2, "Name": name,
                                     "Role": role, "Password": password, "Token": token})
        if not self.welcome["Ok"]:
            self.socket.close()
            raise RuntimeError(self.welcome["Code"])
        self.token = self.welcome.get("Token") or token
        self.actor_id = self.welcome.get("ActorId")
        self.sequence = self.welcome["NextSequence"]
        self._heartbeat = threading.Thread(target=self._keepalive, daemon=True)
        self._heartbeat.start()

    def _read_exact(self, n):
        result = bytearray()
        while len(result) < n:
            data = self.socket.recv(n - len(result))
            if not data:
                raise ConnectionError("Host disconnected")
            result.extend(data)
        return bytes(result)

    def request(self, command):
        with self._lock:
            if self.connection_error is not None:
                raise ConnectionError("Connection lost; reconnect with saved token") from self.connection_error
            return self._request(command)

    def _request(self, command):
        raw = json.dumps(command, ensure_ascii=False, allow_nan=False).encode("utf-8")
        if len(raw) > 8192:
            raise ValueError("Request exceeds 8192 bytes")
        self.socket.sendall(struct.pack("!I", len(raw)) + raw)
        size, = struct.unpack("!I", self._read_exact(4))
        if not 0 < size <= 8 * 1024 * 1024:
            raise ValueError("Invalid response size")
        return json.loads(self._read_exact(size).decode("utf-8"))

    def state(self):
        with self._lock:
            response = self.request({"Op": "state"})
            if not response["Ok"]:
                raise RuntimeError(response["Code"])
            self.sequence = response["NextSequence"]
            return response["State"]

    def action(self, op, target=None, zone=0, text=None):
        with self._lock:
            response = self.request({"Op": op, "Target": target, "Zone": zone,
                                     "Text": text, "Sequence": self.sequence})
            self.sequence = response.get("NextSequence") or self.sequence
            return response

    def _keepalive(self):
        while not self._stop.wait(5):
            try:
                # No automatic replay of mutations after an uncertain response.
                self.state()
            except (OSError, ValueError, RuntimeError) as error:
                self.connection_error = error
                return

    def close(self):
        self._stop.set()
        try:
            self.socket.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        self.socket.close()
        if hasattr(self, "_heartbeat"):
            self._heartbeat.join(timeout=1)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=28766)
    p.add_argument("--name", default="Python Player")
    p.add_argument("--settings", type=pathlib.Path, required=True,
                   help="Host UserData/AstraCoop/settings.json (contains local API key)")
    p.add_argument("--token-file", type=pathlib.Path, required=True)
    p.add_argument("--spectator", action="store_true")
    args = p.parse_args()
    config = json.loads(args.settings.read_text(encoding="utf-8-sig"))
    token = args.token_file.read_text().strip() if args.token_file.exists() else None
    c = Controller(args.host, args.port, args.name, config["ApiKey"],
                   "spectator" if args.spectator else "player", token)
    args.token_file.write_text(c.token, encoding="utf-8")
    try:
        print("Actor:", c.actor_id)
        print(c.action("chat", text="Привет из Python!"))
        print("Commands: state, move ID, attack ID ZONE, use ID, equip ID, craft ID,")
        print("interact ID, pickup ID, drop ID, chat TEXT, quit. Zones are zero-based.")
        # A heartbeat preserves idle connections. The lock serializes complete
        # request/response exchanges, including sequence updates.
        while True:
            line = input("> ").strip()
            if line == "quit":
                break
            parts = line.split(maxsplit=2)
            if not parts:
                continue
            if parts[0] == "state":
                print(json.dumps(c.state(), ensure_ascii=False, indent=2))
            elif parts[0] == "chat":
                print(c.action("chat", text=line[5:]))
            else:
                print(c.action(parts[0], parts[1] if len(parts) > 1 else None,
                               int(parts[2]) if len(parts) > 2 else 0))
    finally:
        c.close()


if __name__ == "__main__":
    main()
