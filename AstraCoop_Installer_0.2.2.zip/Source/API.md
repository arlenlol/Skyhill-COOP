# API, протокол 2

API отключён по умолчанию. Для включения задайте EnableApi=true до создания сессии. Локальный адрес — 127.0.0.1:28766; ключ ApiKey хранится у хоста в UserData/AstraCoop/settings.json. Человеческие клиенты используют LAN-порт 28765 и пароль сессии.

Кадр: длина UTF-8 JSON четырьмя байтами big-endian, затем JSON. Запрос до 8192 байт, ответ до 8 MiB. Одно последовательное соединение на контроллер. Периодически запрашивайте state; таймаут чтения сервера 15 секунд.

```json
{"Version":2,"Op":"join","Name":"Controller","Role":"player","Password":"API_KEY"}
```

Role — player или spectator. Сохраните Token для восстановления сессии. При повторном join передайте Token и тот же пароль/ключ. ActorId назначается сервером; участник управляет только собственным персонажем.

Каждая изменяющая команда использует Sequence=NextSequence из последнего ответа. Повтор последней команды с тем же номером возвращает прежний результат. state не расходует Sequence. Отказ по условиям игрового действия расходует номер, но не ресурсы.

| Op | Поля |
| --- | --- |
| state | Без Sequence; возвращает State |
| move | Target — соседняя комната из Rooms[текущая].Neighbours |
| attack | Target — враг; Zone — индекс зоны от нуля |
| interact | Target — контейнер или объект; для автомата Text="pay" |
| trade | Target — объект Kind=trade; предложение берётся с сервера |
| quest | Target — объект Kind=quest; у последнего компьютера Text — введённый пароль |
| repair | Target — объект Kind=repair; Zone=0 для детали, Zone=1 для ручной попытки |
| lift | Target — комната с работающим лифтом |
| boss | Target — left / center / right |
| perk | Использовать выбранный активный перк своего персонажа |
| pickup | Target — ID из Drops |
| equip, use, drop, recycle | Target — идентификатор предмета |
| slot | Target — оружие; Zone=0 / 1 |
| craft | Target — ID рецепта из Recipes |
| upgrade | Target — strength / dexterity / speed / accuracy |
| sleep | Zone — от 1 до 10 часов; только Home |
| chat | Text — до 512 символов |

Reply содержит Ok, Code и NextSequence. У атаки есть Hit/Damage, у таймера RetryAfter. Все игровые проверки выполняет хост. Объекты в других комнатах, мёртвые персонажи и наблюдатели не могут обойти эти проверки.

State включает Actors, Rooms, Enemies, Containers, Interactives, Items, Inventory, Recipes, HomeProgress, Journal, Recordings, Quests, Drops, Events, Chat, CurrentEnding, CompletedEnding, SecretUnlocked и BossDefeated. В открытом состоянии скрыты непосещённые враги, закрытая добыча и таблицы случайных наград. ServerTime, MovingUntil, NextAttack и NextMove используют монотонное время хоста.

Номера объектов и названия предметов берите из State. Статические объекты могут иметь ID scene:..., динамические квестовые враги — quest_enemy:... . Не разбирайте формат ID на клиенте.

Пример контроллера на Python 3 без внешних зависимостей: Source/examples/client.py. Не публикуйте ключи и токены из UserData.
