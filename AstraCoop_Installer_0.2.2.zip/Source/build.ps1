param([string]$GamePath = 'C:\Program Files (x86)\Steam\steamapps\common\Skyhill')
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$csc = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe'
$bin = Join-Path $root 'bin'
New-Item -ItemType Directory -Force $bin | Out-Null
$core = @('Model.cs','Json.cs','Session.cs','Transport.cs','Persistence.cs','MouseRoute.cs','Progression.cs') | ForEach-Object { Join-Path $root "src\$_" }
$framework=Join-Path $GamePath 'Skyhill_Data\Managed'
$standard=@('/nostdlib+',"/reference:$framework\mscorlib.dll","/reference:$framework\System.dll","/reference:$env:WINDIR\Microsoft.NET\Framework\v2.0.50727\System.Xml.dll","/reference:$framework\System.Core.dll")
& $csc /noconfig /nologo /target:library /optimize+ /debug:pdbonly $standard "/out:$bin\AstraCoop.Core.dll" $core
if ($LASTEXITCODE -ne 0) { throw 'Core compilation failed' }
$managed = Join-Path $GamePath 'Skyhill_Data\Managed'
$loader = Join-Path $GamePath 'MelonLoader'
$refs = @("$bin\AstraCoop.Core.dll", "$managed\Assembly-CSharp.dll", "$managed\Assembly-CSharp-firstpass.dll", "$managed\UnityEngine.dll", "$loader\MelonLoader.dll", "$loader\0Harmony.dll")
$argsRefs = $refs | ForEach-Object { "/reference:$_" }
& $csc /noconfig /nologo /target:library /optimize+ /debug:pdbonly $standard "/out:$bin\AstraCoop.dll" $argsRefs "$root\src\NativeBridge.cs" "$root\src\Mod.cs" "$root\src\MultiplayerCharacter.cs" "$root\src\NativeInterface.cs" "$root\src\NativeProgression.cs" "$root\src\NativeLoot.cs" "$root\src\MultiplayerEnemy.cs"
if ($LASTEXITCODE -ne 0) { throw 'Mod compilation failed' }
Write-Output 'Compiled Core + MelonLoader mod successfully.'



