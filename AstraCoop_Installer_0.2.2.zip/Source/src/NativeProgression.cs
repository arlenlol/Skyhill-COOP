using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
namespace AstraCoop {
public sealed partial class NativeBridge {
 readonly Dictionary<string,string> projectedStates=new Dictionary<string,string>();
 long projectionRevision=-1;
 public static string SceneRoom(Transform obj){
  string side=null;for(Transform t=obj;t!=null;t=t.parent){if(t.name.StartsWith("room_"))side=t.name;if(t.name=="Home")return "Home";if(t.name.StartsWith("floor_"))return t.name+"/"+(side??"room_center");}return null;
 }
 void CaptureProgression(World w){
  w.CurrentEnding=CutscenesManager.getI.getCurrentCutscene();
  var secret=DbManager.instance.getDataFromTable("cutscenes","name","end_3");w.SecretUnlocked=secret!=null&&secret.getDataValue("is_unlocked").Contains("True");
  foreach(DbObject row in DbManager.instance.fetch("journal"))w.Journal[row.getDataValue("identity")]=1;
  foreach(DbObject row in DbManager.instance.fetch("dictaphone")){string id=row.getDataValue("name");w.RecordingCatalog.Add(id);if(row.getDataValue("isKnown")=="True")w.Recordings.Add(id);}
  for(int i=0;i<=4;i++)w.BedHealing[i.ToString()]=Number(RandomGenerationAssistant.getI.getRandomGenerationVar("hunger_to_hp_lvl_"+i));
  foreach(DbObject row in DbManager.instance.fetch("quests")){var q=new QuestState{Id="quest:"+row.index,Name=row.getDataValue("name"),State=row.getDataValue("state")};foreach(var pair in row.data)if(pair.Key.StartsWith("a"))q.Steps[pair.Key]=pair.Value;w.Quests[q.Id]=q;}
  foreach(var pair in rooms){
   Transform point=pair.Value.FindChild("waypoint")??pair.Value.FindChild("left_waypoint");if(point!=null&&!w.Rooms.ContainsKey(pair.Key))AddRoom(w,pair.Key,point,false);
  }
  foreach(Room room in w.Rooms.Values){
   Transform native=ResolveRoom(room.Id);if(native==null)continue;
   var lift=native.GetComponentInChildren<Lift>(true);if(lift==null&&room.Id.EndsWith("room_center")){var floor=level.FindChild(room.Id.Split('/')[0]);if(floor!=null)lift=floor.GetComponentInChildren<Lift>(true);}
   if(lift!=null){room.HasLift=true;room.Vip=lift.isVip||room.Id=="Home";var row=DbManager.instance.getDataFromTable("floors","name",room.Id=="Home"?"Home":room.Id.Split('/')[0]);room.LiftEnabled=room.Id=="Home"||row!=null&&row.getDataValue("lift_enabled")=="True";room.Electricity=row==null||row.getDataValue("shield_enabled")!="False";}
  }
  if(w.SecretUnlocked){Link(w,"floor_1/room_center","floor_-2/room_center");Link(w,"floor_-2/room_center","floor_-3/room_center");Link(w,"floor_-3/room_center","floor_-4/room_center");Link(w,"floor_-4/room_center","floor_-5/room_center");Link(w,"floor_-5/room_center","floor_-6/room_center");Link(w,"floor_-6/room_center","floor_-7/room_center");}
  var random=new System.Random();var tradeItems=new List<string>();foreach(Item item in w.Items.Values)if((item.Type=="weapon"||item.Type=="food"||item.Type=="medical")&&item.Storage=="Inventory"&&item.Id!="hands")tradeItems.Add(item.Id);tradeItems.Sort(StringComparer.Ordinal);
  foreach(Enemy enemy in w.Enemies.Values)if(!w.EnemyTemplates.ContainsKey(enemy.Name))w.EnemyTemplates[enemy.Name]=Json.Copy(enemy);
  foreach(var pair in objects){
   var obj=pair.Value;if(obj==null||obj is InteractiveContainer||obj is BaseEnemy||obj is Bed||obj is Workbranch)continue;
   string room=SceneRoom(obj.transform);if(room==null||!w.Rooms.ContainsKey(room))continue;
   var row=ObjectData.GetValue(obj) as DbObject;string state=row==null?(obj.isActive?"not_used":"used"):row.getDataValue("state");
   var interactive=new Interactive{Id=pair.Key,Name=obj.name,Room=room,State=state,Used=state=="used",Kind="simple"};
   if(obj is QuestBeginer){
    interactive.Kind=obj.name=="change_man"?"trade":"quest";
    var prefab=Resources.Load("quests/"+obj.name) as GameObject;
    interactive.QuestType=prefab!=null&&prefab.GetComponent<SpecialQuest_LastPC>()!=null?"last":prefab!=null&&prefab.GetComponent<SpecialQuest_Windows95>()!=null?"windows":prefab!=null&&prefab.GetComponent<SpecialQuest_PCDialog>()!=null?"dialog":obj.name=="dead_man"?"deadman":"other";
    if(interactive.Kind=="trade"&&tradeItems.Count>1){int n=random.Next(tradeItems.Count);interactive.OfferNeed=tradeItems[n];interactive.OfferHave=tradeItems[(n+1+random.Next(tradeItems.Count-1))%tradeItems.Count];}
    else if(interactive.QuestType=="windows")interactive.Reward["EXPERIMENT_NOTE_1"]=1;
    else if(obj.name=="dead_man"){string[] rewards={"chocolate","door_locker_2_item","knuckles","coin"};interactive.Reward[rewards[random.Next(rewards.Length)]]=1;}
   }else if(obj is InteractiveDoorLocker){interactive.Kind="lock";interactive.Used=state=="used";var sprite=obj.GetComponent<tk2dSprite>();string name=sprite==null?obj.name:sprite.CurrentSprite.name;interactive.NeedItem=name.StartsWith("door_locker_1")?"door_locker_1_item":"door_locker_2_item";interactive.UnlockRoom="floor_"+obj.floorNum+"/"+(obj is InteractiveDoorLockerLeft?"room_left":"room_right");}
   else if(obj is InteractiveElectricityShield){interactive.Kind="repair";interactive.NeedItem=state.StartsWith("not_used_")?state.Substring(9):"wires";}
   else if(obj is TradingMachine){interactive.Kind="machine";interactive.Used=false;var sprite=obj.GetComponent<tk2dSprite>();string name=sprite==null?obj.name:sprite.CurrentSprite.name;string[] products=name.Contains("medic")?new[]{"small_med","bandage","anesthetic","antibiotics"}:name.Contains("food")?new[]{"water","chocolate","cola","nut","milk","overdue_milk"}:new[]{"glue","scotch","rag","mechanism"};foreach(string product in products)if(w.Items.ContainsKey(product))interactive.Products.Add(product);}
   else if(obj is FinishGameObject){interactive.Kind="finish";interactive.Used=false;}
   else if(obj is SuperSecretEndingItem){interactive.Kind="secret_finish";interactive.Used=false;}
   else if(obj is DoorToBoss){interactive.Kind="door";interactive.Used=false;interactive.Destination=((DoorToBoss)obj).isDoorFromBoss?"floor_-5/room_center":"floor_-4/room_center";}
   else if(obj is QuestHolderPhone){interactive.Kind="phone";}
   else if(obj is DoctorWearContainer){interactive.Kind="skin";interactive.Used=false;}

   interactive.NativeLoot=obj is Bird||obj is Fish;w.Interactives[pair.Key]=interactive;
  }
 }
 public void UpgradeSave(World world){
  if(world.Schema>=2)return;var fresh=Capture();
  foreach(var pair in fresh.Items){if(!world.Items.ContainsKey(pair.Key))world.Items[pair.Key]=pair.Value;else world.Items[pair.Key].Storage=pair.Value.Storage;}
  foreach(var pair in fresh.Rooms){Room room;if(!world.Rooms.TryGetValue(pair.Key,out room))world.Rooms[pair.Key]=pair.Value;else{room.HasLift=pair.Value.HasLift;room.LiftEnabled=pair.Value.LiftEnabled;room.Electricity=pair.Value.Electricity;room.Vip=pair.Value.Vip;}}
  foreach(var pair in fresh.Interactives)if(!world.Interactives.ContainsKey(pair.Key))world.Interactives[pair.Key]=pair.Value;
  foreach(var pair in fresh.Recipes){Recipe old;if(!world.Recipes.TryGetValue(pair.Key,out old))world.Recipes[pair.Key]=pair.Value;else{old.Known=pair.Value.Known;old.UpgradeFacility=pair.Value.UpgradeFacility;old.UpgradeLevel=pair.Value.UpgradeLevel;}}
  foreach(Actor actor in world.Actors.Values){actor.ActivePerk=fresh.Template.ActivePerk;actor.PerkState=fresh.Template.PerkState;}world.Template.ActivePerk=fresh.Template.ActivePerk;world.Template.PerkState=fresh.Template.PerkState;
  world.CurrentEnding=fresh.CurrentEnding;world.SecretUnlocked=fresh.SecretUnlocked;world.RecordingCatalog=fresh.RecordingCatalog;world.BedHealing=fresh.BedHealing;world.EnemyTemplates=fresh.EnemyTemplates;
  foreach(var pair in fresh.Journal)world.Journal[pair.Key]=pair.Value;world.Recordings=fresh.Recordings;world.Quests=fresh.Quests;world.Actions=fresh.Actions;world.Schema=2;world.Revision++;
 }
 static readonly Dictionary<int,string> virtualIds=new Dictionary<int,string>();
 public static string VirtualId(BaseInteractiveComponent obj){string id;return obj!=null&&virtualIds.TryGetValue(obj.GetInstanceID(),out id)?id:null;}
 void SpawnQuestEnemies(World world){
  foreach(Enemy enemy in world.Enemies.Values){if(!enemy.Id.StartsWith("quest_enemy:")||objects.ContainsKey(enemy.Id))continue;
   Transform room=ResolveRoom(enemy.Room);if(room==null)continue;
   string side=room.name.Replace("room_","");var config=EnemiesManager.getI.getEnemyDataByName(enemy.Name);var storage=ObjectStorageDataManager.getI.getDataForItemWithName(enemy.Name);if(config==null||storage==null)continue;
   var row=new DbObject("room_objects");row.setDataValue("name",enemy.Name);row.setDataValue("floor_index",Session.FloorNumber(enemy.Room));row.setDataValue("room",side);row.setDataValue("x",config.getDataValue(side+"_x"));row.setDataValue("y",0);row.setDataValue("type",storage.getDataValue("type"));row.setDataValue("prefab",storage.getDataValue("prefab"));row.setDataValue("interactive_component",storage.getDataValue("interactive_component"));row.setDataValue("state","not_used");
   DbManager.instance.insert(row,true);var floor=room.parent;GameObject.Find("GameData").GetComponent<GameData>().addRoomObject(floor.gameObject,row,Session.FloorNumber(enemy.Room));
   foreach(var candidate in room.GetComponentsInChildren<BaseEnemy>(true))if(ObjectData.GetValue(candidate)==row){objects[enemy.Id]=candidate;virtualIds[candidate.GetInstanceID()]=enemy.Id;candidate.enabled=false;candidate.StopAllCoroutines();candidate.CancelInvoke();break;}
  }
 }
 int lastBossPose=-1;bool lastBossDead,bossPresented;float initialBossZ;
 void PresentBoss(World world,Actor observer){
  var floor=level.FindChild("floor_-4");var boss=floor==null?null:floor.GetComponent<Boss>();if(boss==null)return;
  bool here=observer!=null&&observer.Room=="floor_-4/room_center";
  boss.leftClickArea.gameObject.SetActive(here&&!world.BossDefeated&&(observer.BossStep==1||observer.BossStep==3||observer.BossStep==5));
  boss.rightClickArea.gameObject.SetActive(here&&!world.BossDefeated&&(observer.BossStep==1||observer.BossStep==3||observer.BossStep==5));
  boss.centerClickArea.gameObject.SetActive(here&&!world.BossDefeated&&(observer.BossStep==0||observer.BossStep==2||observer.BossStep==4));
  if(!here)return;
  foreach(SkeletonAnimation part in new[]{boss.head,boss.leftPart,boss.centerPart,boss.centerTwoPart})if(part!=null)part.enabled=true;
  if(!bossPresented){initialBossZ=floor.position.z;bossPresented=true;ShowBoss(boss,floor);lastBossPose=0;}
  if(lastBossPose==observer.BossStep&&lastBossDead==world.BossDefeated)return;
  if(world.BossDefeated&&!lastBossDead){SetBossState(boss,8);BossVisual(boss,"attacked");}
  else if(observer.BossStep==0&&lastBossPose>0)ShowBoss(boss,floor);
  else if(observer.BossStep==2&&lastBossPose!=2)BossVisual(boss,"headHit");
  else if(observer.BossStep==4&&lastBossPose!=4){SetBossState(boss,6);BossVisual(boss,"attacked");}
  lastBossPose=observer.BossStep;lastBossDead=world.BossDefeated;

 }
 void ShowBoss(Boss boss,Transform floor){floor.position=new Vector3(floor.position.x,floor.position.y,initialBossZ);BossVisual(boss,"cameraMovedIn");}
 static void SetBossState(Boss boss,int state){typeof(Boss).GetField("state",BindingFlags.NonPublic|BindingFlags.Instance).SetValue(boss,state);}
 static void BossVisual(Boss boss,string method){typeof(Boss).GetMethod(method,BindingFlags.NonPublic|BindingFlags.Instance).Invoke(boss,null);}
 void PresentQuestMessage(World w,GameEvent ev){
  QuestState quest;if(ev.TargetId==null||!w.Quests.TryGetValue(ev.TargetId,out quest))return;
  string body=LanguageManager.Instance.GetTextValue("Quest SMS body: "+(ev.Text??quest.Message));body=body.Replace("XXX",Session.FloorNumber(quest.TargetRoom).ToString());
  QuestsManager.getI.tempSms=new Hashtable();QuestsManager.getI.tempSms["from"]=LanguageManager.Instance.GetTextValue("Quest SMS from: "+(ev.Text??quest.Message));QuestsManager.getI.tempSms["body"]=body;
  NotificationCenter.getI.postNotification("showQuestPhone",QuestsManager.getI);
 }
 void UpdateInteractiveAccess(World w,Actor observer,string id,BaseInteractiveComponent obj){
  Interactive state;if(obj==null||!w.Interactives.TryGetValue(id,out state))return;
  MultiplayerCharacter visual;bool available=observer!=null&&observer.Alive&&observer.Room==state.Room&&w.ServerTime>=observer.MovingUntil&&avatars.TryGetValue(observer.Id,out visual)&&visual!=null&&!visual.IsMoving&&visual.VisualRoom==state.Room&&!state.Used;
  foreach(Enemy e in w.Enemies.Values)if(e.Room==state.Room&&e.Health>0)available=false;
  obj.isChecked=available;obj.isActive=!state.Used;
  var zone=obj.GetComponent<UI_PC_ClickZone>();if(zone!=null){zone.isActive=available;zone.isLocked=false;zone.ShowActionIcon=state.Kind!="lock";zone.cursorState=available?"hand":"arrow";}
  foreach(var collider in obj.GetComponents<Collider>())collider.enabled=available;
  string prior;if(projectedStates.TryGetValue(id,out prior)&&prior==state.State)return;projectedStates[id]=state.State;
  var row=ObjectData.GetValue(obj) as DbObject;if(row!=null){row.setDataValue("state",state.State??"not_used");DbManager.instance.save(row);}
  if(state.Used){
   if(obj is Bird){var renderer=obj.GetComponent<Renderer>();if(renderer!=null)renderer.enabled=false;}
   if(obj is QuestHolderPhone)obj.gameObject.SetActive(false);
   if(obj is Fish){var child=obj.transform.FindChild("anim");var fish=child==null?null:child.GetComponent<SkeletonAnimation>();if(fish!=null){fish.AnimationName="no_fish";fish.Reset();}}
   var sprite=obj.GetComponent<tk2dSprite>();if(sprite!=null&&!sprite.CurrentSprite.name.EndsWith("_used")){string used=sprite.CurrentSprite.name+"_used";if(sprite.GetSpriteIdByName(used)>0)sprite.SetSprite(used);}
   if(obj is InteractiveElectricityShield){var effect=obj.transform.FindChild("crashed_anim");if(effect!=null)effect.gameObject.SetActive(false);}
   if(obj is InteractiveTv){var tv=obj.transform.FindChild("tv_animation");var animation=tv==null?null:tv.GetComponent<SkeletonAnimation>();if(animation!=null){animation.AnimationName="tv_on";animation.Reset();}}
  }
 }
 void ProjectProgression(World w){
  if(w.Revision==projectionRevision)return;projectionRevision=w.Revision;
  SpawnQuestEnemies(w);
  foreach(var pair in w.Journal)if(DbManager.instance.getDataFromTable("journal","identity",pair.Key)==null){var row=new DbObject("journal");row.setDataValue("identity",pair.Key);row.setDataValue("is_new",true);DbManager.instance.insert(row);}
  foreach(DbObject row in DbManager.instance.fetch("dictaphone")){row.setDataValue("isKnown",w.Recordings.Contains(row.getDataValue("name")));DbManager.instance.save(row);}
  var home=DbManager.instance.fetch("home_progress");if(home.Count>0){var row=(DbObject)home[0];foreach(var pair in w.HomeProgress)row.setDataValue(pair.Key,pair.Value);DbManager.instance.save(row);}
  foreach(DbObject row in DbManager.instance.fetch("craft")){Recipe recipe;if(w.Recipes.TryGetValue("recipe:"+row.index,out recipe)){row.setDataValue("is_known",recipe.Known);DbManager.instance.save(row);}}
  NativeInterface.Projecting=true;try{CutscenesManager.getI.setCurrentCutscene(w.CurrentEnding);}finally{NativeInterface.Projecting=false;}
  foreach(Room room in w.Rooms.Values){var native=ResolveRoom(room.Id);if(native==null)continue;var area=native.GetComponent<AreaClick>();if(area!=null)area.isLocked=room.Locked;
   if(!room.HasLift||room.Id=="Home")continue;var row=DbManager.instance.getDataFromTable("floors","name",room.Id.Split('/')[0]);if(row!=null){row.setDataValue("shield_enabled",room.Electricity);DbManager.instance.save(row);}
  }
  var homeObj=GameObject.Find("Home");if(homeObj!=null){var component=homeObj.GetComponent<Home>();if(component!=null)typeof(Home).GetMethod("refresh",BindingFlags.NonPublic|BindingFlags.Instance).Invoke(component,new object[]{null});}
 }
 public bool OpenInteractive(BaseInteractiveComponent obj,World w,Actor player){
  string id=ObjectId(obj);Interactive state;if(id==null||!w.Interactives.TryGetValue(id,out state)||state.Used||player==null||state.Room!=player.Room||w.ServerTime<player.MovingUntil)return false;
  MultiplayerCharacter visual;if(!avatars.TryGetValue(player.Id,out visual)||visual==null||visual.IsMoving)return false;
  NativeInterface.InteractionId=id;
  if(obj is QuestBeginer){NotificationCenter.getI.postNotification("showQuest",obj);return true;}
  if(obj is InteractiveElectricityShield){obj.needItemName=state.NeedItem;NotificationCenter.getI.postNotification(w.Inventory.ContainsKey(state.NeedItem)&&w.Inventory[state.NeedItem]>0?"uiShowElevatorSureMenu":"uiShowElevatorDialog",obj);return true;}
  if(obj is TradingMachine){NotificationCenter.getI.postNotification("uiShowTradingMachineSureMenu",obj);return true;}
  return false;
 }
}
public static partial class NativeInterface {
 public static bool Projecting;public static string InteractionId;
 public static void InstallProgression(HarmonyLib.Harmony h){
  foreach(Type type in typeof(BaseInteractiveComponent).Assembly.GetTypes())if(typeof(BaseInteractiveComponent).IsAssignableFrom(type)){var method=type.GetMethod("action",BindingFlags.Public|BindingFlags.Instance|BindingFlags.DeclaredOnly);if(method!=null)h.Patch(method,new HarmonyLib.HarmonyMethod(typeof(Mod).GetMethod("ObjectClick")));}
  Patch(h,typeof(PerksManager),"useActivePerk","Perk");Patch(h,typeof(PerksManager),"getStateOfCurrentActivePerk","PerkState");
  Patch(h,typeof(SpecialQuest_ChangeMan),"OnEnable","Offer");
  Patch(h,typeof(SpecialQuest_ChangeMan),"accept","AcceptTrade");
  Patch(h,typeof(SpecialQuest_LastPC),"answered","LastPassword");
  Patch(h,typeof(CutscenesManager),"setCurrentCutscene","SetEnding");
  Patch(h,typeof(ExperienceManager),"addExperience","NoNativeMutation");
  Patch(h,typeof(CharacterData),"addJournalItem","NoNativeMutation");
  Patch(h,typeof(CharacterData),"checkJournalContainsItem","ContainsJournal");
  Patch(h,typeof(CharacterData),"getJournalItems","JournalItems");
  Patch(h,typeof(UI_PC_Inventory),"putItem","PutItem");
  Patch(h,typeof(TradingMachine),"Pay","Pay");
  Patch(h,typeof(InteractiveElectricityShield),"repair","Repair");
  Patch(h,typeof(UI_PC_ElevatorDialog),"tryToRepair","TryRepair");
  Patch(h,typeof(UI_PC_LiftMenu),"goToHome","LiftHome");Patch(h,typeof(UI_PC_LiftMenu),"goToFloor","LiftFloor");
  Patch(h,typeof(Lift),"onClicked","LiftOpen");
  Patch(h,typeof(Boss),"onLeftClickArea","BossLeft");Patch(h,typeof(Boss),"onCenterClickArea","BossCenter");Patch(h,typeof(Boss),"onRightClickArea","BossRight");
 }
 public static bool Perk(){if(!Mod.Active)return true;Send("perk",null,0,null);return false;}
 public static bool PerkState(ref string __result){if(!Mod.Active||Player==null)return true;__result=Player.PerkState;return false;}
 public static void ShowQuest(QuestBeginer owner){
  if(owner==null)return;var ui=GameObject.Find("UI");var controller=ui==null?null:ui.GetComponent<GameUI_PC>();var modal=ui==null?null:ui.transform.FindChild("Modal");if(controller==null||modal==null)throw new InvalidOperationException("Native quest UI is not ready");
  var existing=modal.FindChild(owner.name);GameObject panel;
  if(existing==null){
   var prefab=Resources.Load("quests/"+owner.name) as GameObject;if(prefab==null)throw new InvalidOperationException("Missing quest UI: "+owner.name);
   bool wasActive=prefab.activeSelf;prefab.SetActive(false);try{panel=(GameObject)UnityEngine.Object.Instantiate(prefab);}finally{prefab.SetActive(wasActive);}
   panel.name=owner.name;panel.transform.parent=modal;panel.transform.localPosition=new Vector3(576,320,-10);panel.transform.localScale=Vector3.one;
  }else panel=existing.gameObject;
  var quest=panel.GetComponent<Quest>()??panel.GetComponentInChildren<Quest>(true);if(quest==null)throw new InvalidOperationException("Quest UI has no Quest component: "+owner.name);quest.setQuestBeginer(owner);
  if(controller.currentOpenedMenu!=null&&controller.currentOpenedMenu!=panel)controller.currentOpenedMenu.SetActive(false);
  controller.currentOpenedMenu=panel;controller._isModal=true;modal.gameObject.SetActive(true);panel.SetActive(true);NotificationCenter.getI.postNotification("uiTalkingTextHide",null);
 }
 public static bool Offer(SpecialQuest_ChangeMan __instance){if(!Mod.Active||View==null)return true;Interactive obj;if(InteractionId!=null&&View.Interactives.TryGetValue(InteractionId,out obj)){__instance.needItem=GameItemsDataManager.getI.getDataForItemWithName(obj.OfferNeed);__instance.haveItem=GameItemsDataManager.getI.getDataForItemWithName(obj.OfferHave);}return true;}
 public static bool AcceptTrade(SpecialQuest_ChangeMan __instance){if(!Mod.Active)return true;Send("trade",InteractionId,0,null);NotificationCenter.getI.postNotification("closeQuest",__instance);return false;}
 public static bool LastPassword(SpecialQuest_LastPC __instance){if(!Mod.Active)return true;string answer=(string)typeof(SpecialQuest_LastPC).GetField("answer",BindingFlags.NonPublic|BindingFlags.Instance).GetValue(__instance);if(answer=="mr.wgmthooh")Send("quest",InteractionId,0,answer);return true;}
 public static bool SetEnding(){return !Mod.Active||Projecting;}
 public static bool ContainsJournal(string identity,ref int __result){if(!Mod.Active||View==null)return true;__result=View.Journal.ContainsKey(identity)?0:-1;return false;}
 public static bool JournalItems(ref ArrayList __result){if(!Mod.Active||View==null)return true;__result=new ArrayList();foreach(var pair in View.Journal){var row=new DbObject("journal");row.setDataValue("identity",pair.Key);row.setDataValue("is_new",true);__result.Add(row);}return false;}
 public static bool PutItem(){if(!Mod.Active)return true;var cursor=UICursor.cursorInstance;if(cursor!=null&&cursor.itemForPut!=null&&cursor.itemForPut.name=="trash"){Send("recycle",cursor.currentHoldItemName,0,null);return false;}return true;}
 public static bool Pay(TradingMachine __instance){if(!Mod.Active)return true;Send("interact",NativeBridge.ObjectId(__instance),0,"pay");return false;}
 public static bool Repair(InteractiveElectricityShield __instance){if(!Mod.Active)return true;Send("repair",NativeBridge.ObjectId(__instance),0,null);return false;}
 public static bool TryRepair(UI_PC_ElevatorDialog __instance){if(!Mod.Active)return true;Send("repair",NativeBridge.ObjectId(__instance.shield),1,null);NotificationCenter.getI.postNotification("uiHideElevatorDialog",__instance);return false;}
 public static bool LiftHome(){if(!Mod.Active)return true;Send("lift","Home",0,null);NotificationCenter.getI.postNotification("closeLiftMenu",null);return false;}
 public static bool LiftFloor(UI_PC_LiftMenu __instance){if(!Mod.Active)return true;int floor=(int)typeof(UI_PC_LiftMenu).GetField("choosedFloor",BindingFlags.NonPublic|BindingFlags.Instance).GetValue(__instance);Send("lift","floor_"+floor+"/room_center",0,null);NotificationCenter.getI.postNotification("closeLiftMenu",__instance);return false;}
 public static bool LiftOpen(Lift __instance){if(!Mod.Active)return true;if(Player!=null&&View!=null)foreach(Enemy enemy in View.Enemies.Values)if(enemy.Room==Player.Room&&enemy.Health>0)return false;if(Player!=null&&(Player.Room=="Home"?"Home":"floor_"+__instance.floorNum+"/room_center")==Player.Room)NotificationCenter.getI.postNotification("showLiftMenu",__instance);return false;}
 public static bool BossLeft(){if(!Mod.Active)return true;Send("boss","left",0,null);return false;}
 public static bool BossCenter(){if(!Mod.Active)return true;Send("boss","center",0,null);return false;}
 public static bool BossRight(){if(!Mod.Active)return true;Send("boss","right",0,null);return false;}
}
}
