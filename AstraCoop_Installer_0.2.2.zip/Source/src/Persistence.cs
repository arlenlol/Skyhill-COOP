using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
namespace AstraCoop {
public sealed class SaveData {public int Schema=2;public World World;public Settings Settings;public Dictionary<string,Member> Members;}
public sealed class SaveEnvelope {public string Payload,Sha256;}
public static class Persistence {
 public static void Save(Session s,string path,double now){
  var data=new SaveData{World=Json.Copy(s.World),Settings=s.Settings,Members=s.Members};
  foreach(Actor a in data.World.Actors.Values){a.OpeningAttackUntil=Math.Max(0,a.OpeningAttackUntil-now);a.MovingUntil=Math.Max(0,a.MovingUntil-now);a.NextAttack=Math.Max(0,a.NextAttack-now);a.NextMove=Math.Max(0,a.NextMove-now);}
  foreach(Enemy e in data.World.Enemies.Values)e.NextAttack=Math.Max(0,e.NextAttack-now);
  foreach(Counterattack pending in data.World.PendingCounters)pending.At=Math.Max(0,pending.At-now);
  string payload=Json.Write(data);string json=Json.Write(new SaveEnvelope{Payload=payload,Sha256=Session.Hash(payload)});
  Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path)));string temp=path+".tmp";
  using(var f=new FileStream(temp,FileMode.Create,FileAccess.Write,FileShare.None)){byte[] bytes=Encoding.UTF8.GetBytes(json);f.Write(bytes,0,bytes.Length);f.Flush();}
  if(File.Exists(path))File.Replace(temp,path,path+".bak");else File.Move(temp,path);
 }
 public static Session Load(string path,double now){
  var info=new FileInfo(path);if(info.Length>32*1024*1024)throw new IOException("Save too large");
  SaveEnvelope env=Json.Read<SaveEnvelope>(File.ReadAllText(path));if(!Session.Equal(env.Sha256,Session.Hash(env.Payload)))throw new IOException("Checksum mismatch");
  SaveData data=Json.Read<SaveData>(env.Payload);if((data.Schema!=1&&data.Schema!=2)||(data.World.Schema!=1&&data.World.Schema!=2))throw new IOException("Unsupported save version");
  data.World.ServerTime=now;
  foreach(Actor a in data.World.Actors.Values){a.OpeningAttackUntil=now+Math.Max(0,a.OpeningAttackUntil);a.MovingUntil=now+Math.Max(0,a.MovingUntil);a.NextAttack=now+Math.Min(1,a.NextAttack);a.NextMove=now+Math.Max(0,a.NextMove);}
  foreach(Enemy e in data.World.Enemies.Values)e.NextAttack=now+Math.Min(1,e.NextAttack);
  foreach(Counterattack pending in data.World.PendingCounters)pending.At=now+Math.Max(0,pending.At);
  return new Session(data.World,data.Settings,Environment.TickCount){Members=data.Members};
 }
}
}

