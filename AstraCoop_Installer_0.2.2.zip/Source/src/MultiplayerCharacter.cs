using System;
using System.Collections.Generic;
using UnityEngine;
namespace AstraCoop {
// Visual-only actor: no native Character or CharacterData is cloned.
public sealed class MultiplayerCharacter:MonoBehaviour {
 public Actor State {get;private set;}
 public bool IsMoving {get{return route.Count>0;}}
 public string VisualRoom {get{return visualRoom;}}
 readonly Queue<Transform> route=new Queue<Transform>();
 Transform waypoint,masks;BaseSkeletonAnimation graphic;CharacterEffectsManager effects;EventSounds sounds;
 int bossPose=-1;string destination,visualRoom,animation,skin;bool initialized,dead,battle;float speed;
 public void Initialize(Character source,Transform parent,Transform initial,Actor state){
  if(source==null||source.model==null||source.animationGraphix==null||initial==null||state==null)throw new InvalidOperationException("Character visual source is not ready");
  transform.parent=parent;transform.position=initial.position;waypoint=initial;speed=Math.Max(1,source.model.moveSpeed*70f);
  var template=new GameObject("AstraVisual");template.SetActive(false);template.transform.parent=transform;template.transform.localPosition=Vector3.zero;
  var main=(GameObject)UnityEngine.Object.Instantiate(source.animationGraphix.gameObject);main.transform.parent=template.transform;CopyTransform(main.transform,source.animationGraphix.transform,source.transform);
  graphic=main.GetComponent<BaseSkeletonAnimation>();if(graphic==null)throw new InvalidOperationException("Missing actor graphics");graphic.connectedAnimation=null;
  if(source.animationGraphix.connectedAnimation!=null){var shadow=(GameObject)UnityEngine.Object.Instantiate(source.animationGraphix.connectedAnimation.gameObject);shadow.transform.parent=template.transform;CopyTransform(shadow.transform,source.animationGraphix.connectedAnimation.transform,source.transform);var connected=shadow.GetComponent<BaseSkeletonAnimation>();if(connected!=null){connected.connectedAnimation=null;graphic.connectedAnimation=connected;}}
  Transform originalMasks=source.transform.FindChild("shadow_masks");if(originalMasks!=null){var copy=(GameObject)UnityEngine.Object.Instantiate(originalMasks.gameObject);copy.transform.parent=template.transform;copy.transform.localPosition=originalMasks.localPosition;masks=copy.transform;}
  template.SetActive(true);main.SetActive(true);
  if(source.eventSounds!=null){sounds=gameObject.AddComponent<EventSounds>();foreach(var f in typeof(EventSounds).GetFields(System.Reflection.BindingFlags.Public|System.Reflection.BindingFlags.Instance))if(!f.IsInitOnly)f.SetValue(sounds,f.GetValue(source.eventSounds));}
  var sourceEffects=source.transform.FindChild("effects");if(sourceEffects!=null){var copy=(GameObject)UnityEngine.Object.Instantiate(sourceEffects.gameObject);copy.transform.parent=transform;copy.transform.localPosition=sourceEffects.localPosition;effects=copy.GetComponent<CharacterEffectsManager>();foreach(Transform effect in copy.transform)effect.gameObject.SetActive(false);copy.SetActive(true);}
  graphic.onAnimationFinished_evnt+=AnimationFinished;initialized=true;destination=visualRoom=state.Room;State=state;Play("idle",true);UpdateMasks();
 }
 static void CopyTransform(Transform copy,Transform original,Transform character){copy.localPosition=character.InverseTransformPoint(original.position);copy.localRotation=Quaternion.Inverse(character.rotation)*original.rotation;Vector3 scale=character.lossyScale;Vector3 visual=original.lossyScale;copy.localScale=new Vector3(visual.x/Math.Max(0.001f,Mathf.Abs(scale.x)),visual.y/Math.Max(0.001f,Mathf.Abs(scale.y)),visual.z/Math.Max(0.001f,Mathf.Abs(scale.z)));}
 static SkeletonAnimation Skeleton(BaseSkeletonAnimation visual){
  if(visual==null)return null;var skeleton=visual.getSkeletonAnimation();
  if(skeleton==null){skeleton=visual.GetComponent<SkeletonAnimation>();visual.skeletonAnimation=skeleton;}
  if(skeleton!=null)skeleton.enabled=true;
  if(skeleton!=null&&(skeleton.skeleton==null||skeleton.state==null)){skeleton.Reset();}
  return skeleton!=null&&skeleton.skeleton!=null&&skeleton.state!=null?skeleton:null;
 }
 void Weapon(BaseSkeletonAnimation visual){
  var skeleton=Skeleton(visual);if(skeleton==null||State==null)return;
  var slot=skeleton.skeleton.FindSlot("weapon");if(slot==null)return;
  string attachment=String.IsNullOrEmpty(State.Weapon)||State.Weapon=="hands"?null:"char_images/weapons/"+State.Weapon;
  if(attachment!=null&&skeleton.skeleton.GetAttachment("weapon",attachment)==null)return;
  skeleton.skeleton.SetAttachment("weapon",attachment);
 }
 public void Apply(Actor state,Transform target){
  if(state==null||target==null||!initialized)return;State=state;
  if(graphic!=null&&skin!=state.Skin&&Skeleton(graphic)!=null){graphic.changeSkin(state.Skin??"default");skin=state.Skin;}
  if(!state.Alive){if(!dead){dead=true;route.Clear();Play("death_battle",false);}return;}
  if(destination==state.Room){
   if(state.Room=="floor_-4/room_center"&&bossPose!=state.BossStep){bossPose=state.BossStep;string[] positions={"left","center","left","center","right","center","right"};var floor=target.parent;var point=floor.FindChild(positions[Math.Max(0,Math.Min(6,bossPose))]+"_waypoint");if(point!=null&&point!=waypoint){route.Clear();route.Enqueue(point);}}
   return;
  }
  if(state.TravelKind=="lift"){route.Clear();transform.position=target.position;waypoint=target;destination=visualRoom=state.Room;UpdateMasks();Play(IdleAnimation(),true);return;}
  Transform start=waypoint;foreach(Transform point in route)if(point!=null)start=point;
  List<Transform> path=NativePath.Find(start,target);
  if(path==null){ // Only a server-validated destination reaches this adapter.
   route.Clear();transform.position=target.position;waypoint=target;destination=visualRoom=state.Room;UpdateMasks();Play(IdleAnimation(),true);return;
  }
  destination=state.Room;battle=false;foreach(Transform point in path)if(point!=null)route.Enqueue(point);
  if(route.Count==0){waypoint=target;visualRoom=destination;UpdateMasks();}
 }
 void Update(){
  if(!initialized||dead)return;
  if(route.Count>0){
   Transform next=route.Peek();if(next==null){route.Dequeue();return;}
   if(waypoint==null)waypoint=next;
   bool flip=next.position.x<waypoint.position.x;
   if(graphic!=null&&Skeleton(graphic)!=null)graphic.changeFlipX(flip);
   float dy=next.position.y-waypoint.position.y;string walk=dy>1?"walk_stairs_up":dy< -1?"walk_stairs_down":"walk";
   if(waypoint.name=="point_hall_top"&&flip&&Mathf.Abs(dy)<=1)walk="walk_stairs_down";
   if(waypoint.name=="point_hall_middle"&&!flip&&Mathf.Abs(dy)<=1)walk="walk_stairs_up";
   Play(walk,true);transform.position=new Vector3(transform.position.x,transform.position.y,next.position.z);
   transform.position=Vector3.MoveTowards(transform.position,next.position,speed*Time.deltaTime);
   if(transform.position==next.position){waypoint=next;route.Dequeue();if(route.Count==0){visualRoom=destination;Play(IdleAnimation(),true);UpdateMasks();}}
  }
  // Reset() reconstructs Spine's skeleton; restore equipment after every animation reset.
  Weapon(graphic);if(graphic!=null)Weapon(graphic.connectedAnimation);
 }
 public void Present(GameEvent ev){if(ev==null||dead||IsMoving)return;if(ev.Kind=="attack_hit"||ev.Kind=="attack_miss"){battle=true;Play(WeaponType()+"_hit",false,true);}else if(ev.Kind=="enemy_attack"&&ev.Amount>0){if(effects!=null&&effects.transform.FindChild("blood_in_fight_1")!=null)effects.playEffect("blood_in_fight_1");Play(WeaponType()+"_hurt",false,true);}else if(ev.Kind=="player_death")Play("death_battle",false,true);}
 public void SetBattle(bool value){if(!initialized||dead||battle==value)return;battle=value;if(!IsMoving)Play(IdleAnimation(),true,true);}
 string WeaponType(){if(State==null||String.IsNullOrEmpty(State.Weapon))return "cold";var config=InventoryItemsConfigsBase.getI.getConfigForItem(State.Weapon);string type;return config!=null&&config.TryGetValue("weapon_type",out type)&&!String.IsNullOrEmpty(type)?type:"cold";}
 string IdleAnimation(){return battle?WeaponType()+"_idle":"idle";}
 void Play(string name,bool loop,bool force=false){if(graphic==null||Skeleton(graphic)==null)return;if(animation==name&&!force)return;animation=name;graphic.changeAnimation(name,loop,force);if(sounds!=null&&Mathf.Abs(transform.position.y)<1000){string sound=name=="walk_stairs_up"?"walk_up":name=="walk_stairs_down"?"walk_down":name.EndsWith("_hurt")?"hurt":name.StartsWith("cold")&&name.EndsWith("_hit")?"cold_hit":name;sounds.ReceiveEvent("hero_"+sound);}}
 void AnimationFinished(BaseSkeletonAnimation sender){if(!dead&&!IsMoving&&animation!=IdleAnimation())Play(IdleAnimation(),true);}
 void UpdateMasks(){if(masks==null||waypoint==null||waypoint.parent==null)return;foreach(Transform mask in masks)mask.gameObject.SetActive(false);string room=waypoint.parent.name;string side=room.Contains("left")?"left":room.Contains("right")?"right":room.Contains("center")?"center":null;if(side!=null){var mask=masks.FindChild(side+"_room_mask");if(mask!=null)mask.gameObject.SetActive(true);}}
 void OnDestroy(){if(graphic!=null)graphic.onAnimationFinished_evnt-=AnimationFinished;}
}
// Native WayPoint.findWay assumes every parent is a numbered floor and traverses
// shared temporary nodes. BFS uses only scene links and tolerates destroyed nodes.
public static class NativePath {
 public static List<Transform> Find(Transform start,Transform target){
  if(start==null||target==null)return null;var parents=new Dictionary<Transform,Transform>();var queue=new Queue<Transform>();parents[start]=null;queue.Enqueue(start);
  while(queue.Count>0&&parents.Count<10000){var point=queue.Dequeue();if(point==target){var path=new List<Transform>();while(point!=start){path.Add(point);point=parents[point];}path.Reverse();return path;}
   var waypoint=point.GetComponent<WayPoint>();if(waypoint==null)continue;
   if(waypoint.connectedPoints!=null)foreach(var link in waypoint.connectedPoints)if(link!=null&&!parents.ContainsKey(link.transform)){parents[link.transform]=point;queue.Enqueue(link.transform);}
   if(waypoint.connectedWaypoints!=null)foreach(var entry in waypoint.connectedWaypoints){var link=entry as GameObject;if(link!=null&&!parents.ContainsKey(link.transform)){parents[link.transform]=point;queue.Enqueue(link.transform);}}
  }return null;
 }
}
}
