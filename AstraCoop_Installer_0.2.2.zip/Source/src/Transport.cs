using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
namespace AstraCoop {
public static class Wire {
 public const int MaxRequest=8192, MaxReply=8*1024*1024;
 public static string Read(Stream stream,int max){
  byte[] h=ReadExact(stream,4);int n=(h[0]<<24)|(h[1]<<16)|(h[2]<<8)|h[3];
  if(n<1||n>max)throw new IOException("Frame size");return new UTF8Encoding(false,true).GetString(ReadExact(stream,n));
 }
 static byte[] ReadExact(Stream stream,int n){byte[] b=new byte[n];int offset=0;while(offset<n){int got=stream.Read(b,offset,n-offset);if(got==0)throw new EndOfStreamException();offset+=got;}return b;}
 public static void Write(Stream stream,string text){byte[] b=Encoding.UTF8.GetBytes(text);if(b.Length>MaxReply)throw new IOException("Frame size");int n=b.Length;byte[] h={(byte)(n>>24),(byte)(n>>16),(byte)(n>>8),(byte)n};stream.Write(h,0,4);stream.Write(b,0,b.Length);}
}
public sealed class Pending {
 public Command Command; public string MemberId; public bool Api;
 public readonly ManualResetEvent Done=new ManualResetEvent(false); public string Response;
 public volatile bool Abandoned;
}
public sealed class Server:IDisposable {
 readonly object gate=new object();readonly Queue<Pending> pending=new Queue<Pending>();readonly List<TcpClient> clients=new List<TcpClient>();
 readonly List<TcpListener> listeners=new List<TcpListener>();volatile bool stopped;readonly int maxConnections;
 public Server(int maxConnections){this.maxConnections=maxConnections;}
 public void Listen(IPAddress address,int port,bool api){var l=new TcpListener(address,port);l.Start();listeners.Add(l);var t=new Thread(delegate(){Accept(l,api);});t.IsBackground=true;t.Start();}
 void Accept(TcpListener listener,bool api){while(!stopped){try{var c=listener.AcceptTcpClient();lock(gate){if(clients.Count>=maxConnections){c.Close();continue;}clients.Add(c);}var t=new Thread(delegate(){Serve(c,api);});t.IsBackground=true;t.Start();}catch(SocketException){if(stopped)return;}catch(ObjectDisposedException){return;}}}
 void Serve(TcpClient c,bool api){
  try{c.NoDelay=true;c.ReceiveTimeout=15000;c.SendTimeout=5000;using(var s=c.GetStream()){
   string member=null;
   while(!stopped){Command command=Json.Read<Command>(Wire.Read(s,Wire.MaxRequest));if(command==null)break;
    if(member==null&&command.Op!="join"){Wire.Write(s,Json.Write(Reply.Result("join_required")));break;}
    if(member!=null&&command.Op=="join"){Wire.Write(s,Json.Write(Reply.Result("already_joined")));continue;}
    var p=new Pending{Command=command,MemberId=member,Api=api};lock(gate){if(pending.Count>=256){p.Done.Close();break;}pending.Enqueue(p);}
    if(!p.Done.WaitOne(10000)){p.Abandoned=true;break;}
    string response=p.Response;p.Done.Close();if(response==null)break;Wire.Write(s,response);
    if(member==null){Reply r=Json.Read<Reply>(response);if(!r.Ok)break;member=r.MemberId;}
   }
  }}catch(IOException){}catch(SocketException){}catch(ArgumentException){}catch(InvalidOperationException){}catch(FormatException){}catch(OverflowException){}
  finally{c.Close();lock(gate)clients.Remove(c);}
 }
 public int Pump(Session session,double now,int budget){int n=0;while(n<budget){Pending p;lock(gate){if(pending.Count==0)break;p=pending.Dequeue();}
   if(p.Abandoned){p.Done.Close();continue;}
   try{Reply r=p.MemberId==null?session.Join(p.Command,p.Api):session.Execute(p.MemberId,p.Command,now);p.Response=Json.Write(r);}
   catch(Exception){p.Response=Json.Write(Reply.Result("internal_error"));}
   p.Done.Set();n++;
  }return n;
 }
 public void Dispose(){stopped=true;foreach(var l in listeners)l.Stop();lock(gate){foreach(var c in clients)c.Close();while(pending.Count>0){var p=pending.Dequeue();p.Abandoned=true;p.Done.Set();}}}
}
// One sequential request stream per controller; slow sockets never block Unity.
public sealed class Client:IDisposable {
 TcpClient socket;readonly object gate=new object();readonly Queue<Command> commands=new Queue<Command>();
 public volatile Reply Latest;public volatile Reply Welcome;public volatile string Error;volatile bool stopped;long sequence=1;public string Token;
 public void Connect(string host,int port,Command join){var t=new Thread(delegate(){Run(host,port,join);});t.IsBackground=true;t.Start();}
 public void Send(Command command){lock(gate){if(commands.Count>=32){Error="Command queue full";return;}commands.Enqueue(command);}}
 void Run(string host,int port,Command join){try{socket=new TcpClient();var ar=socket.BeginConnect(host,port,null,null);if(!ar.AsyncWaitHandle.WaitOne(5000))throw new IOException("Connect timeout");socket.EndConnect(ar);ar.AsyncWaitHandle.Close();socket.NoDelay=true;socket.ReceiveTimeout=10000;socket.SendTimeout=5000;
  using(var s=socket.GetStream()){
   Reply r=Request(s,join);Latest=r;if(!r.Ok){Error=r.Code;Welcome=r;return;}sequence=r.NextSequence;Token=r.Token??join.Token;Welcome=r;
   while(!stopped){Command c=null;lock(gate){if(commands.Count>0)c=commands.Dequeue();}if(c==null)c=new Command{Op="state"};else c.Sequence=sequence;
    r=Request(s,c);if(r.NextSequence>0)sequence=r.NextSequence;if(r.State!=null)Latest=r;if(!r.Ok)Error=r.Code;else if(c.Op!="state")Error=null;Thread.Sleep(100);
   }
  }
 }catch(Exception e){if(!stopped)Error=e.Message;}finally{if(socket!=null)socket.Close();}}
 static Reply Request(Stream s,Command c){Wire.Write(s,Json.Write(c));return Json.Read<Reply>(Wire.Read(s,Wire.MaxReply));}
 public void Dispose(){stopped=true;if(socket!=null)socket.Close();}
}
}

