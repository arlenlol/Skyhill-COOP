using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
namespace AstraCoop {
// Mutations run only on the owning game thread. Network workers never receive World references.
public sealed partial class Session {
 public World World; public Settings Settings; public Dictionary<string,Member> Members=new Dictionary<string,Member>();
 public Func<bool> EntryAttackAllowed;
 public Func<Actor,string,string,Dictionary<string,int>> GenerateLoot;
 readonly Random random;
 // Host-owned enemy turns: entry initiative and reactions, never periodic idle damage.
 List<Counterattack> counterattacks {get{return World.PendingCounters;}}
 public Session(World world,Settings settings,int seed){World=world;Settings=settings;random=new Random(seed);}
 static readonly RandomNumberGenerator Secrets=RandomNumberGenerator.Create();
 public static string Secret(){byte[] b=new byte[32];lock(Secrets)Secrets.GetBytes(b);return Convert.ToBase64String(b);}
 public static string Hash(string s){using(var h=SHA256.Create())return Convert.ToBase64String(h.ComputeHash(Encoding.UTF8.GetBytes(s??"")));}
 public static bool Equal(string a,string b){var x=Encoding.UTF8.GetBytes(Hash(a));var y=Encoding.UTF8.GetBytes(Hash(b));int z=0;for(int i=0;i<x.Length;i++)z|=x[i]^y[i];return z==0;}
 public Reply Join(Command c,bool api){
  if(c.Version!=2)return Reply.Result("protocol_version");
  if(!Equal(c.Password,api?Settings.ApiKey:Settings.Password))return Reply.Result("unauthorized");
  if(!String.IsNullOrEmpty(c.Token)){
   string hash=Hash(c.Token);foreach(Member m in Members.Values)if(Equal(m.TokenHash,hash))return Welcome(m,null,api);
   return Reply.Result("invalid_resume_token");
  }
  if(c.Role!="player"&&c.Role!="spectator")return Reply.Result("invalid_role");
  bool spectator=c.Role=="spectator";
  if(spectator&&!Settings.AllowSpectators)return Reply.Result("spectators_disabled");
  int count=0;foreach(Member m in Members.Values)if((m.ActorId==null)==spectator)count++;
  if(count>=(spectator?Settings.MaxSpectators:Settings.MaxPlayers))return Reply.Result("session_full");
  if(String.IsNullOrEmpty(c.Name)||c.Name.Trim().Length==0||c.Name.Length>32||HasControls(c.Name))return Reply.Result("invalid_name");
  if(!spectator&&World.GameOver)return Reply.Result("game_over");
  string token=Secret();var member=new Member{Id=Guid.NewGuid().ToString("N"),Name=c.Name.Trim(),TokenHash=Hash(token)};
  if(!spectator){
   if(World.Template==null)return Reply.Result("world_not_ready");
   var actor=Json.Copy(World.Template);actor.Id=member.Id;actor.Name=member.Name;actor.NextAttack=actor.NextMove=0;
   member.ActorId=actor.Id;World.Actors.Add(actor.Id,actor);
  }
  Members.Add(member.Id,member);World.Revision++;return Welcome(member,token,api);
 }
 Reply Welcome(Member m,string token,bool api){return new Reply{Ok=true,Code="ok",Token=token,MemberId=m.Id,ActorId=m.ActorId,NextSequence=m.LastSequence+1,State=View(),Bootstrap=api?null:World.NativeXml};}
 public World View(){
  // Project before cloning: never repeatedly parse the entire original XML database,
  // and never place hidden loot tables or credentials in a public snapshot.
  var v=new World{SessionId=World.SessionId,Schema=World.Schema,Started=World.Started,GameOver=World.GameOver,Revision=World.Revision,
   ChatSequence=World.ChatSequence,EventSequence=World.EventSequence,ServerTime=World.ServerTime,Actions=World.Actions,
   Actors=World.Actors,Rooms=World.Rooms,Inventory=World.Inventory,Items=World.Items,Recipes=World.Recipes,HomeProgress=World.HomeProgress,Chat=World.Chat,Events=World.Events,
   CurrentEnding=World.CurrentEnding,CompletedEnding=World.CompletedEnding,SecretUnlocked=World.SecretUnlocked,BossDefeated=World.BossDefeated,Journal=World.Journal,Recordings=World.Recordings,Quests=World.Quests};
  foreach(var pair in World.Interactives)if(World.Rooms.ContainsKey(pair.Value.Room)&&World.Rooms[pair.Value.Room].Known){var copy=Json.Copy(pair.Value);copy.Reward.Clear();copy.Products.Clear();v.Interactives.Add(pair.Key,copy);}
  foreach(var e in World.Enemies)if(World.Rooms[e.Value.Room].Known)v.Enemies.Add(e.Key,e.Value);
  foreach(var d in World.Drops)if(World.Rooms[d.Value.Room].Known)v.Drops.Add(d.Key,d.Value);
  foreach(var c in World.Containers.Values)if(World.Rooms[c.Room].Known)v.Containers.Add(c.Id,new Container{Id=c.Id,Name=c.Name,Room=c.Room,Used=c.Used,EnemyId=c.EnemyId});
  return Json.Copy(v);
 }
 public Reply Execute(string memberId,Command c,double now){
  Member m;if(!Members.TryGetValue(memberId,out m))return Reply.Result("unauthorized");
  if(c.Op=="state")return new Reply{Ok=true,Code="ok",State=View(),NextSequence=m.LastSequence+1};
  if(c.Sequence==m.LastSequence&&m.LastReply!=null)return Json.Copy(m.LastReply);
  if(c.Sequence!=m.LastSequence+1)return new Reply{Code="sequence_mismatch",NextSequence=m.LastSequence+1};
  World.ServerTime=now;Reply r=Apply(m,c,now);m.LastSequence=c.Sequence;r.NextSequence=c.Sequence+1;m.LastReply=Json.Copy(r);return r;
 }
 Reply Apply(Member m,Command c,double now){
  if(c.Op=="chat"){
   if(m.ActorId==null&&!Settings.SpectatorChat)return Reply.Result("spectator_chat_disabled");
   if(c.Text==null||c.Text.Trim().Length==0||c.Text.Length>512||HasControls(c.Text))return Reply.Result("invalid_text");
   World.Chat.Add(new Chat{Id=++World.ChatSequence,SenderId=m.Id,SenderName=m.Name,Text=c.Text,Time=DateTime.UtcNow.ToString("o")});
   if(World.Chat.Count>256)World.Chat.RemoveAt(0);World.Revision++;return Reply.Result("ok");
  }
  if(m.ActorId==null)return Reply.Result("spectator_read_only");
  Actor p=World.Actors[m.ActorId];if(!p.Alive)return Reply.Result("dead");
  if(!World.Started)return Reply.Result("not_started");if(World.GameOver)return Reply.Result("game_over");
  if(now<p.OpeningAttackUntil)return new Reply{Code="enemy_turn",RetryAfter=p.OpeningAttackUntil-now};
  if(now<p.MovingUntil)return new Reply{Code="moving",RetryAfter=p.MovingUntil-now};
  Reply special=Progression(p,c,now);if(special!=null)return special;
  if(c.Op=="move"){
   Room dest;if(c.Target==null||!World.Rooms.TryGetValue(c.Target,out dest)||!World.Rooms[p.Room].Neighbours.Contains(c.Target))return Reply.Result("unreachable");
   if(dest.Locked)return Reply.Result("room_locked");
   if(p.Room=="floor_-4/room_center"&&!World.BossDefeated)return Reply.Result("boss_not_defeated");
   if(!World.SecretUnlocked&&dest.Id.StartsWith("floor_-"))return Reply.Result("secret_locked");
   if(now<p.NextMove)return Cooldown(p.NextMove-now);
   if(p.PassivePerk=="PASSIVE_PERK_1")foreach(Enemy enemy in World.Enemies.Values)if(enemy.Room==p.Room&&enemy.Health>0)return Reply.Result("enemies_present");
   if(p.Room.EndsWith("/room_center"))foreach(Enemy enemy in World.Enemies.Values)if(enemy.Room==p.Room&&enemy.Health>0){int from=FloorNumber(p.Room),to=FloorNumber(dest.Id);if(to<=from)return Reply.Result("center_enemy_blocks_route");}
   double travel;World.Rooms[p.Room].TravelSeconds.TryGetValue(dest.Id,out travel);
   p.TravelKind="walk";p.MovingUntil=now+Math.Max(0,travel);p.Room=dest.Id;dest.Known=true;p.NextMove=Math.Max(now+1,p.MovingUntil);
   ScheduleEntryAttack(p,p.MovingUntil);TravelTurn(p);AdvanceQuests(p,"room",dest.Id);Record("move",p.Id,dest.Id,0);CheckGameOver();World.Revision++;return Reply.Result("ok");
  }
  if(c.Op=="sleep"){
   if(p.Room!="Home")return Reply.Result("requires_home");
   if(c.Zone<1||c.Zone>10)return Reply.Result("invalid_sleep_hours");
   if(World.SleepHealthPerFood<=0)return Reply.Result("sleep_rules_unavailable");
   int bed;World.HomeProgress.TryGetValue("bed",out bed);double healing;if(!World.BedHealing.TryGetValue(bed.ToString(),out healing))healing=World.SleepHealthPerFood;
   double spent=Math.Min(c.Zone*10,Math.Max(0,p.Food-5));if(spent==0)return Reply.Result("not_enough_food");
   p.Food-=spent;p.Health=Math.Min(p.MaxHealth,p.Health+spent*healing);Record("sleep",p.Id,"Home",c.Zone);World.Revision++;return Reply.Result("ok");
  }
  if(c.Op=="attack"){
   Enemy e;if(c.Target==null||!World.Enemies.TryGetValue(c.Target,out e))return Reply.Result("unknown_enemy");
   if(e.Room!=p.Room)return Reply.Result("out_of_range");if(e.Health<=0)return Reply.Result("already_dead");
   if(c.Zone<0||c.Zone>=e.Chances.Length)return Reply.Result("invalid_zone");
   if(now<p.NextAttack)return Cooldown(p.NextAttack-now);
   Item w;if(!World.Items.TryGetValue(p.Weapon,out w))return Reply.Result("unknown_weapon");
   p.NextAttack=now+1;bool power=p.ActivePerk=="ACTIVE_PERK_8"&&p.PerkState=="prepared";if(power)p.PerkState="150";double chance=Math.Min(95,e.Chances[c.Zone]+Stat(p,"accuracy")*Stat(p,"accuracy_factor"));
   Reply result=Reply.Result("ok");if(power||random.Next(Math.Max(1,100-p.MissCompensation))<chance){
    p.MissCompensation=0;double min,max;WeaponDamage(p,w,out min,out max);
    double damage=random.Next((int)Math.Round(min*100),(int)Math.Round(max*100)+1)/100.0;
    if(random.Next(100)<Stat(p,"strength")*Stat(p,"strength_factor"))damage*=1.5;
    damage*=e.Multipliers[c.Zone];if(p.PassivePerk=="PASSIVE_PERK_3")damage*=p.Room.EndsWith("room_center")?0.5:1.25;if(p.PassivePerk=="PASSIVE_PERK_9")damage*=random.Next(1,301)/100.0;if(power)damage=1000;damage=Math.Round(damage,1);e.Health=Math.Max(0,e.Health-damage);result.Hit=true;result.Damage=damage;
    if(e.Health==0){AdvanceQuests(p,"enemy",e.Name);GrantExperience(p,e.Experience);Record("enemy_death",p.Id,e.Id,0);}
   }else p.MissCompensation=Math.Min(99,p.MissCompensation+15);
   Record(result.Hit?"attack_hit":"attack_miss",p.Id,e.Id,result.Damage);
   // 50% chance for the living monster to react AFTER an attempted attack.
   // The reaction has its own native dexterity-based hit/miss calculation.
   // Entry initiative is scheduled separately at arrival, using the native 20% roll.
   if(e.Health>0&&random.Next(100)<50){
    counterattacks.Add(new Counterattack{EnemyId=e.Id,VictimId=p.Id,At=now+0.65});
   }
   World.Revision++;return result;
  }
  if(c.Op=="upgrade"){
   if(c.Target!="strength"&&c.Target!="dexterity"&&c.Target!="speed"&&c.Target!="accuracy")return Reply.Result("invalid_stat");
   if(Stat(p,"free_skill_points")<1)return Reply.Result("no_skill_points");p.Stats["free_skill_points"]=Stat(p,"free_skill_points")-1;p.Stats[c.Target]=Stat(p,c.Target)+(p.PassivePerk=="PASSIVE_PERK_7"?random.Next(1,9):1);World.Revision++;return Reply.Result("ok");
  }
  if(c.Op=="pickup"){
   Loot d;if(c.Target==null||!World.Drops.TryGetValue(c.Target,out d))return Reply.Result("already_taken");
   if(d.Room!=p.Room)return Reply.Result("out_of_range");Add(d.Item,d.Count);World.Drops.Remove(d.Id);World.Revision++;return Reply.Result("ok");
  }
  if(c.Op=="interact"){
   Container box;if(c.Target==null||!World.Containers.TryGetValue(c.Target,out box))return Reply.Result("unsupported_object");
   if(box.Room!=p.Room)return Reply.Result("out_of_range");if(box.Used)return Reply.Result("already_used");
   foreach(Enemy enemy in World.Enemies.Values)if(enemy.Room==p.Room&&enemy.Health>0)return Reply.Result("enemies_present");
   if(box.NativeLoot){if(GenerateLoot==null)return Reply.Result("loot_generator_unavailable");box.Loot=GenerateLoot(p,box.Name,box.Room);}
   Dictionary<string,int> receipt=Award(box.Loot);box.Used=true;AdvanceQuests(p,"object",box.Name);Record("loot",p.Id,box.Id,0);World.Events[World.Events.Count-1].Items=receipt;World.Revision++;return Reply.Result("ok");
  }
  if(c.Op=="craft"){
   Recipe recipe;if(c.Target==null||!World.Recipes.TryGetValue(c.Target,out recipe))return Reply.Result("unknown_recipe");
   if(!recipe.Known)return Reply.Result("recipe_locked");
   if(recipe.UpgradeFacility!=null){int current;World.HomeProgress.TryGetValue(recipe.UpgradeFacility,out current);if(recipe.UpgradeLevel!=current+1)return Reply.Result("upgrade_order");}
   if(recipe.NeedHome&&p.Room!="Home")return Reply.Result("requires_home");
   int level=0;if(!String.IsNullOrEmpty(recipe.RequiredFacility))World.HomeProgress.TryGetValue(recipe.RequiredFacility,out level);
   if(level<recipe.RequiredLevel)return Reply.Result("requires_home_upgrade");
   var spend=new Dictionary<string,int>();
   // Reserve exact ingredients first, then wildcard ingredients from the remainder.
   foreach(var pair in recipe.Ingredients)if(pair.Key!="any_fruit"&&pair.Key!="any_veg"){
    if(pair.Value<=0||Available(pair.Key)<pair.Value)return Reply.Result("missing_ingredients_or_equipped");spend[pair.Key]=pair.Value;
   }
   var ids=new List<string>(World.Inventory.Keys);ids.Sort(StringComparer.Ordinal);
   foreach(string wildcard in new[]{"any_fruit","any_veg"}){
    int remaining;if(!recipe.Ingredients.TryGetValue(wildcard,out remaining))continue;
    foreach(string id in ids){if(!id.Contains(wildcard=="any_fruit"?"f1":"v1"))continue;int used;spend.TryGetValue(id,out used);int count=Math.Min(remaining,Math.Max(0,Available(id)-used));if(count>0){spend[id]=used+count;remaining-=count;}if(remaining==0)break;}
    if(remaining!=0)return Reply.Result("missing_ingredients_or_equipped");
   }
   foreach(var pair in spend)Add(pair.Key,-pair.Value);
   if(recipe.UpgradeFacility!=null){World.HomeProgress[recipe.UpgradeFacility]=recipe.UpgradeLevel;recipe.Known=false;foreach(var next in World.Recipes.Values)if(next.UpgradeFacility==recipe.UpgradeFacility&&next.UpgradeLevel==recipe.UpgradeLevel+1)next.Known=true;}
   else Add(recipe.Result,1);
   RefreshStory();Record("craft",p.Id,recipe.Result,1);World.Revision++;return Reply.Result("ok");
  }
  Item item;if(c.Target==null||!World.Items.TryGetValue(c.Target,out item))return Reply.Result("unknown_item");
  if(c.Op=="recycle"){
   if(Available(item.Id)<1)return Reply.Result("item_unavailable");
   string[] materials={"wood","glandules","nails","mechanism","scotch","copper_wires"};
   Add(item.Id,-1);if(item.Type=="weapon"){var valid=new List<string>();foreach(string id in materials)if(World.Items.ContainsKey(id))valid.Add(id);if(valid.Count>0)Add(valid[random.Next(valid.Count)],1);}Record("recycle",p.Id,item.Id,1);World.Revision++;return Reply.Result("ok");
  }
  if(c.Op=="slot"){
   if(c.Zone<0||c.Zone>1)return Reply.Result("invalid_slot");
   if(item.Type!="weapon")return Reply.Result("not_weapon");
   int count;if(item.Id!="hands"&&(!World.Inventory.TryGetValue(item.Id,out count)||count<=0))return Reply.Result("item_unavailable");
   if(c.Zone==0)p.QuickWeapon1=item.Id;else p.QuickWeapon2=item.Id;
   World.Revision++;return Reply.Result("ok");
  }
  if(c.Op=="equip"){
   if(item.Type!="weapon")return Reply.Result("not_weapon");
   if(item.Id!="hands"&&p.Weapon!=item.Id&&Available(item.Id)<=0)return Reply.Result("item_unavailable");
   p.Weapon=item.Id;
  }else if(c.Op=="use"){
   if(Available(item.Id)<=0)return Reply.Result("item_unavailable");
   if(item.Type=="food"){p.Food=Math.Max(0,Math.Min(p.MaxFood,p.Food+item.Food));if(p.PassivePerk=="PASSIVE_PERK_2"&&random.Next(101)<25)p.Health=Math.Max(1,p.Health-item.Food);if(item.Id.Contains("overdue")&&p.PassivePerk!="PASSIVE_PERK_5"&&random.Next(101)<50)p.Health=Math.Max(0,p.Health-8);}
   else if(item.Type=="medical"){p.Health=Math.Max(0,Math.Min(p.MaxHealth,p.Health+item.Health));if(item.Id=="antidote")p.Poison=false;}
   else return Reply.Result("not_consumable");Add(item.Id,-1);
  }else if(c.Op=="drop"){
   // Explicitly dropping one's equipped weapon releases its reservation first.
   if(Available(item.Id)<=0){if(p.Weapon!=item.Id||item.Id=="hands")return Reply.Result("item_unavailable");p.Weapon="hands";}
   Add(item.Id,-1);var d=new Loot{Id=Guid.NewGuid().ToString("N"),Room=p.Room,Item=item.Id,Count=1};World.Drops.Add(d.Id,d);
  }else return Reply.Result("unsupported_action");
  World.Revision++;return Reply.Result("ok");
 }
 void ScheduleEntryAttack(Actor player,double arrival){
  if((EntryAttackAllowed!=null?!EntryAttackAllowed():World.SuppressEntryAttack)||player.PassivePerk=="PASSIVE_PERK_1")return;
  var enemies=new List<Enemy>();foreach(Enemy enemy in World.Enemies.Values)if(enemy.Room==player.Room&&enemy.Health>0)enemies.Add(enemy);
  if(enemies.Count==0||random.Next(100)>=20)return;
  enemies.Sort(delegate(Enemy a,Enemy b){return StringComparer.Ordinal.Compare(a.Id,b.Id);});
  player.OpeningAttackUntil=arrival+0.65+(enemies.Count-1)*0.2;
  for(int i=0;i<enemies.Count;i++)counterattacks.Add(new Counterattack{EnemyId=enemies[i].Id,VictimId=player.Id,At=arrival+0.65+i*0.2});
 }
 public void Tick(double now){
  World.ServerTime=now;
  if(!World.Started||World.GameOver)return;
  for(int i=counterattacks.Count-1;i>=0;i--){
   Counterattack pending=counterattacks[i];if(now<pending.At)continue;
   counterattacks.RemoveAt(i);
   Enemy e;Actor p;
   if(!World.Enemies.TryGetValue(pending.EnemyId,out e)||e.Health<=0||
      !World.Actors.TryGetValue(pending.VictimId,out p)||!p.Alive||p.Room!=e.Room)continue;
   // Original FightingManager.enemieAttackChance: a successful dexterity
   // roll makes the monster miss. Preserve native damage scatter and crit.
   double evasion=Math.Max(0,Math.Min(100,Stat(p,"dexterity")*Stat(p,"dexterity_factor")));
   bool hits=random.Next(101)>evasion;
   double damage=0;
   if(hits){
    int scatter=Math.Max(0,Math.Min(100,(int)World.EnemyScatter));
    damage=e.Damage*(1+random.Next(-scatter,scatter+1)/100.0)*World.Difficulty;if(p.PassivePerk=="PASSIVE_PERK_4")damage*=1.25;
    if(random.Next(101)<World.EnemyCritPercent)damage*=1+World.EnemyCritFactor;
    damage=Math.Max(0,Math.Round(damage,1));
    p.Health=Math.Max(0,p.Health-damage);
   }
   Record(hits?"enemy_attack":"enemy_miss",e.Id,p.Id,damage);
   if(!p.Alive)Record("player_death",p.Id,e.Id,0);
   World.Revision++;
  }
  CheckGameOver();
 }
 void CheckGameOver(){
  if(World.Actors.Count==0)return;
  bool alive=false;foreach(Actor p in World.Actors.Values){if(p.Alive)alive=true;else p.Weapon="hands";}
  if(!alive&&!World.GameOver){World.GameOver=true;counterattacks.Clear();Record("game_over",null,null,0);World.Revision++;}
 }
 void Record(string kind,string actor,string target,double amount){World.Events.Add(new GameEvent{Id=++World.EventSequence,Kind=kind,ActorId=actor,TargetId=target,Amount=amount,Time=DateTime.UtcNow.ToString("o")});if(World.Events.Count>512)World.Events.RemoveAt(0);}
 void GrantExperience(Actor p,int experience){
  double points=Stat(p,"experience_points")+Math.Round(experience/Math.Max(0.01,World.Difficulty));double threshold=Math.Max(50,Stat(p,"experience_points_max"));
  while(points>=threshold){points-=threshold;threshold=Math.Round(threshold*1.5);p.Stats["level_num"]=Stat(p,"level_num")+1;p.Stats["free_skill_points"]=Stat(p,"free_skill_points")+(p.PassivePerk=="PASSIVE_PERK_7"?1:4);p.Health=Math.Min(p.MaxHealth,p.Health+World.LevelUpHealing);}
  p.Stats["experience_points"]=points;p.Stats["experience_points_max"]=threshold;
 }
 public int Available(string id){int n;World.Inventory.TryGetValue(id,out n);foreach(Actor p in World.Actors.Values)if(p.Weapon==id)n--;return n;}
 void Add(string id,int n){int count;World.Inventory.TryGetValue(id,out count);World.Inventory[id]=checked(count+n);if(World.Inventory[id]<0)throw new InvalidOperationException("Negative inventory");RefreshStory();}
 static Reply Cooldown(double seconds){return new Reply{Code="cooldown",RetryAfter=seconds};}
 static bool HasControls(string s){foreach(char c in s)if(Char.IsControl(c))return true;return false;}
 public static double Stat(Actor p,string key){double n;return p.Stats.TryGetValue(key,out n)?n:0;}
 public static void WeaponDamage(Actor p,Item w,out double min,out double max){
  int required=0,met=0;double sum=0;double[] needs={w.Strength,w.Dexterity,w.Speed};string[] names={"strength","dexterity","speed"};
  for(int i=0;i<3;i++)if(needs[i]>0){required++;if(Stat(p,names[i])>=needs[i]){met++;sum+=Stat(p,names[i]);}}
  double bonus=0;if(required==met)bonus=Math.Round(sum*Stat(p,required==2?"double_weapon_factor":required==3?"tripple_weapon_factor":"weapon_bonus_factor"),1);
  min=Math.Round(required==met?w.Min+bonus:w.Min*0.67,1);max=Math.Round(required==met?w.Max+bonus:w.Max*0.67,1);
 }
}
}
