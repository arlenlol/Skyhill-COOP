using System;
using System.Collections.Generic;

namespace AstraCoop {
// Client-side route selection only: the server still validates every individual move.
// This code never touches SKYHILL's global Character or mutates the world.
public static class MouseRoute {
 public static List<string> Find(World world,string source,string destination){
  if(world==null||world.Rooms==null||String.IsNullOrEmpty(source)||String.IsNullOrEmpty(destination))return null;
  if(!world.Rooms.ContainsKey(source)||!world.Rooms.ContainsKey(destination))return null;
  if(source==destination)return new List<string>();
  if(world.Rooms[destination].Locked)return null;
  var previous=new Dictionary<string,string>(StringComparer.Ordinal);
  var queue=new Queue<string>();queue.Enqueue(source);previous[source]=null;
  while(queue.Count>0){
   string at=queue.Dequeue();Room room=world.Rooms[at];if(room.Neighbours==null)continue;
   foreach(string next in room.Neighbours){
    Room candidate;
    if(previous.ContainsKey(next)||!world.Rooms.TryGetValue(next,out candidate)||candidate.Locked)continue;
    previous[next]=at;
    if(next==destination){
     var path=new List<string>();string current=destination;
     while(current!=source){path.Add(current);current=previous[current];}
     path.Reverse();return path;
    }
    queue.Enqueue(next);
   }
  }
  return null;
 }
}
}
