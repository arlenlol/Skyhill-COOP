using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Text;
namespace AstraCoop {
// Closed DTO serializer for the Unity 5 Mono profile. No type names, object activation from input,
// polymorphic dispatch, external dependencies or executable deserialization callbacks.
public static class Json {
 public static T Copy<T>(T value){return Read<T>(Write(value));}
 public static string Write(object value){var b=new StringBuilder();Encode(b,value,0);return b.ToString();}
 public static T Read<T>(string value){if(value==null||value.Length>16*1024*1024)throw new FormatException("JSON size");var p=new Parser(value);object o=p.Value(0);p.Space();if(!p.End)throw new FormatException("Trailing JSON");return (T)ConvertValue(o,typeof(T));}
 static void Encode(StringBuilder b,object value,int depth){
  if(depth>64)throw new FormatException("JSON depth");if(value==null){b.Append("null");return;}
  if(value is string){Quote(b,(string)value);return;}if(value is bool){b.Append((bool)value?"true":"false");return;}
  if(value is IDictionary){b.Append('{');bool comma=false;foreach(DictionaryEntry e in (IDictionary)value){if(comma)b.Append(',');comma=true;Quote(b,(string)e.Key);b.Append(':');Encode(b,e.Value,depth+1);}b.Append('}');return;}
  if(value is IEnumerable){b.Append('[');bool comma=false;foreach(object e in (IEnumerable)value){if(comma)b.Append(',');comma=true;Encode(b,e,depth+1);}b.Append(']');return;}
  Type t=value.GetType();if(t.IsPrimitive||value is decimal){string n=System.Convert.ToString(value,CultureInfo.InvariantCulture);if(n=="NaN"||n.Contains("Infinity"))throw new FormatException("Nonfinite number");b.Append(n);return;}
  b.Append('{');bool first=true;foreach(FieldInfo f in t.GetFields(BindingFlags.Public|BindingFlags.Instance)){if(!first)b.Append(',');first=false;Quote(b,f.Name);b.Append(':');Encode(b,f.GetValue(value),depth+1);}b.Append('}');
 }
 static void Quote(StringBuilder b,string s){b.Append('"');foreach(char c in s){switch(c){case '"':b.Append("\\\"");break;case '\\':b.Append("\\\\");break;case '\n':b.Append("\\n");break;case '\r':b.Append("\\r");break;case '\t':b.Append("\\t");break;default:if(c<32)b.Append("\\u"+((int)c).ToString("x4"));else b.Append(c);break;}}b.Append('"');}
 static object ConvertValue(object value,Type type){
  if(value==null){if(type.IsValueType)throw new FormatException("Null value type");return null;}
  if(type==typeof(string)){if(!(value is string))throw new FormatException("Expected string");return value;}
  if(type==typeof(bool)){if(!(value is bool))throw new FormatException("Expected bool");return value;}
  if(type.IsPrimitive||type==typeof(decimal)){if(!(value is double))throw new FormatException("Expected number");double n=(double)value;if((type==typeof(int)||type==typeof(long))&&n!=Math.Truncate(n))throw new FormatException("Expected integer");return System.Convert.ChangeType(value,type,CultureInfo.InvariantCulture);}
  if(type.IsArray){var source=value as List<object>;if(source==null)throw new FormatException("Expected array");Type item=type.GetElementType();Array array=Array.CreateInstance(item,source.Count);for(int i=0;i<source.Count;i++)array.SetValue(ConvertValue(source[i],item),i);return array;}
  if(type.IsGenericType&&type.GetGenericTypeDefinition()==typeof(List<>)){var source=value as List<object>;if(source==null)throw new FormatException("Expected list");IList result=(IList)Activator.CreateInstance(type);foreach(object item in source)result.Add(ConvertValue(item,type.GetGenericArguments()[0]));return result;}
  var fields=value as Dictionary<string,object>;if(fields==null)throw new FormatException("Expected object");
  if(type.IsGenericType&&type.GetGenericTypeDefinition()==typeof(Dictionary<,>)){IDictionary result=(IDictionary)Activator.CreateInstance(type);foreach(var pair in fields)result.Add(pair.Key,ConvertValue(pair.Value,type.GetGenericArguments()[1]));return result;}
  object dto=Activator.CreateInstance(type);foreach(var pair in fields){FieldInfo f=type.GetField(pair.Key,BindingFlags.Instance|BindingFlags.Public);if(f!=null)f.SetValue(dto,ConvertValue(pair.Value,f.FieldType));}return dto;
 }
 sealed class Parser {
  readonly string text;int index;public Parser(string text){this.text=text;}public bool End{get{return index==text.Length;}}
  public void Space(){while(index<text.Length&&(text[index]==' '||text[index]=='\n'||text[index]=='\r'||text[index]=='\t'))index++;}
  char Take(){if(End)throw new FormatException("Truncated JSON");return text[index++];}
  void Expect(char c){Space();if(Take()!=c)throw new FormatException("Unexpected JSON token");}
  bool Literal(string s){if(index+s.Length>text.Length||text.Substring(index,s.Length)!=s)return false;index+=s.Length;return true;}
  public object Value(int depth){Space();if(depth>64||End)throw new FormatException("JSON depth/truncation");char c=text[index];
   if(c=='"')return String();
   if(c=='{'){index++;var o=new Dictionary<string,object>();Space();if(index<text.Length&&text[index]=='}'){index++;return o;}while(true){Space();string key=String();Expect(':');if(o.ContainsKey(key))throw new FormatException("Duplicate JSON key");o.Add(key,Value(depth+1));Space();c=Take();if(c=='}')return o;if(c!=',')throw new FormatException("Expected comma");}}
   if(c=='['){index++;var a=new List<object>();Space();if(index<text.Length&&text[index]==']'){index++;return a;}while(true){a.Add(Value(depth+1));Space();c=Take();if(c==']')return a;if(c!=',')throw new FormatException("Expected comma");}}
   if(Literal("true"))return true;if(Literal("false"))return false;if(Literal("null"))return null;
   int start=index;if(text[index]=='-')index++;if(index==text.Length)throw new FormatException("Number");
   if(text[index]=='0')index++;else{if(text[index]<'1'||text[index]>'9')throw new FormatException("Number");while(index<text.Length&&Char.IsDigit(text[index]))index++;}
   if(index<text.Length&&text[index]=='.'){index++;int digits=index;while(index<text.Length&&Char.IsDigit(text[index]))index++;if(index==digits)throw new FormatException("Fraction");}
   if(index<text.Length&&(text[index]=='e'||text[index]=='E')){index++;if(index<text.Length&&(text[index]=='+'||text[index]=='-'))index++;int digits=index;while(index<text.Length&&Char.IsDigit(text[index]))index++;if(index==digits)throw new FormatException("Exponent");}
   double number;if(!Double.TryParse(text.Substring(start,index-start),NumberStyles.Float,CultureInfo.InvariantCulture,out number)||Double.IsInfinity(number)||Double.IsNaN(number))throw new FormatException("Invalid number");return number;
  }
  string String(){if(Take()!='"')throw new FormatException("Expected string");var b=new StringBuilder();while(true){char c=Take();if(c=='"')return b.ToString();if(c<32)throw new FormatException("Control in string");if(c!='\\'){b.Append(c);continue;}c=Take();switch(c){case '"':case '\\':case '/':b.Append(c);break;case 'b':b.Append('\b');break;case 'f':b.Append('\f');break;case 'n':b.Append('\n');break;case 'r':b.Append('\r');break;case 't':b.Append('\t');break;case 'u':if(index+4>text.Length)throw new FormatException("Unicode escape");b.Append((char)Int32.Parse(text.Substring(index,4),NumberStyles.HexNumber));index+=4;break;default:throw new FormatException("String escape");}}
  }
 }
}
}
