using System;
using System.Collections.Generic;
namespace AstraCoop {
public sealed partial class Session {
 // All progression mutations share Execute's sequencing, range checks and save state.
 Reply Progression(Actor p,Command c,double now){
  if(p.Room=="floor_-4/room_center"&&!World.BossDefeated&&c.Op!="boss"&&c.Op!="state")return Reply.Result("boss_in_progress");
  if(c.Op=="boss"){
   if(p.Room!="floor_-4/room_center")return Reply.Result("out_of_range");
   if(World.BossDefeated)return Reply.Result("already_used");
   string[] sequence={"center","left","center","right","center","right"};
   if(c.Target!="left"&&c.Target!="right"&&c.Target!="center")return Reply.Result("invalid_boss_direction");
   if(now<p.NextAttack)return Cooldown(p.NextAttack-now);
   p.NextAttack=now+1;
   if(c.Target!=sequence[Math.Max(0,Math.Min(5,p.BossStep))]){p.BossStep=0;Record("boss_restart",p.Id,c.Target,0);}
   else{p.BossStep++;Record("boss_step",p.Id,c.Target,p.BossStep);if(p.BossStep==6){World.BossDefeated=true;Record("boss_death",p.Id,null,0);}}
   World.Revision++;return Reply.Result("ok");
  }
  if(c.Op=="perk")return UsePerk(p,now);
  if(c.Op=="lift")return RideLift(p,c.Target,now);
  Interactive obj;if(c.Target==null||!World.Interactives.TryGetValue(c.Target,out obj))return null;
  if(c.Op!="interact"&&c.Op!="trade"&&c.Op!="quest"&&c.Op!="repair")return null;
  if(obj.Room!=p.Room)return Reply.Result("out_of_range");
  foreach(Enemy enemy in World.Enemies.Values)if(enemy.Room==p.Room&&enemy.Health>0)return Reply.Result("enemies_present");
  if(obj.Used)return Reply.Result("already_used");
  if(c.Op=="trade"&&obj.Kind!="trade"||c.Op=="quest"&&obj.Kind!="quest"||c.Op=="repair"&&obj.Kind!="repair")return Reply.Result("invalid_object_action");
  if(obj.Kind=="trade"){
   if(c.Op!="trade")return Reply.Result("confirmation_required");
   if(String.IsNullOrEmpty(obj.OfferNeed)||String.IsNullOrEmpty(obj.OfferHave))return Reply.Result("offer_unavailable");
   if(Available(obj.OfferNeed)<1)return Reply.Result("missing_trade_item");
   Add(obj.OfferNeed,-1);Add(obj.OfferHave,1);obj.Used=true;
   Record("trade",p.Id,obj.Id,1);
  }else if(obj.Kind=="quest"){
   if(c.Op!="quest")return Reply.Result("confirmation_required");
   if(obj.QuestType=="last"||obj.Name.Contains("last")||obj.Name.Contains("Last")){
    if(c.Text!="mr.wgmthooh")return Reply.Result("wrong_password");
    World.CurrentEnding="end_3";
   }
   if(obj.QuestType=="windows"&&World.Journal.ContainsKey("EXPERIMENT_NOTE_1"))return Reply.Result("already_used");
   Award(obj.Reward);GrantExperience(p,100);obj.Used=true;Record("quest",p.Id,obj.Id,0);
  }else if(obj.Kind=="phone"){
   QuestState quest=StartQuest(p);if(quest==null)return Reply.Result("no_quests");obj.Used=true;
  }else if(obj.Kind=="lock"){
   bool lockpick=p.ActivePerk=="ACTIVE_PERK_5"&&p.PerkState=="prepared";
   string key=!String.IsNullOrEmpty(obj.NeedItem)&&Available(obj.NeedItem)>0?obj.NeedItem:Available("master_key")>0?"master_key":null;
   if(key==null&&!lockpick)return Reply.Result("missing_key");
   Room room;if(obj.UnlockRoom==null||!World.Rooms.TryGetValue(obj.UnlockRoom,out room))return Reply.Result("unknown_room");
   if(lockpick)p.PerkState="100";else Add(key,-1);room.Locked=false;obj.Used=true;Record("unlock",p.Id,obj.UnlockRoom,0);
  }else if(obj.Kind=="repair"){
   if(c.Op!="repair")return Reply.Result("confirmation_required");
   if(c.Zone==0){if(Available(obj.NeedItem)<1)return Reply.Result("missing_repair_item");Add(obj.NeedItem,-1);}
   else if(c.Zone==1){
    int cost=random.Next(5,15);double food=Math.Min(cost,p.Food);p.Food-=food;p.Health=Math.Max(1,p.Health-(cost-food));
    if(random.Next(101)>=80){Record("repair_failed",p.Id,obj.Id,cost);World.Revision++;return Reply.Result("repair_failed");}
   }else return Reply.Result("invalid_repair_mode");
   int floor=FloorNumber(obj.Room);for(int i=0;i<5&&floor-i>1;i++)foreach(Room room in World.Rooms.Values)if(FloorNumber(room.Id)==floor-i)room.Electricity=true;
   obj.Used=true;Record("repair",p.Id,obj.Id,0);
  }else if(obj.Kind=="machine"){
   if(c.Text!="pay")return Reply.Result("confirmation_required");
   if(Available("coin")<1)return Reply.Result("missing_coin");if(obj.Products.Count==0)return Reply.Result("products_unavailable");
   Add("coin",-1);Add(obj.Products[random.Next(obj.Products.Count)],1);Record("machine",p.Id,obj.Id,1);
  }else if(obj.Kind=="finish"||obj.Kind=="secret_finish"){
   if(obj.Kind=="secret_finish"&&(!World.SecretUnlocked||!World.BossDefeated||p.Room!="floor_-7/room_center"))return Reply.Result("ending_locked");
   World.CompletedEnding=obj.Kind=="secret_finish"?"end_4":World.CurrentEnding;
   World.GameOver=true;counterattacks.Clear();Record("ending",p.Id,World.CompletedEnding,0);
  }else if(obj.Kind=="door"){
   if(obj.Destination==null||!World.Rooms.ContainsKey(obj.Destination))return Reply.Result("secret_locked");
   if(p.Room=="floor_-4/room_center"&&!World.BossDefeated)return Reply.Result("boss_not_defeated");
   p.Room=obj.Destination;p.TravelKind="walk";p.MovingUntil=now+1;World.Rooms[p.Room].Known=true;Record("move",p.Id,p.Room,0);
  }else if(obj.Kind=="skin"){p.Skin="med";obj.Used=true;Record("skin",p.Id,obj.Id,0);}
  else {if(obj.NativeLoot){if(GenerateLoot==null)return Reply.Result("loot_generator_unavailable");obj.Reward=GenerateLoot(p,obj.Name,obj.Room);}obj.Used=true;Award(obj.Reward);Record("interact",p.Id,obj.Id,0);}
  if(obj.Used)obj.State="used";AdvanceQuests(p,"object",obj.Name);RefreshStory();World.Revision++;return Reply.Result("ok");
 }
 Reply RideLift(Actor p,string target,double now){
  Room origin,dest;if(!World.Rooms.TryGetValue(p.Room,out origin)||target==null||!World.Rooms.TryGetValue(target,out dest))return Reply.Result("unknown_room");
  if(!origin.HasLift||!dest.HasLift||!origin.LiftEnabled||!dest.LiftEnabled)return Reply.Result("lift_unavailable");
  foreach(Enemy e in World.Enemies.Values)if(e.Room==p.Room&&e.Health>0)return Reply.Result("enemies_present");
  if((origin.Vip||dest.Vip)&&Available("vip_card")<1)return Reply.Result("missing_vip_card");
  int bottom=Math.Min(FloorNumber(p.Room),FloorNumber(target));
  foreach(Room r in World.Rooms.Values)if(r.HasLift&&FloorNumber(r.Id)>=bottom&&!r.Electricity)return Reply.Result("electricity_off");
  if(dest.Locked)return Reply.Result("room_locked");
  p.Room=target;p.TravelKind="lift";p.MovingUntil=now+0.5;p.NextMove=p.MovingUntil;dest.Known=true;ScheduleEntryAttack(p,p.MovingUntil);TravelTurn(p);AdvanceQuests(p,"room",dest.Id);Record("lift",p.Id,target,0);World.Revision++;return Reply.Result("ok");
 }
 public static int FloorNumber(string room){if(room=="Home")return 100;int floor;return room!=null&&room.StartsWith("floor_")&&Int32.TryParse(room.Split('/')[0].Substring(6),out floor)?floor:0;}
 Dictionary<string,int> Award(Dictionary<string,int> items){
  var receipt=new Dictionary<string,int>();foreach(var pair in items){
   string id=pair.Key;Item item;if(pair.Value<=0||!World.Items.TryGetValue(id,out item))continue;
   if(id=="audio_tape_2"){for(int i=0;i<pair.Value;i++)foreach(string recording in World.RecordingCatalog)if(!World.Recordings.Contains(recording)){World.Recordings.Add(recording);break;}receipt[id]=pair.Value;continue;}
   if(item.Storage=="journal"){
    if(World.Journal.ContainsKey(id)&&id!="EXPERIMENT_NOTE_1"){
     var candidates=new List<string>();foreach(Item next in World.Items.Values)if(next.Storage=="journal"&&next.Type=="storyline"&&!World.Journal.ContainsKey(next.Id))candidates.Add(next.Id);
     candidates.Sort(StringComparer.Ordinal);if(candidates.Count==0)continue;id=candidates[random.Next(candidates.Count)];
    }
    if(!World.Journal.ContainsKey(id)){World.Journal[id]=1;receipt[id]=1;}
   }else{Add(id,pair.Value);receipt[id]=pair.Value;}
  }RefreshStory();return receipt;
 }
 void RefreshStory(){
  int photo;World.Inventory.TryGetValue("maniac_photo",out photo);if(photo>0&&World.CurrentEnding=="end_1")World.CurrentEnding="end_2";
  bool pieces=true;for(int i=1;i<=4;i++){int n;if(!World.Inventory.TryGetValue("piece_of_photo_"+i,out n)||n<1)pieces=false;}
  if(pieces)foreach(Recipe r in World.Recipes.Values)if(r.Result=="maniac_photo")r.Known=true;
 }
 void TravelTurn(Actor p){
  int counter;if(Int32.TryParse(p.PerkState,out counter))p.PerkState=counter<=1?"ready":(counter-1).ToString();
  p.PerkMoves++;
  if(p.PassivePerk=="PASSIVE_PERK_6"&&p.PerkMoves%8==0){var ids=new List<string>();foreach(var pair in World.Inventory)if(Available(pair.Key)>0)ids.Add(pair.Key);ids.Sort(StringComparer.Ordinal);if(ids.Count>0)Add(ids[random.Next(ids.Count)],-1);}
  int floor=FloorNumber(p.Room);if(p.PassivePerk=="PASSIVE_PERK_8"&&floor>0&&floor<p.LowestFloor){double max=60+90-floor/10*10;if(max>p.MaxHealth)p.Health=p.MaxHealth=max;p.LowestFloor=floor;}
  if(p.ActivePerk=="ACTIVE_PERK_1"&&Int32.TryParse(p.PerkState,out counter)&&counter>90)return;
  if(p.Room.StartsWith("floor_-")||p.Room=="floor_1/room_center")return;
  double factor=p.PassivePerk=="PASSIVE_PERK_2"?0.5:1;
  if(p.Food>0)p.Food=Math.Max(0,p.Food-p.Hunger*factor);else p.Health=Math.Max(0,p.Health-p.Hunger*p.HungerDamage*(p.PassivePerk=="PASSIVE_PERK_5"?5:factor));
  if(p.Poison)p.Health=Math.Max(0,p.Health-1);
 }
 Reply UsePerk(Actor p,double now){
  if(String.IsNullOrEmpty(p.ActivePerk))return Reply.Result("no_active_perk");
  if(p.PerkState!="ready"&&p.PerkState!="prepared")return Reply.Result("perk_unavailable");
  switch(p.ActivePerk){
   case "ACTIVE_PERK_1":p.PerkState="100";break;
   case "ACTIVE_PERK_2":p.Food=Math.Min(p.MaxFood,p.Food+100);p.PerkState="used";break;
   case "ACTIVE_PERK_3":p.Health=Math.Min(p.MaxHealth,p.Health+50);p.PerkState="used";break;
   case "ACTIVE_PERK_4":{
    var choices=new List<string>();foreach(string facility in new[]{"bed","table","door","kitchen"}){int current,max;World.HomeProgress.TryGetValue(facility,out current);World.HomeProgress.TryGetValue(facility+"_max",out max);if(current<max)choices.Add(facility);}
    if(choices.Count==0)return Reply.Result("home_fully_upgraded");string chosen=choices[random.Next(choices.Count)];World.HomeProgress[chosen]++;foreach(var r in World.Recipes.Values)if(r.UpgradeFacility==chosen)r.Known=r.UpgradeLevel==World.HomeProgress[chosen]+1;p.PerkState="used";break;
   }
   case "ACTIVE_PERK_5":case "ACTIVE_PERK_8":p.PerkState=p.PerkState=="prepared"?"ready":"prepared";break;
   case "ACTIVE_PERK_6":foreach(Room room in World.Rooms.Values)if(Math.Abs(FloorNumber(room.Id)-FloorNumber(p.Room))<=1)room.Known=true;p.PerkState="50";break;
   case "ACTIVE_PERK_7":{
    foreach(Enemy enemy in World.Enemies.Values)if(enemy.Room==p.Room&&enemy.Health>0)return Reply.Result("enemies_present");
    string room="floor_"+random.Next(30,71)+"/room_center";if(!World.Rooms.ContainsKey(room))return Reply.Result("unknown_room");p.Room=room;p.TravelKind="lift";p.MovingUntil=now+0.5;World.Rooms[room].Known=true;p.PerkState="100";TravelTurn(p);break;
   }
   case "ACTIVE_PERK_9":{
    double points=p.PassivePerk=="PASSIVE_PERK_7"?Math.Max(0,Stat(p,"level_num")-1):Stat(p,"free_skill_points");foreach(string stat in new[]{"speed","dexterity","strength","accuracy"}){if(p.PassivePerk!="PASSIVE_PERK_7")points+=Math.Max(0,Stat(p,stat)-5);p.Stats[stat]=5;}p.Stats["free_skill_points"]=points;p.PerkState="used";break;
   }
   case "ACTIVE_PERK_10":{
    switch(random.Next(7)){case 0:p.Health=Math.Min(p.MaxHealth,p.Health+25*random.Next(1,5));break;case 1:p.Health=Math.Max(0,p.Health-25*random.Next(1,3));break;case 2:p.Food=Math.Min(p.MaxFood,p.Food+25*random.Next(1,3));break;case 3:p.Food=Math.Max(0,p.Food-25*random.Next(1,3));break;case 4:GrantExperience(p,100);break;case 5:p.Poison=true;break;default:string stat=new[]{"speed","dexterity","accuracy","strength"}[random.Next(4)];p.Stats[stat]=Stat(p,stat)+1;break;}p.PerkState="50";break;
   }
   default:return Reply.Result("unknown_perk");
  }
  Record("perk",p.Id,p.ActivePerk,0);CheckGameOver();World.Revision++;return Reply.Result("ok");
 }
 void AdvanceQuests(Actor player,string kind,string value){
  foreach(QuestState quest in World.Quests.Values){
   int step;if(!Int32.TryParse(quest.State,out step)||step<=0)continue;
   string need;if(!quest.Steps.TryGetValue("a"+step,out need))continue;
   bool location=quest.TargetRoom==null||quest.TargetRoom==player.Room;
   bool match=location&&(kind=="object"&&(need=="special_"+value||need==value)||kind=="enemy"&&need==value);
   if(kind=="room"){string[] room=value.Split('/');if(room.Length==2){string side=room[1].Replace("room_","");match=need=="goto_"+side.Substring(0,1)+"_"+FloorNumber(value);}}
   if(match)StepQuest(player,quest,step+1);
  }
 }
 QuestState StartQuest(Actor p){
  var candidates=new List<QuestState>();foreach(var q in World.Quests.Values)if(q.State=="0"){
   if(q.Name.StartsWith("special_")){bool exists=false;string name=q.Name.Substring(8);foreach(var box in World.Containers.Values)if(box.Name==name&&!box.Used)exists=true;foreach(var obj in World.Interactives.Values)if(obj.Name==name&&!obj.Used)exists=true;if(!exists)continue;}
   candidates.Add(q);
  }
  if(candidates.Count==0)return null;candidates.Sort(delegate(QuestState a,QuestState b){return StringComparer.Ordinal.Compare(a.Id,b.Id);});var quest=candidates[random.Next(candidates.Count)];quest.OwnerId=p.Id;StepQuest(p,quest,1);return quest;
 }
 void StepQuest(Actor player,QuestState quest,int step){
  for(int guard=0;guard<20;guard++,step++){
   string next;quest.State=step.ToString();
   if(!quest.Steps.TryGetValue("a"+step,out next)||String.IsNullOrEmpty(next)||next=="finish"){
    quest.State="finished";GrantExperience(player,100);Record("quest_finished",player.Id,quest.Id,100);return;
   }
   if(next.StartsWith("sms")){quest.Message=next;Record("quest_message",player.Id,quest.Id,0);World.Events[World.Events.Count-1].Text=next;continue;}
   if(next=="goto_rnd"){
    string room=null;
    if(quest.Name.StartsWith("special_")){string name=quest.Name.Substring(8);foreach(var box in World.Containers.Values)if(box.Name==name&&!box.Used){room=box.Room;break;}if(room==null)foreach(var obj in World.Interactives.Values)if(obj.Name==name&&!obj.Used){room=obj.Room;break;}}
    if(room==null){int floor=FloorNumber(player.Room)-random.Next(5,10);if(floor<2)floor=Math.Min(99,FloorNumber(player.Room)+random.Next(5,10));room="floor_"+floor+"/room_"+(random.Next(2)==0?"left":"right");}
    if(!World.Rooms.ContainsKey(room)){quest.State="0";return;}quest.TargetRoom=room;string side=room.Split('/')[1].Replace("room_","").Substring(0,1);quest.Steps["a"+step]="goto_"+side+"_"+FloorNumber(room);
    string enemyName;Enemy template;if(quest.Steps.TryGetValue("a"+(step+1),out enemyName)&&enemyName.StartsWith("enemy_")&&World.EnemyTemplates.TryGetValue(enemyName,out template)){
     string id="quest_enemy:"+quest.Id+":"+step;var enemy=Json.Copy(template);enemy.Id=id;enemy.Room=room;enemy.Looted=false;World.Enemies[id]=enemy;World.Containers[id]=new Container{Id=id,EnemyId=id,Name=enemyName,Room=room};
    }
    Record("quest_target",player.Id,quest.Id,0);return;
   }
   return;
  }
 }
}
}
