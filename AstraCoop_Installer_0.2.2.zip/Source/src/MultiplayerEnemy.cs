using System;
using System.Collections.Generic;
using UnityEngine;
namespace AstraCoop {
// Presentation only. Network health/events own combat; no native enemy turns or
// animation-event callbacks are allowed to mutate gameplay from this adapter.
public sealed class MultiplayerEnemy {
 sealed class Visual {public SkeletonAnimation Skeleton;public Spine.AnimationState Owned;public string Clip;public float Elapsed,Duration;public bool Loop,Finished,Shadow;}
 readonly BaseEnemy source;readonly List<Visual> visuals=new List<Visual>();
 bool ready,dead,corpse;string mode="idle";long lastEvent;
 public string AnimationName {get{return visuals.Count==0?null:visuals[0].Clip;}}
 public float AnimationTime {get{return visuals.Count==0?0:visuals[0].Elapsed;}}
 public bool IsCorpse {get{return corpse;}}
 public MultiplayerEnemy(BaseEnemy native){source=native;}
 bool Bind(){
  if(source==null)return false;
  var assistant=source.GetComponent<EnemyAnimsAssistant>();var main=assistant==null?null:assistant.mainAnimation;
  if(main==null)foreach(var candidate in source.GetComponentsInChildren<BaseSkeletonAnimation>(true))if(!candidate.name.ToLowerInvariant().Contains("shadow")){main=candidate;break;}
  if(main==null)return false;
  var seen=new HashSet<BaseSkeletonAnimation>();var graph=main;
  while(graph!=null&&seen.Add(graph)){
   var skeleton=graph.getSkeletonAnimation()??graph.GetComponent<SkeletonAnimation>();
   if(skeleton==null||skeleton.skeletonDataAsset==null)return false;
   for(Transform t=graph.transform;t!=null&&t!=source.transform;t=t.parent)t.gameObject.SetActive(true);
   graph.enabled=false;skeleton.enabled=false;skeleton.Reset();
   if(skeleton.skeleton==null||skeleton.state==null)return false;
   var owned=new Spine.AnimationState(skeleton.skeletonDataAsset.GetAnimationStateData());skeleton.state=owned;skeleton.timeScale=1;
   var renderer=skeleton.GetComponent<Renderer>();if(renderer!=null)renderer.enabled=true;
   visuals.Add(new Visual{Skeleton=skeleton,Owned=owned,Shadow=visuals.Count>0});
   graph=graph.connectedAnimation;
  }
  ready=visuals.Count>0;return ready;
 }
 public void Sync(Enemy state){
  if(state==null||source==null)return;
  source.health=(float)state.Health;source.isDead=state.Health<=0;
  if(!ready){visuals.Clear();if(!Bind())return;dead=state.Health<=0;corpse=dead;Play(dead?"corpse":"idle");}
  else if(state.Health<=0&&!dead){dead=true;corpse=false;Play("death");Sound("death");}
 }
 public void Present(GameEvent ev,Enemy state){
  if(ev==null||ev.Id<=lastEvent)return;lastEvent=ev.Id;
  Sync(state);if(!ready)return;
  if(ev.Kind=="enemy_death"){if(!dead){dead=true;corpse=false;Play("death");Sound("death");}return;}
  if(dead)return;
  if(ev.Kind=="enemy_attack"||ev.Kind=="enemy_miss"){Play("hit");Sound("hit");}
  else if(ev.Kind=="attack_hit"&&state!=null&&state.Health>0){Play("hurt");Sound("hurt");}
 }
 void Sound(string suffix){var sounds=source.GetComponent<EventSounds>();if(sounds!=null)sounds.ReceiveEvent(source.enemyType+"_"+suffix);}
 string Choose(Visual v,string action){
  var data=v.Skeleton.skeletonDataAsset.GetSkeletonData(false);string[] names;
  if(action=="corpse")names=source.deadAnimName=="dead2"?new[]{"dead2","dead","death"}:new[]{"dead","dead2","death"};
  else if(action=="death")names=new[]{"death","death2","dead"};
  else if(action=="hit")names=new[]{"hit","attack","idle"};
  else if(action=="hurt")names=new[]{"hurt","idle"};
  else names=new[]{"idle","stand"};
  foreach(string name in names)if(data.FindAnimation(name)!=null)return name;
  return null;
 }
 void Play(string action){
  mode=action;
  foreach(var v in visuals){
   if(v.Skeleton==null)continue;
   string clip=Choose(v,action);if(clip==null)continue;
   v.Clip=clip;v.Elapsed=0;v.Finished=false;v.Loop=action=="idle";
   v.Skeleton.skeleton.SetToSetupPose();
   v.Owned=new Spine.AnimationState(v.Skeleton.skeletonDataAsset.GetAnimationStateData());v.Skeleton.state=v.Owned;
   v.Owned.SetAnimation(0,clip,v.Loop);
   v.Duration=v.Owned.GetCurrent(0).Animation.Duration;
   if(action=="corpse"){v.Elapsed=v.Duration;v.Finished=true;}
   Pose(v);
   if(v.Shadow)v.Skeleton.gameObject.SetActive(action!="corpse");
  }
 }
 static void Pose(Visual v){
  var track=v.Owned.GetCurrent(0);if(track==null)track=v.Owned.SetAnimation(0,v.Clip,v.Loop);
  track.Time=v.Elapsed;
  v.Skeleton.state=v.Owned;
  v.Owned.Apply(v.Skeleton.skeleton);
  v.Skeleton.skeleton.UpdateWorldTransform();
  v.Skeleton.LateUpdate();
 }
 public void Advance(float delta){
  if(!ready||source==null||!source.gameObject.activeInHierarchy)return;
  bool completed=false;
  foreach(var v in visuals){
   if(v.Skeleton==null||v.Shadow&&corpse)continue;
   // Native pause flags, speed callbacks and mouse callbacks must never freeze
   // or reset this owned track. Skeleton.Update is called exactly once here.
   v.Skeleton.enabled=false;v.Skeleton.timeScale=1;
   if(v.Skeleton.state!=v.Owned){v.Skeleton.state=v.Owned;v.Owned.Apply(v.Skeleton.skeleton);v.Skeleton.skeleton.UpdateWorldTransform();}
   if(!v.Finished){
    v.Elapsed+=Math.Max(0,delta);
    if(!v.Loop&&v.Elapsed>=v.Duration){v.Elapsed=v.Duration;v.Finished=true;if(!v.Shadow)completed=true;}
   }
   Pose(v);
  }
  if(completed){if(mode=="death"){corpse=true;Play("corpse");}else if(!dead&&mode!="idle")Play("idle");}
 }
}
}
