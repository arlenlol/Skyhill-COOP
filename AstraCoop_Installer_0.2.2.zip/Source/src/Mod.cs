using System;
using System.IO;
using System.Net;
using System.Reflection;
using MelonLoader;
using HarmonyLib;
using UnityEngine;
[assembly:MelonInfo(typeof(AstraCoop.Mod),"Astra SKYHILL Coop","0.2.2","Astra")]
[assembly:MelonGame("DefaultCompany","SKYHILL")]
namespace AstraCoop {
public sealed class Mod:MelonMod {
 static Mod instance;
 public static bool UseNativeUi {get{return instance!=null&&instance.settings!=null&&instance.settings.NativeUi;}}
 public static bool Active,Isolated;public static string DataPath;
 Session session;Server server;Client client;NativeBridge bridge;World view;Settings settings;
 string name="Player",host="127.0.0.1",password="",status="",memberId,actorId,follow,chat="",capacity="16",port="28765";
 bool spectator,show=true,typing,clientAttached;int attachDelay;long sequence=1;double nextSave,nextView;
 Vector2 listScroll,chatScroll;Rect window=new Rect(12,12,390,620);bool inventory,recipes;
 int testStage;bool testHost,testClient;long lastChat;bool followChat=true;
 // Local mouse-driven navigation. Only the server advances the authoritative actor.
 string mouseUnlockDestination;float mouseUnlockSince;
 string mouseDestination,mousePending,mouseClickLast;int mouseClickFrame=-1;
 float mousePendingSince;
 static double Now{get{return System.Diagnostics.Stopwatch.GetTimestamp()/(double)System.Diagnostics.Stopwatch.Frequency;}}
 public override void OnApplicationStart(){
  instance=this;
  DataPath=Path.Combine(Path.Combine(Environment.CurrentDirectory,"UserData"),"AstraCoop");Directory.CreateDirectory(DataPath);
  string config=Path.Combine(DataPath,"settings.json");settings=File.Exists(config)?Json.Read<Settings>(File.ReadAllText(config)):new Settings{ApiKey=Session.Secret()};
  if(String.IsNullOrEmpty(settings.ApiKey))settings.ApiKey=Session.Secret();
  // Mouse control must not silently turn off the entire native HUD. Migrate
  // configurations created by the earlier experimental NativeUi=false build.
  if(!settings.NativeUi){settings.NativeUi=true;LoggerInstance.Msg("AstraCoop: enabling original SKYHILL UI (inventory, Escape, HP and hunger).");}
  File.WriteAllText(config,Json.Write(settings));capacity=settings.MaxPlayers.ToString();port=settings.LanPort.ToString();password=settings.Password;
  NativeInterface.Send=Send;NativeInterface.Leave=LeaveSession;
  var h=new HarmonyLib.Harmony("astra.skyhill.coop");
  h.Patch(typeof(NotificationCenter).GetMethod("postNotification"),new HarmonyMethod(typeof(Mod).GetMethod("AllowNative")));
  h.Patch(typeof(DbManager).GetMethod("getSavesFolderPath",BindingFlags.NonPublic|BindingFlags.Instance),new HarmonyMethod(typeof(Mod).GetMethod("SaveDirectory")));
  h.Patch(typeof(AreaClick).GetMethod("OnMouseUp",BindingFlags.NonPublic|BindingFlags.Instance),new HarmonyMethod(typeof(Mod).GetMethod("RoomClick")));
  if(settings.NativeUi)NativeInterface.Install(h);NativeInterface.InstallProgression(h);
  if(Array.IndexOf(Environment.GetCommandLineArgs(),"--astra-test")>=0||File.Exists(Path.Combine(Environment.CurrentDirectory,"astra-test-isolation.flag"))){PrepareIsolation();Isolated=true;}
  testHost=Isolated&&File.Exists(Path.Combine(Environment.CurrentDirectory,"astra-test-host.flag"));
  testClient=Isolated&&File.Exists(Path.Combine(Environment.CurrentDirectory,"astra-test-client.flag"));
  LoggerInstance.Msg("Astra loaded. F9 opens session controls; no session is started automatically.");
 }
 public static bool AllowNative(string notificationName,UnityEngine.Object arg){return UseNativeUi?NativeInterface.Dispatch(notificationName,arg):!Active;}
 public static bool RoomClick(AreaClick __instance){
  if(!Active)return true;
  if(instance!=null)instance.HandleRoomClick(NativeBridge.AreaId(__instance.gameObject));
  return false;
 }
 bool NativeModal(){var ui=GameObject.Find("UI");var game=ui==null?null:ui.GetComponent<GameUI_PC>();return game!=null&&game._isModal;}
 bool MouseBlocked(){
  if(typing||!Active||view==null||String.IsNullOrEmpty(actorId))return true;
  if(show&&window.Contains(new Vector2(Input.mousePosition.x,Screen.height-Input.mousePosition.y)))return true;
  if(UseNativeUi){var ui=GameObject.Find("UI");if(ui!=null){var controller=ui.GetComponent<GameUI_PC>();if(controller!=null&&controller._isModal)return true;}}
  return false;
 }
 void HandleRoomClick(string destination){
  if(MouseBlocked()||String.IsNullOrEmpty(destination))return;
  // Both Unity OnMouseUp and tk2d OnClick can fire for the same room.
  if(mouseClickFrame==Time.frameCount&&mouseClickLast==destination)return;
  mouseClickFrame=Time.frameCount;mouseClickLast=destination;
  if(mouseDestination==destination)return;
  Actor actor;if(!view.Actors.TryGetValue(actorId,out actor)||!actor.Alive)return;
  Room locked;if(view.Rooms.TryGetValue(destination,out locked)&&locked.Locked){foreach(Interactive door in view.Interactives.Values)if(door.Kind=="lock"&&door.UnlockRoom==destination&&door.Room==actor.Room){mouseUnlockDestination=destination;mouseUnlockSince=Time.realtimeSinceStartup;Send("interact",door.Id);if(session!=null&&session.World.Rooms[destination].Locked)mouseUnlockDestination=null;return;}}
  var path=MouseRoute.Find(view,actor.Room,destination);
  if(path==null){status="До комнаты нет доступного маршрута: "+destination;LoggerInstance.Msg("Mouse route rejected: "+actor.Room+" -> "+destination);return;}
  mouseDestination=destination;mousePending=null;
  if(path.Count==0){mouseDestination=null;return;}
  status="Маршрут мышью: "+path.Count+" переход(ов)";LoggerInstance.Msg("Mouse route: "+actor.Room+" -> "+destination+" ("+path.Count+" hops)");
  TickMouseNavigation();
 }
 void TickMouseNavigation(){
  if(mouseUnlockDestination!=null&&view!=null){Room room;if(view.Rooms.TryGetValue(mouseUnlockDestination,out room)&&!room.Locked){string destination=mouseUnlockDestination;mouseUnlockDestination=null;HandleRoomClick(destination);}else if(Time.realtimeSinceStartup-mouseUnlockSince>5)mouseUnlockDestination=null;}
  if(mouseDestination==null||view==null||actorId==null)return;
  Actor actor;if(!view.Actors.TryGetValue(actorId,out actor)||!actor.Alive){CancelMouseNavigation();return;}
  if(mousePending!=null){
   if(actor.Room==mousePending){mousePending=null;}
   else if(Time.realtimeSinceStartup-mousePendingSince>5f){status="Сервер не подтвердил переход в "+mousePending;CancelMouseNavigation();}
   else return;
  }
  if(actor.Room==mouseDestination){CancelMouseNavigation();return;}
  if(view.ServerTime<actor.MovingUntil||view.ServerTime<actor.NextMove)return;
  var route=MouseRoute.Find(view,actor.Room,mouseDestination);
  if(route==null||route.Count==0){status="Маршрут недоступен";CancelMouseNavigation();return;}
  if(route.Count>1)foreach(Enemy enemy in view.Enemies.Values)if(enemy.Room==actor.Room&&enemy.Health>0){status="Маршрут остановлен: враг в комнате";CancelMouseNavigation();return;}
  mousePending=route[0];mousePendingSince=Time.realtimeSinceStartup;
  Send("move",mousePending);
  // Host executes immediately. Do not keep navigating after a rejected move.
  if(session!=null&&session.World.Actors.ContainsKey(actorId)&&session.World.Actors[actorId].Room!=mousePending){
   CancelMouseNavigation();
  }
 }
 void CancelMouseNavigation(){mouseDestination=null;mousePending=null;mouseUnlockDestination=null;}
 public static bool ObjectClick(BaseInteractiveComponent __instance){
  if(!Active)return true;
  if(instance!=null)instance.HandleObjectClick(__instance);
  return false;
 }
 void HandleObjectClick(BaseInteractiveComponent obj){
  if(obj==null||MouseBlocked()||actorId==null)return;
  CancelMouseNavigation();
  Actor player;if(view==null||!view.Actors.TryGetValue(actorId,out player)||!player.Alive)return;
  string objectRoom=NativeBridge.SceneRoom(obj.transform);if(objectRoom!=null&&player.Room!=objectRoom){HandleRoomClick(objectRoom);return;}
  if(view.ServerTime<player.MovingUntil)return;
  string id=NativeBridge.ObjectId(obj);
  if(lastObjectId==id&&Time.realtimeSinceStartup-lastObjectTime<0.35f)return;
  lastObjectId=id;lastObjectTime=Time.realtimeSinceStartup;
  foreach(Enemy living in view.Enemies.Values)if(living.Room==player.Room&&living.Health>0&&!(obj is BaseEnemy))return;
  if(obj is Bed){if(player.Room=="Home")NotificationCenter.getI.postNotification("uiShowSleepingManager",obj);return;}
  if(obj is Workbranch){if(player.Room=="Home")NotificationCenter.getI.postNotification("showInventory",obj);return;}
  if(bridge!=null&&bridge.OpenInteractive(obj,view,player))return;
  Enemy enemy;var nativeEnemy=obj as BaseEnemy;
  if(nativeEnemy!=null&&id!=null&&view.Enemies.TryGetValue(id,out enemy)&&enemy.Health>0){
   if(player.Room!=enemy.Room){status="Враг находится в другой комнате";return;}
   // Native SKYHILL displays the body-zone chooser. NativeInterface.Attack
   // sends the selected zone as the authoritative network command.
   if(UseNativeUi&&bridge!=null)bridge.ShowAttackUI(nativeEnemy);
   else status="Откройте окно боя в игре";
  }else if(id!=null)Send("interact",id);
 }
 public static bool SaveDirectory(ref string __result){if(!Isolated)return true;__result=Path.Combine(DataPath,"NativeCache");Directory.CreateDirectory(__result);return false;}
 static void PrepareIsolation(){
  string source=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Daedalic Entertainment GmbH/Skyhill/Savegames");
  string target=Path.Combine(DataPath,"NativeCache");Directory.CreateDirectory(target);
  foreach(string file in new[]{"Db.xml","DbScheme.xml"})if(File.Exists(Path.Combine(source,file))&&!File.Exists(Path.Combine(target,file)))File.Copy(Path.Combine(source,file),Path.Combine(target,file));
 }
 public override void OnSceneWasInitialized(int buildIndex,string sceneName){if((clientAttached||session!=null)&&sceneName=="House")attachDelay=60;}
 public override void OnUpdate(){
  if(Input.GetKeyDown(KeyCode.F9)&&!typing)show=!show;
  try{
   if(testHost&&testStage==0&&Application.loadedLevelName=="main_menu"){testStage=1;Application.LoadLevel("House");}
   else if(testHost&&testStage==1&&NativeBridge.Ready()){testStage=2;spectator=true;settings.EnableApi=true;Host(File.Exists(Path.Combine(DataPath,"coop-save.json")));if(session!=null){session.World.Started=true;LoggerInstance.Msg("INTEGRATION HOST READY: rooms="+session.World.Rooms.Count+" enemies="+session.World.Enemies.Count);}}
   if(testClient&&testStage==0&&Application.loadedLevelName=="main_menu"){testStage=1;name="LAN Client";Connect(false);}
   if(testClient&&testStage==1&&Active){testStage=2;Send("move","floor_99/room_center");Send("chat",null,0,"Сообщение из второго экземпляра SKYHILL");}
   if(session!=null){server.Pump(session,Now,32);if(Active)session.Tick(Now);if(Now>=nextView){view=session.View();nextView=Now+0.1;}if(Now>=nextSave){Persistence.Save(session,Path.Combine(DataPath,"coop-save.json"),Now);nextSave=Now+30;}}
   if(client!=null){
    if(client.Error!=null)status=client.Error;
    if(client.Welcome!=null&&client.Welcome.Ok&&!clientAttached){
     Active=false;bridge=null;
     memberId=client.Welcome.MemberId;actorId=client.Welcome.ActorId;follow=actorId;view=client.Welcome.State;
     File.WriteAllText(Path.Combine(DataPath,"resume-"+SafeHost()+".json"),Json.Write(client.Token));
     PrepareIsolation();Isolated=true;NativeBridge.Import(client.Welcome.Bootstrap);clientAttached=true;attachDelay=120;Application.LoadLevel("House");
    }
    if(clientAttached&&client.Latest!=null&&client.Latest.State!=null)view=client.Latest.State;
   }
   if((clientAttached||session!=null)&&!Active&&attachDelay>0){attachDelay--;if(attachDelay==0){if(NativeBridge.Ready()){
    bridge=new NativeBridge();if(session!=null)bridge.UpgradeSave(session.World);if(session!=null)bridge.ConfigureLoot(session);bridge.Attach(HandleRoomClick);Active=true;show=actorId==null||view==null||!view.Started;
   }else attachDelay=30;}}
   if(Active&&bridge!=null&&view!=null){
    // Physics fallback for versions in which OnMouseUp is not delivered by the scene.
    // tk2d OnClick is also bound in NativeBridge.Attach.
    if(Input.GetMouseButtonUp(0)&&!MouseBlocked())bridge.TryMouseRaycast(Input.mousePosition,HandleRoomClick,HandleObjectClick);
    Actor local=null;if(actorId!=null)view.Actors.TryGetValue(actorId,out local);if(local==null&&follow!=null)view.Actors.TryGetValue(follow,out local);NativeInterface.Refresh(view,local);NativeInterface.Typing=typing;Actor controlled;if(actorId!=null&&view.Actors.TryGetValue(actorId,out controlled)&&controlled.Alive)follow=actorId;bridge.Render(view,follow);TickMouseNavigation();if(view.ChatSequence!=lastChat){lastChat=view.ChatSequence;if(followChat)chatScroll.y=Single.MaxValue;}}
  }catch(Exception e){status=e.GetType().Name+": "+e.Message;LoggerInstance.Error(e.ToString());}
 }
 string lastObjectId;float lastObjectTime;
 string SafeHost(){return BitConverter.ToString(System.Security.Cryptography.SHA256.Create().ComputeHash(System.Text.Encoding.UTF8.GetBytes(host+":"+port))).Replace("-","").Substring(0,16);}
 void Host(bool load){
  if(!load&&!NativeBridge.Ready()){status="Сначала загрузите забег SKYHILL (Продолжить или Новая игра).";return;}
  int n,p;if(!Int32.TryParse(capacity,out n)||n<1||n>1000||!Int32.TryParse(port,out p)||p<1024||p>65535){status="Проверьте число игроков и порт (1024–65535).";return;}
  settings.MaxPlayers=n;settings.LanPort=p;settings.Password=password;PrepareIsolation();Isolated=true;
  Application.runInBackground=true;
  bridge=new NativeBridge();session=load?Persistence.Load(Path.Combine(DataPath,"coop-save.json"),Now):new Session(bridge.Capture(),settings,Environment.TickCount);
  if(load){session.Settings.NativeUi=settings.NativeUi;settings=session.Settings;p=settings.LanPort;n=settings.MaxPlayers;password=settings.Password;}
  server=new Server(n+settings.MaxSpectators+8);
  try{server.Listen(IPAddress.Any,p,false);if(settings.EnableApi)server.Listen(IPAddress.Loopback,settings.ApiPort,true);}catch{server.Dispose();server=null;session=null;throw;}
  string tokenFile=Path.Combine(DataPath,"host-resume.json");string resume=load&&File.Exists(tokenFile)?Json.Read<string>(File.ReadAllText(tokenFile)):null;
  Reply welcome=session.Join(new Command{Op="join",Name=name,Role=load&&resume==null?"spectator":spectator?"spectator":"player",Password=password,Token=resume},false);
  if(!welcome.Ok){server.Dispose();server=null;session=null;status=welcome.Code;return;}
  memberId=welcome.MemberId;actorId=welcome.ActorId;follow=actorId;view=welcome.State;
  sequence=welcome.NextSequence;if(welcome.Token!=null)File.WriteAllText(tokenFile,Json.Write(welcome.Token));
  File.WriteAllText(Path.Combine(DataPath,"settings.json"),Json.Write(settings));
  if(load){NativeBridge.Import(session.World.NativeXml);attachDelay=120;Application.LoadLevel("House");}else{if(session!=null)bridge.ConfigureLoot(session);bridge.Attach(HandleRoomClick);Active=true;show=actorId==null||view==null||!view.Started;}
  nextSave=Now+30;status="Лобби открыто: TCP "+p+". Передайте гостям IPv4 хоста и пароль.";
 }
 void Connect(bool resume){
  int p;if(!Int32.TryParse(port,out p)||p<1||p>65535){status="Неверный порт";return;}
  if(client!=null)client.Dispose();client=new Client();string token=null;string file=Path.Combine(DataPath,"resume-"+SafeHost()+".json");if(resume&&File.Exists(file))token=Json.Read<string>(File.ReadAllText(file));
  clientAttached=false;
  Application.runInBackground=true;
  client.Connect(host,p,new Command{Op="join",Name=name,Role=spectator?"spectator":"player",Password=password,Token=token});status="Подключение…";
 }
 void LeaveSession(){
  if(session!=null)Persistence.Save(session,Path.Combine(DataPath,"coop-save.json"),Now);
  if(server!=null)server.Dispose();if(client!=null)client.Dispose();
  if(bridge!=null)bridge.DetachMouse();CancelMouseNavigation();
  server=null;client=null;session=null;bridge=null;view=null;Active=false;clientAttached=false;attachDelay=0;show=true;typing=false;NativeInterface.Refresh(null,null);
 }
 void Send(string op,string target=null,int zone=0,string text=null){
  var c=new Command{Op=op,Target=target,Zone=zone,Text=text,Sequence=sequence};
  if(session!=null){Reply r=session.Execute(memberId,c,Now);if(r.NextSequence>0)sequence=r.NextSequence;status=r.Ok?"":r.Code;view=session.View();}else if(client!=null)client.Send(c);
 }
 public override void OnGUI(){
  GUI.skin.label.wordWrap=true;GUI.skin.label.richText=false;
  if(Event.current.type==EventType.KeyDown){
   if(Event.current.keyCode==KeyCode.Return&&Active&&(typing||!NativeModal())){if(typing||GUI.GetNameOfFocusedControl()=="AstraChat"){if(chat.Trim().Length>0)Send("chat",null,0,chat);chat="";typing=false;GUI.FocusControl("");}else{typing=true;show=true;}Event.current.Use();}
   else if(Event.current.keyCode==KeyCode.Escape&&typing){typing=false;chat="";Event.current.Use();}
  }
  if(Active&&view!=null&&view.GameOver){
   Rect bounds=new Rect(Screen.width*0.5f-200,Screen.height*0.5f-95,400,190);
   GUI.Box(bounds,"КООПЕРАТИВНЫЙ ЗАБЕГ ОКОНЧЕН");
   GUI.Label(new Rect(bounds.x+24,bounds.y+50,bounds.width-48,50),view.CompletedEnding==null?"Все игроки погибли. Сохранение кооператива завершено.":"Забег завершён: "+view.CompletedEnding);
   if(view.CompletedEnding!=null&&GUI.Button(new Rect(bounds.x+90,bounds.y+82,220,34),"Смотреть концовку")){
    string ending=view.CompletedEnding;LeaveSession();CutscenesManager.getI.cutsceneForShow=ending;CutscenesManager.getI.isEnd=true;CutscenesManager.getI.isShowcaseMode=false;Application.LoadLevel("CutscenesShowcase");return;
   }
   if(GUI.Button(new Rect(bounds.x+90,bounds.y+122,220,38),"В главное меню")){
    LeaveSession();Application.LoadLevel("main_menu");
   }
   return;
  }
  if(Active&&view!=null&&actorId!=null&&!view.GameOver){Actor me;
   if(view.Actors.TryGetValue(actorId,out me)&&!me.Alive)
    GUI.Label(new Rect(Screen.width*0.5f-190,18,380,32),"Персонаж погиб — режим наблюдателя (F9)");
  }
  if(!show&&!typing)return;
  if(Active&&UseNativeUi&&!typing){var ui=GameObject.Find("UI");if(ui!=null){var controller=ui.GetComponent<GameUI_PC>();if(controller!=null&&controller._isModal)return;}}
  window=GUILayout.Window(91872,window,Draw,"ASTRA • SKYHILL COOP 0.2.2",GUILayout.Width(390));
 }
 void Draw(int id){
  try{
   GUILayout.Label(status,GUILayout.Width(365));
   if(Active&&client!=null&&client.Error!=null&&GUILayout.Button("Переподключиться своим персонажем"))Connect(true);
   if(!Active){
    GUILayout.Label("Имя");name=GUILayout.TextField(name,32);GUILayout.Label("Адрес хоста (IPv4 / имя)");host=GUILayout.TextField(host,128);
    GUILayout.Label("TCP-порт");port=GUILayout.TextField(port,5);GUILayout.Label("Пароль сессии");password=GUILayout.PasswordField(password,'*',64);
    spectator=GUILayout.Toggle(spectator,"Войти наблюдателем");GUILayout.Label("Максимум игроков");capacity=GUILayout.TextField(capacity,4);
    settings.EnableApi=GUILayout.Toggle(settings.EnableApi,"Локальный API (ключ в settings.json)");
    if(GUILayout.Button("Создать LAN-лобби из открытого забега"))Host(false);
    if(File.Exists(Path.Combine(DataPath,"coop-save.json"))&&GUILayout.Button("Загрузить кооперативное сохранение"))Host(true);
    if(GUILayout.Button("Подключиться"))Connect(false);
    if(GUILayout.Button("Переподключиться своим персонажем"))Connect(true);
    GUILayout.Label("Загрузите одиночную сцену перед созданием лобби. Кооператив использует отдельные сохранения.");
   }else if(view!=null){
    if(session!=null&&!view.Started&&GUILayout.Button("Начать кооператив")){session.World.Started=true;session.World.Revision++;view=session.View();if(actorId!=null)show=false;}
    if(view.GameOver)GUILayout.Label("GAME OVER — все персонажи погибли");
    GUILayout.BeginHorizontal();inventory=GUILayout.Toggle(inventory,"Инвентарь");recipes=GUILayout.Toggle(recipes,"Крафт");GUILayout.EndHorizontal();
    listScroll=GUILayout.BeginScrollView(listScroll,GUILayout.Height(310));
    foreach(Actor a in view.Actors.Values){if(GUILayout.Button(a.Name+" • "+RoomName(a.Room)+" • HP "+a.Health.ToString("0.0")+" • Еда "+a.Food.ToString("0.0")+(a.Alive?"":" • погиб")))follow=a.Id;}
    Actor player=null;if(actorId!=null)view.Actors.TryGetValue(actorId,out player);
    if(player!=null&&player.Alive){
     GUILayout.Label("Перемещение");foreach(string room in view.Rooms[player.Room].Neighbours)if(GUILayout.Button(RoomName(room)))Send("move",room);
     GUILayout.Label("Оружие: "+player.Weapon+" • Атака через "+Math.Max(0,player.NextAttack-view.ServerTime).ToString("0.0")+" с");
     if(Session.Stat(player,"free_skill_points")>0){GUILayout.Label("Очки навыков: "+Session.Stat(player,"free_skill_points"));foreach(string stat in new[]{"strength","dexterity","speed","accuracy"})if(GUILayout.Button(stat+" +1"))Send("upgrade",stat);}
     foreach(Enemy e in view.Enemies.Values)if(e.Room==player.Room&&e.Health>0){GUILayout.Label(e.Name+" • "+e.Health.ToString("0.0")+" HP");GUILayout.BeginHorizontal();for(int z=0;z<e.Chances.Length;z++)if(GUILayout.Button("Удар "+(z+1)))Send("attack",e.Id,z);GUILayout.EndHorizontal();}
     foreach(Interactive obj in view.Interactives.Values)if(obj.Room==player.Room&&!obj.Used){
      GUILayout.Label(obj.Name);
      if(obj.Kind=="trade"){GUILayout.Label(obj.OfferNeed+" → "+obj.OfferHave);if(GUILayout.Button("Обменять"))Send("trade",obj.Id);}
      else if(obj.Kind=="repair"){if(GUILayout.Button("Починить: "+obj.NeedItem))Send("repair",obj.Id);if(GUILayout.Button("Попробовать ремонт вручную"))Send("repair",obj.Id,1);}
      else if(obj.Kind!="quest"&&GUILayout.Button("Взаимодействовать"))Send("interact",obj.Id,0,obj.Kind=="machine"?"pay":null);
     }
     if(player.Room=="floor_-4/room_center"&&!view.BossDefeated){GUILayout.Label("Босс");GUILayout.BeginHorizontal();foreach(string direction in new[]{"left","center","right"})if(GUILayout.Button(direction))Send("boss",direction);GUILayout.EndHorizontal();}
     foreach(Container box in view.Containers.Values)if(box.Room==player.Room&&!box.Used)if(GUILayout.Button("Обыскать: "+box.Name))Send("interact",box.Id);
     foreach(Loot d in view.Drops.Values)if(d.Room==player.Room)if(GUILayout.Button("Поднять: "+d.Item))Send("pickup",d.Id);
    }
    if(inventory)foreach(var pair in view.Inventory){if(pair.Value<=0)continue;GUILayout.Label(pair.Key+" × "+pair.Value);if(player!=null&&player.Alive){GUILayout.BeginHorizontal();if(GUILayout.Button("Использовать"))Send(view.Items[pair.Key].Type=="weapon"?"equip":"use",pair.Key);if(GUILayout.Button("Выбросить"))Send("drop",pair.Key);GUILayout.EndHorizontal();}}
    if(recipes&&player!=null&&player.Alive)foreach(Recipe recipe in view.Recipes.Values)if(recipe.Known&&GUILayout.Button("Создать "+recipe.Result))Send("craft",recipe.Id);
    GUILayout.EndScrollView();
    followChat=GUILayout.Toggle(followChat,"Чат • Enter / Escape • следить за новыми");chatScroll=GUILayout.BeginScrollView(chatScroll,GUILayout.Height(130));
    foreach(Chat message in view.Chat)GUILayout.Label("["+message.SenderName+"]: "+message.Text,GUILayout.Width(340));GUILayout.EndScrollView();
    GUI.SetNextControlName("AstraChat");chat=GUILayout.TextField(chat,512);if(typing)GUI.FocusControl("AstraChat");
    if(GUILayout.Button("Отправить")&&chat.Trim().Length>0){Send("chat",null,0,chat);chat="";}
    if(session!=null&&GUILayout.Button("Сохранить кооператив")){Persistence.Save(session,Path.Combine(DataPath,"coop-save.json"),Now);status="Сохранено";}
    if(GUILayout.Button("Выйти из кооператива")){LeaveSession();Application.LoadLevel("main_menu");}
   }
  }catch(Exception e){status=e.Message;LoggerInstance.Error(e.ToString());}
  GUI.DragWindow(new Rect(0,0,390,20));
 }
 static string RoomName(string id){if(id=="Home")return "Пентхаус";string[] parts=id.Split('/');return parts[0].Replace("floor_","Этаж ")+" — "+(id.EndsWith("left")?"слева":id.EndsWith("right")?"справа":"лестница");}
 public override void OnApplicationQuit(){if(session!=null)try{Persistence.Save(session,Path.Combine(DataPath,"coop-save.json"),Now);}catch(Exception e){LoggerInstance.Error(e.Message);}if(server!=null)server.Dispose();if(client!=null)client.Dispose();}
}
}
