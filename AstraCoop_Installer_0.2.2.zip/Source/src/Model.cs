using System;
using System.Collections.Generic;
namespace AstraCoop {
public sealed class Settings {
 public int MaxPlayers=16, MaxSpectators=32, LanPort=28765, ApiPort=28766;
 public bool NativeUi=true;
 public bool AllowSpectators=true, SpectatorChat=true, EnableApi=false;
 public string Password="", ApiKey="";
}
public sealed class Actor {
 public string Id,Name,Room,Weapon="hands"; public double Health,MaxHealth,Food,MaxFood;
 public double Hunger=1,HungerDamage=1,NextAttack,NextMove; public int MissCompensation=10;
 public string ActivePerk="",PerkState="ready";public int PerkMoves,LowestFloor=100;
 public string PassivePerk="",Skin="default",TravelKind="walk"; public int BossStep;
 public string QuickWeapon1="hands",QuickWeapon2="";
 public double OpeningAttackUntil;public double MovingUntil;
 public bool Poison; public Dictionary<string,double> Stats=new Dictionary<string,double>();
 public bool Alive {get{return Health>0;}}
}
public sealed class Room {
 public string Id; public bool Known,Locked; public bool HasLift,LiftEnabled,Electricity=true,Vip; public List<string> Neighbours=new List<string>();
 public Dictionary<string,double> TravelSeconds=new Dictionary<string,double>();
 public float X,Y,Z;
}
public sealed class Enemy {
 public string Id,Name,Room; public double Health,Damage,NextAttack; public int Experience;
 public double[] Chances,Multipliers; public bool Looted;
}
public sealed class Container {
 public bool NativeLoot;public string Id,Name,Room,EnemyId; public bool Used; public Dictionary<string,int> Loot=new Dictionary<string,int>();
}
public sealed class Item {
 public string Id,Type,Name,Storage; public double Min,Max,Strength,Dexterity,Speed,Food,Health;
}
public sealed class Recipe {
 public bool Known=true; public string UpgradeFacility; public int UpgradeLevel; public bool NeedHome; public string RequiredFacility; public int RequiredLevel;
 public string Id,Result; public Dictionary<string,int> Ingredients=new Dictionary<string,int>();
}
public sealed class Loot {
 public string Id,Room,Item; public int Count;
}
public sealed class Chat {
 public long Id; public string SenderId,SenderName,Text,Time;
}
public sealed class GameEvent {public string Text;public Dictionary<string,int> Items;public long Id;public string Kind,ActorId,TargetId,Time;public double Amount;}
public sealed class Counterattack {public string EnemyId,VictimId;public double At;}
public sealed class World {
 public List<Counterattack> PendingCounters=new List<Counterattack>();
 public bool SuppressEntryAttack;public int LootRulesVersion;public Dictionary<string,string> LootGeneratorState=new Dictionary<string,string>();
 public string NativeXml;
 public string CurrentEnding="end_1",CompletedEnding; public bool SecretUnlocked,BossDefeated;
 public Dictionary<string,Interactive> Interactives=new Dictionary<string,Interactive>();
 public Dictionary<string,int> Journal=new Dictionary<string,int>();
 public List<string> Recordings=new List<string>(),RecordingCatalog=new List<string>();
 public Dictionary<string,double> BedHealing=new Dictionary<string,double>();
 public Dictionary<string,Enemy> EnemyTemplates=new Dictionary<string,Enemy>();
 public Dictionary<string,QuestState> Quests=new Dictionary<string,QuestState>();
 public int Schema=2; public string SessionId=Guid.NewGuid().ToString("N");
 public bool Started,GameOver; public long Revision,ChatSequence,EventSequence;public double ServerTime;
 public string[] Actions={"move","attack","interact","pickup","equip","slot","use","drop","craft","upgrade","sleep","chat","state","trade","quest","repair","lift","boss","perk","recycle"};
 public Dictionary<string,Actor> Actors=new Dictionary<string,Actor>();
 public Dictionary<string,Room> Rooms=new Dictionary<string,Room>();
 public Dictionary<string,Enemy> Enemies=new Dictionary<string,Enemy>();
 public Dictionary<string,int> Inventory=new Dictionary<string,int>();
 public Dictionary<string,Item> Items=new Dictionary<string,Item>();
 public Dictionary<string,Recipe> Recipes=new Dictionary<string,Recipe>();
 public Dictionary<string,int> HomeProgress=new Dictionary<string,int>();
 public Dictionary<string,Loot> Drops=new Dictionary<string,Loot>();
 public Dictionary<string,Container> Containers=new Dictionary<string,Container>();
 public List<Chat> Chat=new List<Chat>(); public Actor Template;
 public List<GameEvent> Events=new List<GameEvent>();public double LevelUpHealing;
 public double SleepHealthPerFood;
 public double Difficulty=1,EnemyScatter=10,EnemyCritPercent,EnemyCritFactor;
}
public sealed class Interactive {
 public bool NativeLoot;public string QuestType; public string Id,Name,Room,Kind,State,NeedItem,OfferNeed,OfferHave,UnlockRoom,Destination;
 public bool Used; public Dictionary<string,int> Reward=new Dictionary<string,int>();
 public List<string> Products=new List<string>();
}
public sealed class QuestState {public string TargetRoom,Message,OwnerId; public string Id,Name,State; public Dictionary<string,string> Steps=new Dictionary<string,string>();}
public sealed class Member {
 public string Id,Name,TokenHash,ActorId; public long LastSequence; public Reply LastReply;
}
public sealed class Command {
 public int Version=2; public string Op,Name,Role,Password,Token,Target,Text;
 public long Sequence; public int Zone;
}
public sealed class Reply {
 public double Damage;public bool Hit;
 public string Bootstrap;
 public bool Ok; public string Code,Message,Token,MemberId,ActorId; public long NextSequence;
 public double RetryAfter; public World State;
 public static Reply Result(string code){return new Reply{Ok=code=="ok",Code=code};}
}
}
