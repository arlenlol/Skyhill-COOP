using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
namespace AstraCoop {
public sealed partial class NativeBridge {
 public void ConfigureLoot(Session session){
  if(level==null)IndexScene();
  var w=session.World;
  if(w.LootRulesVersion<1){foreach(Container box in w.Containers.Values)if(!box.Used){BaseInteractiveComponent native;box.NativeLoot=!objects.TryGetValue(box.Id,out native)||!(native is EnemyThird);box.Loot.Clear();}w.LootGeneratorState.Clear();w.LootRulesVersion=1;w.Revision++;}
  session.EntryAttackAllowed=delegate{return GameObject.Find("Tutorial")==null&&GameObject.Find("phone")==null;};
  RandomLootGenerator generator=null;
  session.GenerateLoot=delegate(Actor actor,string name,string room){
   World previous=NativeInterface.View;Actor player=NativeInterface.Player;
   NativeInterface.View=w;NativeInterface.Player=actor;
   try{
    ProjectProgression(w);
    if(generator==null){generator=new RandomLootGenerator();
    // Restore the native generator's adaptive probabilities and recent-item history.
    foreach(var pair in w.LootGeneratorState){var field=typeof(RandomLootGenerator).GetField(pair.Key,BindingFlags.Instance|BindingFlags.NonPublic);if(field==null)continue;
     if(field.FieldType==typeof(float))field.SetValue(generator,Json.Read<float>(pair.Value));
     else if(field.FieldType==typeof(bool))field.SetValue(generator,Json.Read<bool>(pair.Value));
     else if(field.FieldType==typeof(float[]))field.SetValue(generator,Json.Read<float[]>(pair.Value));
     else if(field.FieldType==typeof(ArrayList))field.SetValue(generator,new ArrayList(Json.Read<List<string>>(pair.Value)));
    }
    }
    var result=new Dictionary<string,int>();
    foreach(string id in generator.getLootForObject(name,Session.FloorNumber(room)))if(!String.IsNullOrEmpty(id)&&w.Items.ContainsKey(id)){int count;result.TryGetValue(id,out count);result[id]=count+1;}
    foreach(var field in typeof(RandomLootGenerator).GetFields(BindingFlags.Instance|BindingFlags.NonPublic))if(field.FieldType==typeof(float)||field.FieldType==typeof(bool)||field.FieldType==typeof(float[])||field.FieldType==typeof(ArrayList))w.LootGeneratorState[field.Name]=Json.Write(field.GetValue(generator));
    return result;
   }finally{NativeInterface.View=previous;NativeInterface.Player=player;}
  };
 }
}
}
