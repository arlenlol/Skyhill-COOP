using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using HarmonyLib;
using UnityEngine;
namespace AstraCoop {
// A read-only projection for the local native UI. Remote actors never execute UI
// callbacks against Character.getInstance(). All mutations go through Session.
public static partial class NativeInterface {
 public static World View;public static Actor Player;public static Action<string,string,int,string> Send;
 public static Action Leave;public static bool Typing;
 static readonly FieldInfo Callbacks=typeof(NotificationCenter).GetField("callback_storage",BindingFlags.NonPublic|BindingFlags.Instance);
 static void Patch(HarmonyLib.Harmony h,Type type,string method,string prefix){var m=type.GetMethod(method,BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance);if(m==null)throw new MissingMethodException(type.Name,method);h.Patch(m,new HarmonyMethod(typeof(NativeInterface).GetMethod(prefix)));}
 public static void Install(HarmonyLib.Harmony h){
  foreach(string method in new[]{"onSpeedBtn","onDexterityBtn","onStrengthBtn","onAccuracyBtn"})Patch(h,typeof(UI_PC_CharacterSpecifications),method,"Upgrade");
  h.Patch(typeof(UI_PC_ClickZone).GetMethod("refresh",BindingFlags.NonPublic|BindingFlags.Instance),null,new HarmonyMethod(typeof(NativeInterface).GetMethod("ActionIcon")));
  Patch(h,typeof(CharacterData),"checkInventoryContainsItem","ContainsItem");
  Patch(h,typeof(UI_PC_FightingItem),"setItemInInventory","EquipSlot");
  Patch(h,typeof(CharacterData),"get_fightingItemFirst","Slot");Patch(h,typeof(CharacterData),"get_fightingItemSecond","Slot");
  Patch(h,typeof(CharacterData),"getInventory","Inventory");Patch(h,typeof(CharacterData),"get_specs","Specs");Patch(h,typeof(CharacterData),"getSpecs","Specs");
  foreach(string field in new[]{"health","maxHealth","food","maxFood"})Patch(h,typeof(CharacterData),"get_"+field,"Number");
  Patch(h,typeof(CharacterData),"get_isPoison","Poison");
  foreach(string field in new[]{"floor_name","room_name","current_weapon"})Patch(h,typeof(CharacterData),"get_"+field,"Text");
  foreach(var prop in typeof(CharacterData).GetProperties())if(prop.GetSetMethod()!=null)h.Patch(prop.GetSetMethod(),new HarmonyMethod(typeof(NativeInterface).GetMethod("NoNativeMutation")));
  foreach(string method in new[]{"addInventoryItem","removeInventoryItem","swapInventoryItems","setAnySpec","useWeapon"})Patch(h,typeof(CharacterData),method,"NoNativeMutation");
  Patch(h,typeof(UI_PC_Inventory),"useItemHandler","Use");Patch(h,typeof(UI_PC_Craft),"craftItems","Craft");
  Patch(h,typeof(UI_PC_AttackZones),"zoneTouched","Attack");Patch(h,typeof(UI_PC_SleepingManager),"sleep","Sleep");
  Patch(h,typeof(UI_PC_GameplaySystemMenu),"toMainMenu","Exit");Patch(h,typeof(GameUI_PC),"Update","Keyboard");
 }
 public static bool Upgrade(MethodBase __originalMethod){if(!Mod.Active)return true;string stat=__originalMethod.Name.Substring(2);stat=stat.Substring(0,stat.Length-3).ToLowerInvariant();Send("upgrade",stat,0,null);return false;}
 public static bool NoNativeMutation(){return !Mod.Active;}
 static readonly FieldInfo ActionIconField=typeof(UI_PC_ClickZone).GetField("icon",BindingFlags.NonPublic|BindingFlags.Instance);
 public static void ActionIcon(UI_PC_ClickZone __instance){
  if(!Mod.Active)return;
  var icon=ActionIconField.GetValue(__instance) as GameObject;if(icon==null)return;
  bool markers=SettingsManager.getI.markers||Input.GetKey(KeyCode.Space)||Input.GetMouseButton(1);
  icon.SetActive(__instance.ShowActionIcon&&__instance.isActive&&!__instance.isLocked&&__instance.cursorState!="arrow"&&markers);
 }
 public static bool Keyboard(){return !Mod.Active||!Typing;}
 public static bool Dispatch(string name,UnityEngine.Object arg){
  if(!Mod.Active)return true;
  if(name=="showQuest"){ShowQuest(arg as QuestBeginer);return false;}
  if(name=="questCompleted"){
   Interactive state;if(View!=null&&InteractionId!=null&&View.Interactives.TryGetValue(InteractionId,out state)&&state.Kind=="quest"&&state.QuestType!="last")Send("quest",InteractionId,0,null);
   return false;
  }
  if(name=="weaponChangedByChanger"){var changer=arg as UI_PC_WeaponsChanger;if(changer!=null)Send("equip",changer.currentWeaponName,0,null);return false;}
  // Preserve native UI notifications, without triggering the original global turn,
  // hunger, save or quest callbacks. Snapshot because callbacks may unregister.
  var table=(Hashtable)Callbacks.GetValue(NotificationCenter.getI);var list=table[name] as ArrayList;if(list==null)return false;
  foreach(NotificationCenter.callback callback in list.ToArray()){
   var component=callback.Target as Component;if(component==null)continue;
   Transform parent=component.transform;bool ui=false;while(parent!=null){if(parent.name=="UI"){ui=true;break;}parent=parent.parent;}
   if(ui)callback(arg);
  }return false;
 }
 public static bool ContainsItem(string identity,ref int __result){if(!Mod.Active||View==null)return true;int i=0;__result=-1;foreach(var pair in View.Inventory)if(pair.Value>0){if(pair.Key==identity){__result=i;break;}i++;}return false;}
 public static bool Slot(MethodBase __originalMethod,ref string __result){if(!Mod.Active)return true;__result=Player==null?"hands":__originalMethod.Name=="get_fightingItemFirst"?ValidSlot(Player.QuickWeapon1):ValidSlot(Player.QuickWeapon2);return false;}
 public static bool EquipSlot(UI_PC_FightingItem __instance,string itemName_in){if(!Mod.Active)return true;Send("slot",itemName_in,__instance.name.Contains("1")?0:1,null);return false;}
 static string ValidSlot(string id){int n;return id=="hands"||(!String.IsNullOrEmpty(id)&&View.Inventory.TryGetValue(id,out n)&&n>0)?id:"";}
 public static bool Inventory(ref ArrayList __result){if(!Mod.Active||View==null)return true;__result=new ArrayList();foreach(var pair in View.Inventory)if(pair.Value>0){var row=new DbObject("character_inventory");row.setDataValue("identity",pair.Key);row.setDataValue("count",pair.Value);__result.Add(row);}return false;}
 public static bool Specs(ref DbObject __result){if(!Mod.Active||Player==null)return true;__result=new DbObject("character_specs");foreach(var pair in Player.Stats)__result.setDataValue(pair.Key,pair.Value.ToString(CultureInfo.InvariantCulture));return false;}
 public static bool Number(MethodBase __originalMethod,ref float __result){if(!Mod.Active||Player==null)return true;switch(__originalMethod.Name){case "get_health":__result=(float)Player.Health;break;case "get_maxHealth":__result=(float)Player.MaxHealth;break;case "get_food":__result=(float)Player.Food;break;default:__result=(float)Player.MaxFood;break;}return false;}
 public static bool Poison(ref bool __result){if(!Mod.Active||Player==null)return true;__result=Player.Poison;return false;}
 public static bool Text(MethodBase __originalMethod,ref string __result){if(!Mod.Active||Player==null)return true;string[] room=Player.Room.Split('/');__result=__originalMethod.Name=="get_current_weapon"?Player.Weapon:__originalMethod.Name=="get_floor_name"?room[0]:room.Length>1?room[1]:"Home";return false;}
 public static bool Use(object target){if(!Mod.Active)return true;var item=((GameObject)target).GetComponent<UI_PC_InventoryItem>();string id=item.model.getDataValue("identity");if(id.Contains("piece_of_photo_")||id=="maniac_photo")return true;Send(item.currentItemConfig["type"]=="weapon"?"equip":"use",item.model.getDataValue("identity"),0,null);return false;}
 public static bool Craft(UI_PC_Craft __instance){if(!Mod.Active)return true;
  var ingredients=new Dictionary<string,int>();foreach(string source in __instance._prePreparedItems){string id=source.Contains("f1")?"any_fruit":source.Contains("v1")?"any_veg":source;int n;ingredients.TryGetValue(id,out n);ingredients[id]=n+1;}
  foreach(Recipe recipe in View.Recipes.Values){if(!recipe.Known)continue;bool match=ingredients.Count==recipe.Ingredients.Count;foreach(var pair in recipe.Ingredients){int n;if(!ingredients.TryGetValue(pair.Key,out n)||n!=pair.Value)match=false;}if(match){Send("craft",recipe.Id,0,null);break;}}
  NotificationCenter.getI.postNotification("clearCraftSlots",__instance);return false;
 }
 public static bool Attack(UI_PC_AttackZones __instance,tk2dUIItem pressedZone_in){
  if(!Mod.Active)return true;
  // SKYHILL zone names follow zone_0/zone_1 etc. Never blindly parse
  // an arbitrary UI element name or send an invalid/out-of-range attack.
  int zone;string name=pressedZone_in==null?null:pressedZone_in.name;
  if(String.IsNullOrEmpty(name)||!name.StartsWith("zone_")||!Int32.TryParse(name.Substring(5),out zone))return false;
  Send("attack",NativeBridge.ObjectId(__instance.currentEnemy),zone,null);
  NotificationCenter.getI.postNotification("hideZonesAttackUI",__instance);return false;
 }
 public static bool Sleep(UI_PC_SleepingManager __instance){if(!Mod.Active)return true;int hours=(int)typeof(UI_PC_SleepingManager).GetField("numOfHours",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(__instance);Send("sleep",null,hours,null);NotificationCenter.getI.postNotification("uiHideSleepingManager",__instance);return false;}
 public static bool Exit(){if(!Mod.Active)return true;Leave();Application.LoadLevel("main_menu");return false;}
 // The native Character is intentionally deactivated in multiplayer. Drive its
 // original health/hunger HUD from the authoritative local actor snapshot.
 static string inventorySignature;
 static float nextHudRefresh;
 static string hudActor;
 static double hudHealth,hudFood,hudMaxHealth,hudMaxFood;
 static bool hudPoison;static string hudStats;
 public static void Refresh(World view,Actor player){
  View=view;Player=player;
  if(!Mod.Active||!Mod.UseNativeUi||player==null){hudActor=null;return;}
  string items=Json.Write(view.Journal)+Json.Write(view.Inventory)+"|"+player.Weapon+"|"+player.QuickWeapon1+"|"+player.QuickWeapon2;
  if(items!=inventorySignature){inventorySignature=items;var root=GameObject.Find("UI");if(root!=null){var inventory=root.transform.FindChild("Modal/Inventory");if(inventory!=null&&inventory.gameObject.activeInHierarchy){NotificationCenter.getI.postNotification("inventoryClear",null);NotificationCenter.getI.postNotification("inventoryLayoutItems",null);}NotificationCenter.getI.postNotification("refreshWeaponsChanger",null);}}
  float now=Time.realtimeSinceStartup;
  if(now<nextHudRefresh)return;
  string stats=Json.Write(player.Stats);
  bool changed=hudStats!=stats||hudActor!=player.Id||hudHealth!=player.Health||hudFood!=player.Food||hudMaxHealth!=player.MaxHealth||hudMaxFood!=player.MaxFood||hudPoison!=player.Poison;
  if(!changed&&now<nextHudRefresh+1.5f)return;
  // Updating this notification only reaches the original UI callbacks: the
  // NativeInterface.Dispatch Harmony prefix prevents singleton game mutations.
  // Do not use the Character singleton as the source of the snapshot.
  GameObject ui=GameObject.Find("UI");
  if(ui==null||!ui.activeInHierarchy)return;
  hudStats=stats;hudActor=player.Id;hudHealth=player.Health;hudFood=player.Food;hudMaxHealth=player.MaxHealth;hudMaxFood=player.MaxFood;hudPoison=player.Poison;
  nextHudRefresh=now+0.20f;
  NotificationCenter.getI.postNotification("updateCharacterStats",null);
 }
 }
}

