using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Xml;
using UnityEngine;
namespace AstraCoop {
public sealed partial class NativeBridge {
 static readonly FieldInfo Storage=typeof(DbManager).GetField("_customStorage",BindingFlags.Instance|BindingFlags.NonPublic);
 static readonly FieldInfo ObjectData=typeof(BaseInteractiveComponent).GetField("dbObj",BindingFlags.Instance|BindingFlags.NonPublic);
 readonly Dictionary<string,BaseInteractiveComponent> objects=new Dictionary<string,BaseInteractiveComponent>();
 readonly Dictionary<string,MultiplayerEnemy> enemyVisuals=new Dictionary<string,MultiplayerEnemy>();
 readonly Dictionary<string,MultiplayerCharacter> avatars=new Dictionary<string,MultiplayerCharacter>();
 long eventCursor;bool eventsInitialized;
 readonly Dictionary<tk2dUIItem,Action> roomClickHandlers=new Dictionary<tk2dUIItem,Action>();
 readonly Dictionary<string,Transform> rooms=new Dictionary<string,Transform>();
 string lastObservedRoom;bool lastObservedBattle;string lastObservedActor;int lastObservedEnemyCount=-1;
 // Floor and room click colliders are projections of the LOCAL actor's room.
 // Original RoomTrigger cannot run because the singleton hero is deactivated.
 readonly Dictionary<Collider,bool> originalRoomColliders=new Dictionary<Collider,bool>();
 readonly HashSet<Collider> locallyOccupiedColliders=new HashSet<Collider>();
 readonly Dictionary<BaseSkeletonAnimation,Action<BaseSkeletonAnimation>> animationResetHandlers=new Dictionary<BaseSkeletonAnimation,Action<BaseSkeletonAnimation>>();
 Transform level;GameObject heroGraphic;Character original;bool attached;
 public static string Export(){return ((CustomXMLStorage)Storage.GetValue(DbManager.instance)).getXML().OuterXml;}
 public static void Import(string xml){
  if(xml==null||xml.Length>8*1024*1024)throw new FormatException("Database size");
  var doc=new XmlDocument{XmlResolver=null};using(var reader=XmlReader.Create(new System.IO.StringReader(xml),new XmlReaderSettings{ProhibitDtd=true,XmlResolver=null}))doc.Load(reader);
  if(doc.DocumentElement==null||doc.DocumentElement.Name!="root")throw new System.IO.IOException("Invalid game database");
  Storage.SetValue(DbManager.instance,new CustomXMLStorage(doc));
 }
 public static bool Ready(){var level=GameObject.Find("Level");return Application.loadedLevelName=="House"&&GameObject.Find("Character")!=null&&level!=null&&level.transform.FindChild("floor_1")!=null;}
 static double Number(string s){double n;return Double.TryParse(s,NumberStyles.Float,CultureInfo.InvariantCulture,out n)?n:0;}
 static double Num(DbObject row,string key){return Number(row.getDataValue(key));}
 static string RoomId(int floor,string room){return "floor_"+floor+"/room_"+room;}
 void IndexScene(){
  level=GameObject.Find("Level").transform;original=Character.getInstance();heroGraphic=original.animationGraphix.gameObject;
  foreach(var floor in level.GetComponentsInChildren<Floor>(true)){
   if(!floor.name.StartsWith("floor_"))continue;
   foreach(string side in new[]{"left","center","right"}){Transform room=floor.transform.FindChild("room_"+side);if(room!=null)rooms[floor.name+"/room_"+side]=room;}
  }
  foreach(Transform floor in level)if(floor.name.StartsWith("floor_")&&(floor.FindChild("waypoint")!=null||floor.FindChild("left_waypoint")!=null))rooms[floor.name+"/room_center"]=floor;
  var all=new List<BaseInteractiveComponent>(level.GetComponentsInChildren<BaseInteractiveComponent>(true));
  var home=GameObject.Find("Home");if(home!=null)all.AddRange(home.GetComponentsInChildren<BaseInteractiveComponent>(true));
  foreach(var obj in all)objects[ObjectId(obj)]=obj;
 }
 public World Capture(){
  IndexScene();var w=new World();var m=original.model;
  w.Template=new Actor{Health=m.health,MaxHealth=m.maxHealth,Food=m.food,MaxFood=m.maxFood,Hunger=m.hungeFactor,HungerDamage=m.hungeToHealthFactor,Room="Home",Weapon="hands"};
  w.SuppressEntryAttack=GameObject.Find("Tutorial")!=null||GameObject.Find("phone")!=null;
  w.Template.PassivePerk=SettingsManager.getI.passivePerk;w.Template.ActivePerk=SettingsManager.getI.activePerk;if(!String.IsNullOrEmpty(w.Template.ActivePerk))w.Template.PerkState=PerksManager.getI.getStateOfCurrentActivePerk();
  foreach(var pair in m.specs.data)w.Template.Stats[pair.Key]=Number(pair.Value);
  Transform home=GameObject.Find("Home").transform.FindChild("waypoint");AddRoom(w,"Home",home,true);
  foreach(var pair in rooms){Transform point=pair.Value.FindChild("waypoint");if(point==null)continue;var floor=pair.Value.parent;var row=DbManager.instance.getDataFromTable("floors","name",floor.name);string side=pair.Value.name.Substring(5);AddRoom(w,pair.Key,point,row!=null&&row.getDataValue(side+"_known")=="True");}
  // The final floor uses a single waypoint, unlike floors 2..99.
  var first=level.FindChild("floor_1");if(!w.Rooms.ContainsKey("floor_1/room_center")&&first!=null)AddRoom(w,"floor_1/room_center",first.FindChild("waypoint"),false);
  Link(w,"Home","floor_99/room_center");
  for(int i=1;i<=99;i++){Link(w,RoomId(i,"center"),RoomId(i,"left"));Link(w,RoomId(i,"center"),RoomId(i,"right"));Link(w,RoomId(i,"center"),RoomId(i-1,"center"));}
  foreach(DbObject row in DbManager.instance.fetch("game_items")){
   string id=row.getDataValue("identity");if(String.IsNullOrEmpty(id))continue;var cfg=InventoryItemsConfigsBase.getI.getConfigForItem(id);
   Func<string,double> val=k=>cfg.ContainsKey(k)?Number(cfg[k]):0;
   w.Items[id]=new Item{Id=id,Name=row.getDataValue("dysplay_name"),Type=cfg["type"],Storage=row.getDataValue("storage"),Min=val("damage_min"),Max=val("damage_max"),Strength=val("str"),Dexterity=val("dex"),Speed=val("spd"),Food=val("energy"),Health=val("health")};
  }
  foreach(DbObject row in m.getInventory())w.Inventory[row.getDataValue("identity")]=(int)Num(row,"count");
  foreach(DbObject row in DbManager.instance.fetch("home_progress"))foreach(var pair in row.data)w.HomeProgress[pair.Key]=(int)Number(pair.Value);
  foreach(DbObject row in DbManager.instance.fetch("craft")){
   var recipe=new Recipe{Id="recipe:"+row.index,Result=row.getDataValue("result_identity"),Known=row.getDataValue("is_known")=="True"};
   if(row.getDataValue("category")=="upgrades"){int split=recipe.Result.LastIndexOf('_');int n;if(split>0&&Int32.TryParse(recipe.Result.Substring(split+1),out n)){recipe.UpgradeFacility=recipe.Result.Substring(0,split);recipe.UpgradeLevel=n;}}
   if(recipe.UpgradeFacility==null&&!w.Items.ContainsKey(recipe.Result))continue;
   recipe.NeedHome=row.getDataValue("need_home")=="True";
   string need=row.getDataValue("need");if(!String.IsNullOrEmpty(need)){int split=need.IndexOf('_');if(split<=0||!Int32.TryParse(need.Substring(0,split),out recipe.RequiredLevel))throw new FormatException("Invalid recipe requirement: "+need);recipe.RequiredFacility=need.Substring(split+1);}
   for(int i=1;i<=4;i++){string id=row.getDataValue("identity_"+i);if(id.Length==0)continue;int n;recipe.Ingredients.TryGetValue(id,out n);recipe.Ingredients[id]=n+1;}
   if(recipe.Ingredients.Count>0)w.Recipes.Add(recipe.Id,recipe);
  }
  w.Difficulty=SavesManager.getI.currentDifficultyKoeff;w.EnemyScatter=Number(RandomGenerationAssistant.getI.getRandomGenerationVar("enemy_scatter"));w.EnemyCritPercent=Number(RandomGenerationAssistant.getI.getRandomGenerationVar("enemy_crit_percent"));w.EnemyCritFactor=Number(RandomGenerationAssistant.getI.getRandomGenerationVar("enemy_crit_koeff"));
  string difficulty=((DbObject)DbManager.instance.fetch("settings")[0]).getDataValue("difficulty");w.LevelUpHealing=difficulty=="0"?25:difficulty=="1"?10:0;
  foreach(var pair in objects){
   BaseInteractiveComponent obj=pair.Value;DbObject row=(DbObject)ObjectData.GetValue(obj);string room=SceneRoom(obj.transform);if(room==null||!w.Rooms.ContainsKey(room))continue;
   var enemy=obj as BaseEnemy;
   if(enemy!=null){w.Enemies[pair.Key]=new Enemy{Id=pair.Key,Name=obj.name,Room=room,Health=enemy.isDead?0:enemy.health,Damage=enemy.damage,Experience=enemy.exp,Chances=Array.ConvertAll(enemy.zonesPercents,x=>(double)x),Multipliers=Array.ConvertAll(enemy.zonesDamageMods,x=>(double)x)};}
   if(obj is InteractiveContainer||enemy!=null){
    var box=new Container{Id=pair.Key,Name=obj.name,Room=room,EnemyId=enemy==null?null:pair.Key,Used=row!=null&&(row.getDataValue("state")=="used"||row.getDataValue("state")=="dead")};
    box.NativeLoot=!(obj is EnemyThird);
    w.Containers.Add(box.Id,box);
   }
  }
  int bed;w.HomeProgress.TryGetValue("bed",out bed);w.SleepHealthPerFood=Number(RandomGenerationAssistant.getI.getRandomGenerationVar("hunger_to_hp_lvl_"+bed));
  CaptureProgression(w);PopulateTravelTimes(w);
  w.NativeXml=Export();return w;
 }
 public void PopulateTravelTimes(World w){
  if(level==null)IndexScene();
  foreach(Room room in w.Rooms.Values)foreach(string destination in room.Neighbours){
   Transform start=ResolveWaypoint(room.Id),end=ResolveWaypoint(destination);if(start==null||end==null)continue;
   int from=room.Id=="Home"?100:Int32.Parse(room.Id.Split('/')[0].Substring(6));
   int to=destination=="Home"?100:Int32.Parse(destination.Split('/')[0].Substring(6));
   var path=NativePath.Find(start,end);
   // SKYHILL's waypoint graph can omit the penthouse/99th-floor link.
   // The co-op topology still contains that single legal transition.
   if(path==null){if((room.Id=="Home"&&destination=="floor_99/room_center")||
      (destination=="Home"&&room.Id=="floor_99/room_center"))
     room.TravelSeconds[destination]=Vector3.Distance(start.position,end.position)/Math.Max(1,original.model.moveSpeed*70);
    continue;}
   double distance=0;Vector3 previous=start.position;foreach(Transform point in path){distance+=Vector3.Distance(previous,point.position);previous=point.position;}
   room.TravelSeconds[destination]=distance/Math.Max(1,original.model.moveSpeed*70);
  }
 }
 void AddRoom(World w,string id,Transform point,bool known){if(point==null)return;Vector3 pos=level.InverseTransformPoint(point.position);var area=point.parent.GetComponent<AreaClick>();w.Rooms[id]=new Room{Id=id,Known=known,Locked=area!=null&&area.isLocked,X=pos.x,Y=pos.y,Z=pos.z};}
 static void Link(World w,string a,string b){if(w.Rooms.ContainsKey(a)&&w.Rooms.ContainsKey(b)){w.Rooms[a].Neighbours.Add(b);w.Rooms[b].Neighbours.Add(a);}}
 public void Attach(Action<string> roomClicked){
  if(attached)return;IndexScene();
  foreach(var script in original.GetComponentsInChildren<MonoBehaviour>(true))script.StopAllCoroutines();
  original.gameObject.SetActive(false);var viewer=GameObject.Find("LevelViewer");if(viewer!=null)viewer.GetComponent<LevelViewer>().enabled=false;
  // Keep the original HUD, inventory and Escape menu alive in co-op.
  // The native player itself stays disabled; UI mutations are handled by
  // NativeInterface Harmony prefixes and authoritative network commands.
  var ui=GameObject.Find("UI");if(ui!=null)ui.SetActive(true);
  var tutorial=GameObject.Find("Tutorial");if(tutorial!=null)tutorial.SetActive(false);
  foreach(var obj in objects.Values){obj.CancelInvoke();obj.StopAllCoroutines();obj.enabled=false;foreach(var collider in obj.GetComponentsInChildren<Collider>(true))collider.enabled=true;}
  BindMouseRooms(roomClicked);
  // Clear old singleton character tutorial speech ("You can go down...").
  NotificationCenter.getI.postNotification("uiTalkingTextHide",null);
  attached=true;
 }
 void BindMouseRooms(Action<string> clicked){
  // Original AreaClick.OnMouseUp is patched in Mod, but its tk2d hoverDetector
  // can receive clicks independently of Unity's OnMouseUp collider callbacks.
  var all=new List<AreaClick>();
  all.AddRange(level.GetComponentsInChildren<AreaClick>(true));
  var home=GameObject.Find("Home");if(home!=null)all.AddRange(home.GetComponentsInChildren<AreaClick>(true));
  foreach(AreaClick area in all){
   if(area==null||area.hoverDetector==null||roomClickHandlers.ContainsKey(area.hoverDetector))continue;
   string id=AreaId(area.gameObject);
   if(id!="Home"&&!rooms.ContainsKey(id)&&id!="floor_1/room_center")continue;
   Action handler=delegate(){clicked(id);};
   area.hoverDetector.OnClick+=handler;
   roomClickHandlers.Add(area.hoverDetector,handler);
  }
 }
 public void DetachMouse(){
  foreach(var pair in roomClickHandlers)if(pair.Key!=null)pair.Key.OnClick-=pair.Value;
  roomClickHandlers.Clear();
  foreach(var pair in originalRoomColliders)if(pair.Key!=null)pair.Key.enabled=pair.Value;
  originalRoomColliders.Clear();locallyOccupiedColliders.Clear();
  foreach(var pair in animationResetHandlers)if(pair.Key!=null)pair.Key.onAnimationFinished_evnt-=pair.Value;
  animationResetHandlers.Clear();enemyVisuals.Clear();
  foreach(var avatar in avatars.Values)if(avatar!=null)UnityEngine.Object.Destroy(avatar.gameObject);avatars.Clear();attached=false;
 }
 public void TryMouseRaycast(Vector3 mouse,Action<string> clicked,Action<BaseInteractiveComponent> interact){
  // Fallback for scenes with OnMouseUp disabled: honor foreground interactive
  // objects and choose the closest room collider instead of guessing by X/Y.
  Camera camera=Camera.main;if(camera==null){var cameras=Camera.allCameras;if(cameras!=null&&cameras.Length>0)camera=cameras[0];}if(camera==null)return;
  RaycastHit[] hits=Physics.RaycastAll(camera.ScreenPointToRay(mouse),100000f);
  Array.Sort(hits,delegate(RaycastHit a,RaycastHit b){return a.distance.CompareTo(b.distance);});
  foreach(RaycastHit hit in hits){
   if(hit.collider==null)continue;
   Transform t=hit.collider.transform;bool anotherUiItem=false;
   while(t!=null){
    BaseInteractiveComponent obj=t.GetComponent<BaseInteractiveComponent>();
    if(obj!=null){if((obj.isChecked||obj is Bed||obj is Workbranch)&&obj.isActive){if(interact!=null)interact(obj);}else{string room=SceneRoom(obj.transform);if(room!=null&&clicked!=null)clicked(room);}return;}
    AreaClick area=t.GetComponent<AreaClick>();
    if(area!=null){string id=AreaId(area.gameObject);
     if(id=="Home"||rooms.ContainsKey(id)||id=="floor_1/room_center")clicked(id);
     return;
    }
    if(t.GetComponent<tk2dUIItem>()!=null)anotherUiItem=true;
    t=t.parent;
   }
   // Do not click through menus, inventory buttons or other UI colliders.
   if(anotherUiItem)return;
  }
 }
 public Transform ResolveWaypoint(string id){if(id=="Home"){var home=GameObject.Find("Home");return home==null?null:home.transform.FindChild("waypoint");}Transform room;if(rooms.TryGetValue(id,out room))return room.FindChild("waypoint")??room.FindChild("left_waypoint");if(id.EndsWith("/room_center")){var floor=level.FindChild(id.Split('/')[0]);if(floor!=null)return floor.FindChild("waypoint")??floor.FindChild("left_waypoint");}return null;}
 public static string AreaId(GameObject area){if(area.name=="Home")return "Home";if(area.name.StartsWith("floor_"))return area.name+"/room_center";return area.transform.parent.name+"/"+area.name;}
 public static string ObjectId(BaseInteractiveComponent obj){if(obj==null)return null;string virtualId=VirtualId(obj);if(virtualId!=null)return virtualId;var row=ObjectData.GetValue(obj) as DbObject;if(row!=null&&row.index>=0)return "obj:"+row.index;
  string path=obj.name;Transform t=obj.transform.parent;while(t!=null){path=t.name+"/"+path;t=t.parent;}return "scene:"+path;}
 void SetRoomCollider(Collider collider,bool current){
  if(collider==null)return;
  bool original;
  if(!originalRoomColliders.TryGetValue(collider,out original)){
   original=collider.enabled;originalRoomColliders.Add(collider,original);
  }
  if(current)locallyOccupiedColliders.Add(collider);
  // Do not resurrect zones that the original game intentionally disabled,
  // except when the multiplayer actor has already occupied and left them.
  collider.enabled=!current&&(original||locallyOccupiedColliders.Contains(collider));
 }
 void ObserveLocalRoom(World w,Actor local,string visibleRoom){
  if(local==null)return;
  string roomId=visibleRoom??local.Room;
  bool changed=roomId!=lastObservedRoom||lastObservedActor!=local.Id;
  var enemies=new ArrayList();
  foreach(var pair in objects){Enemy enemy;if(w.Enemies.TryGetValue(pair.Key,out enemy)&&enemy.Room==roomId&&enemy.Health>0&&pair.Value is BaseEnemy)enemies.Add(pair.Value);}
  if(!changed&&enemies.Count==lastObservedEnemyCount)return;
  // The original hero's RoomTriggers never fire in co-op. Reproduce only
  // their VISUAL/UI effects here; hunger and discovery belong to Session.
  foreach(var pair in rooms){
   Room state;if(!w.Rooms.TryGetValue(pair.Key,out state))continue;
   Transform room=pair.Value;bool current=pair.Key==roomId;
   Transform inactive=room.FindChild("inactive");
   if(inactive!=null)inactive.gameObject.SetActive(!current);
   Transform unknown=room.FindChild("unknown");
   if(unknown!=null)unknown.gameObject.SetActive(!state.Known);
   AreaClick area=room.GetComponent<AreaClick>();
   if(area!=null){
    // Occupied area must not swallow clicks on its furniture/enemies.
    SetRoomCollider(area.GetComponent<Collider>(),current);
    // tk2d uses a separate hover collider on some floors.
    if(area.hoverDetector!=null)SetRoomCollider(area.hoverDetector.GetComponent<Collider>(),current);

   }
  }
  var ground=level.FindChild("floor_1");
  if(ground!=null){
   bool current=roomId=="floor_1/room_center";
   Transform inactive=ground.FindChild("inactive");if(inactive!=null)inactive.gameObject.SetActive(!current);
   var area=ground.GetComponent<AreaClick>();if(area!=null){
    SetRoomCollider(area.GetComponent<Collider>(),current);
    if(area.hoverDetector!=null)SetRoomCollider(area.hoverDetector.GetComponent<Collider>(),current);
   }
  }
  var home=GameObject.Find("Home");
  if(home!=null){
   Transform inactive=home.transform.FindChild("inactive");if(inactive!=null)inactive.gameObject.SetActive(roomId!="Home");
   AreaClick area=home.GetComponent<AreaClick>();
   if(area!=null){SetRoomCollider(area.GetComponent<Collider>(),roomId=="Home");
    if(area.hoverDetector!=null)SetRoomCollider(area.hoverDetector.GetComponent<Collider>(),roomId=="Home");}
  }
  lastObservedRoom=roomId;lastObservedActor=local.Id;
  lastObservedEnemyCount=enemies.Count;
  if(changed)NotificationCenter.getI.postNotification("uiTalkingTextHide",null);
  // These notifications are routed exclusively to UI listeners by the patch.
  NotificationCenter.getI.postNotification("noEnemyInRoom",null);
  if(enemies.Count>0){
   Transform room=ResolveRoom(roomId);AreaObjects area=room==null?null:room.GetComponent<AreaObjects>();
   if(area!=null){area.enemies=enemies;NotificationCenter.getI.postNotification("enemyInRoom",area);}
   NotificationCenter.getI.postNotification("showWeaponsChanger",null);
   lastObservedBattle=true;
  }else{
   if(lastObservedBattle)NotificationCenter.getI.postNotification("hideWeaponsChanger",null);
   lastObservedBattle=false;
  }
 }
 Transform ResolveRoom(string roomId){if(roomId=="Home"){var home=GameObject.Find("Home");return home==null?null:home.transform;}
  Transform room;if(rooms.TryGetValue(roomId,out room))return room;
  if(roomId=="floor_1/room_center")return level.FindChild("floor_1");return null;}
 public void ShowAttackUI(BaseEnemy target){if(!attached||target==null)return;
  NotificationCenter.getI.postNotification("showZonesAttackUI",target);
 }
 public void Render(World w,string follow){
  if(!attached||level==null||w==null)return;
  ProjectProgression(w);
  foreach(Actor a in w.Actors.Values){
   MultiplayerCharacter avatar;Transform point=ResolveWaypoint(a.Room);if(point==null)continue;
   if(!avatars.TryGetValue(a.Id,out avatar)||avatar==null){
    var root=new GameObject("Astra_"+a.Id);avatar=root.AddComponent<MultiplayerCharacter>();try{avatar.Initialize(original,level,point,a);avatars[a.Id]=avatar;}catch{UnityEngine.Object.Destroy(root);throw;}
   }
   avatar.Apply(a,point);
   bool battling=false;
   foreach(Enemy e in w.Enemies.Values)if(e.Health>0&&e.Room==a.Room){battling=true;break;}
   avatar.SetBattle(battling);
  }
  Actor target;if(follow==null||!w.Actors.TryGetValue(follow,out target)||!target.Alive){target=null;foreach(Actor a in w.Actors.Values)if(a.Alive){target=a;break;}}
  if(target!=null){
   MultiplayerCharacter visual;
   string visibleRoom=avatars.TryGetValue(target.Id,out visual)&&visual!=null?visual.VisualRoom:target.Room;
   ObserveLocalRoom(w,target,visibleRoom);
   Room room;
   if(w.Rooms.TryGetValue(target.Room,out room)){
    float cameraY=room.Y;
    MultiplayerCharacter current;
    // Follow the visible character while its waypoint animation is running;
    // authoritative Actor.Room already contains the destination at move start.
    if(avatars.TryGetValue(target.Id,out current)&&current!=null&&current.IsMoving)
     cameraY=level.InverseTransformPoint(current.transform.position).y;
    float cameraX=target.Room.StartsWith("floor_-")?-Math.Max(0,room.X-520):0;
    level.position=new Vector3(cameraX,Mathf.Clamp(218f*((float)Screen.height/Screen.width)/0.5633803f-cameraY,-20,22550),0);
   }
  }
  PresentBoss(w,target);
  foreach(Transform floor in level){if(floor.name.StartsWith("floor_"))floor.gameObject.SetActive(Mathf.Abs(floor.position.y)<1000);}
  if(!eventsInitialized){eventCursor=w.EventSequence;eventsInitialized=true;}
  foreach(GameEvent ev in w.Events)if(ev.Id>eventCursor){
   if(ev.Kind=="loot")PresentLoot(w,ev);
   if(ev.Kind=="quest_message"&&target!=null&&ev.ActorId==target.Id)PresentQuestMessage(w,ev);
   MultiplayerCharacter avatar;if(ev.ActorId!=null&&avatars.TryGetValue(ev.ActorId,out avatar))avatar.Present(ev);
   if((ev.Kind=="enemy_attack"||ev.Kind=="enemy_miss")&&ev.TargetId!=null&&avatars.TryGetValue(ev.TargetId,out avatar))avatar.Present(ev);
   BaseInteractiveComponent obj;string enemyId=(ev.Kind=="enemy_attack"||ev.Kind=="enemy_miss")?ev.ActorId:ev.TargetId;
   if(enemyId!=null&&objects.TryGetValue(enemyId,out obj)&&obj is BaseEnemy){Enemy state;if(w.Enemies.TryGetValue(enemyId,out state))EnemyVisual(enemyId,(BaseEnemy)obj).Present(ev,state);}
   eventCursor=ev.Id;
  }
  foreach(var pair in rooms){Room r;if(!w.Rooms.TryGetValue(pair.Key,out r))continue;var unknown=pair.Value.FindChild("unknown");if(unknown!=null)unknown.gameObject.SetActive(!r.Known);}
  foreach(var pair in objects){
   UpdateObjectAccess(w,target,pair.Key,pair.Value);
   Enemy e;if(w.Enemies.TryGetValue(pair.Key,out e)&&pair.Value is BaseEnemy){var visual=EnemyVisual(pair.Key,(BaseEnemy)pair.Value);visual.Sync(e);visual.Advance(Time.deltaTime);}
   Container box;if(w.Containers.TryGetValue(pair.Key,out box)&&box.Used&&!(pair.Value is BaseEnemy)){var sprite=pair.Value.GetComponent<tk2dSprite>();if(sprite!=null&&sprite.GetSpriteIdByName(pair.Value.name+"_used")>0)sprite.SetSprite(pair.Value.name+"_used");}
  }
 }
 MultiplayerEnemy EnemyVisual(string id,BaseEnemy native){MultiplayerEnemy visual;if(!enemyVisuals.TryGetValue(id,out visual)){visual=new MultiplayerEnemy(native);enemyVisuals[id]=visual;}return visual;}
 void UpdateObjectAccess(World w,Actor observer,string id,BaseInteractiveComponent obj){
  Container box;Enemy enemy;bool container=w.Containers.TryGetValue(id,out box);bool isEnemy=w.Enemies.TryGetValue(id,out enemy);
  if(!container&&!isEnemy){UpdateInteractiveAccess(w,observer,id,obj);return;}
  string room=container?box.Room:enemy.Room;
  MultiplayerCharacter visual;bool arrived=observer!=null&&observer.Alive&&w.ServerTime>=observer.MovingUntil&&
   avatars.TryGetValue(observer.Id,out visual)&&visual!=null&&!visual.IsMoving&&visual.VisualRoom==room&&observer.Room==room;
  bool fighting=false;foreach(Enemy other in w.Enemies.Values)if(other.Room==room&&other.Health>0){fighting=true;break;}
  bool aliveEnemy=isEnemy&&enemy.Health>0;
  bool available=arrived&&(aliveEnemy||(container&&!box.Used&&!fighting));
  obj.isChecked=available;obj.isActive=aliveEnemy||(container&&!box.Used);
  var zone=obj.GetComponent<UI_PC_ClickZone>();if(zone!=null){zone.isActive=available;zone.isLocked=false;zone.ShowActionIcon=true;zone.cursorState=aliveEnemy?"attack":"hand";}
 }
 void PresentLoot(World world,GameEvent ev){
  Container box;BaseInteractiveComponent owner;
  if(ev.TargetId==null||!world.Containers.TryGetValue(ev.TargetId,out box)||box.Room!=lastObservedRoom||!objects.TryGetValue(ev.TargetId,out owner))return;
  var ui=GameObject.Find("UI");var prefab=Resources.Load("LootItem");if(ui==null||prefab==null||ev.Items==null)return;
  int index=0;foreach(var item in ev.Items){
   DbObject data=GameItemsDataManager.getI.getDataForItemWithName(item.Key);if(data==null)continue;
   for(int n=0;n<item.Value&&index<64;n++,index++){
    var popup=(GameObject)UnityEngine.Object.Instantiate(prefab,owner.transform.position,Quaternion.identity);
    popup.transform.parent=ui.transform;popup.transform.localPosition=new Vector3(popup.transform.localPosition.x,popup.transform.localPosition.y,-1);
    popup.transform.FindChild("graphics").GetComponent<tk2dSprite>().SetSprite(data.getDataValue("sprite"));
    var loot=popup.GetComponent<LootItem>();loot.itemName=LanguageManager.Instance.GetTextValue("InventoryItemName: "+data.getDataValue("dysplay_name"));loot.correctionY=index*20;loot.take(index*0.15f);
   }
  }
  // LootItem only animates the confirmed receipt. It never calls the generator
  // or adds inventory items locally, so duplicate snapshots cannot award loot.
  NotificationCenter.getI.postNotification("inventoryLayoutItems",null);
 }
}
}

