param([string]$GamePath = 'C:\Program Files (x86)\Steam\steamapps\common\Skyhill')
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$before = Get-Date
Write-Host 'Rebuilding AstraCoop from sources:' $root
& (Join-Path $root 'build.ps1') -GamePath $GamePath
if ($LASTEXITCODE -ne 0) { throw "build.ps1 returned exit code $LASTEXITCODE" }
foreach ($name in @('AstraCoop.Core.dll', 'AstraCoop.dll')) {
    $path = Join-Path $root "bin\$name"
    $file = Get-Item -LiteralPath $path -ErrorAction Stop
    if ($file.LastWriteTime -lt $before.AddSeconds(-2)) {
        throw "DLL was not freshly built: $path ($($file.LastWriteTime))"
    }
    $hash = Get-FileHash -LiteralPath $path -Algorithm SHA256
    Write-Host "$name  Size=$($file.Length)  Built=$($file.LastWriteTime)  SHA256=$($hash.Hash)"
}
Write-Host 'Running core tests...'
& (Join-Path $root 'test.ps1')
if ($LASTEXITCODE -ne 0) { throw "test.ps1 returned exit code $LASTEXITCODE" }
Write-Host 'Build and core tests completed. Live SKYHILL gameplay must still be tested.'
