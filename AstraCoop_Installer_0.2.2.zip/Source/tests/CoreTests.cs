using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using AstraCoop;
class Tests {
 static int passed;static void Check(bool value,string label){if(!value)throw new Exception("FAIL: "+label);Console.WriteLine("PASS: "+label);passed++;}
 static Session Fixture(){var w=new World{Started=true,Template=new Actor{Room="a",Health=100,MaxHealth=100,Food=100,MaxFood=100}};
  w.Rooms.Add("a",new Room{Id="a",Known=true});w.Rooms.Add("b",new Room{Id="b"});w.Rooms["a"].Neighbours.Add("b");w.Rooms["b"].Neighbours.Add("a");
  w.Items["hands"]=new Item{Id="hands",Type="weapon",Min=10,Max=10};w.Items["med"]=new Item{Id="med",Type="medical",Health=20};w.Items["wood"]=new Item{Id="wood"};w.Items["sword"]=new Item{Id="sword",Type="weapon",Min=20,Max=20};
  w.Inventory["med"]=1;w.Inventory["wood"]=3;w.Inventory["sword"]=1;w.Recipes["r"]=new Recipe{Id="r",Result="med"};w.Recipes["r"].Ingredients["wood"]=2;
  w.Enemies["e"]=new Enemy{Id="e",Room="a",Health=100,Damage=10,Chances=new double[]{0},Multipliers=new double[]{1}};return new Session(w,new Settings(),1);
 }
 static Reply Join(Session s,string name,string role="player"){return s.Join(new Command{Op="join",Name=name,Role=role},false);}
 static Reply Act(Session s,Reply who,string op,string target=null,double now=0,int zone=0,string text=null){return s.Execute(who.MemberId,new Command{Op=op,Target=target,Sequence=s.Members[who.MemberId].LastSequence+1,Zone=zone,Text=text},now);}
 static void UpgradeTest(){var s=Fixture();var a=Join(s,"a");var b=Join(s,"b");var p=s.World.Actors[a.ActorId];p.Stats["free_skill_points"]=1;p.Stats["strength"]=5;
  var c=new Command{Op="upgrade",Target="strength",Sequence=1};Check(s.Execute(a.MemberId,c,0).Ok&&s.Execute(a.MemberId,c,0).Ok&&p.Stats["strength"]==6&&p.Stats["free_skill_points"]==0,"upgrade spends one point once despite retransmission");
  Check(Act(s,a,"upgrade","accuracy").Code=="no_skill_points"&&Session.Stat(s.World.Actors[b.ActorId],"strength")==0,"upgrade cannot overspend or affect another actor");
  Check(Act(s,a,"upgrade","health").Code=="invalid_stat","UI cannot upgrade arbitrary state");
  p.PassivePerk="PASSIVE_PERK_7";p.Stats["free_skill_points"]=1;double before=p.Stats["strength"];Check(Act(s,a,"upgrade","strength").Ok&&p.Stats["strength"]-before>=1&&p.Stats["strength"]-before<=8,"native passive perk seven upgrade range");
 }
 static void SearchTest(){
  var s=Fixture();var a=Join(s,"a");var b=Join(s,"b");var watcher=Join(s,"watch","spectator");var box=new Container{Id="box",Room="a"};box.Loot["wood"]=2;s.World.Containers[box.Id]=box;
  Check(Act(s,a,"interact","box").Code=="enemies_present"&&!box.Used,"search blocked by living enemy");
  s.World.Enemies["e"].Health=0;s.World.Actors[a.ActorId].MovingUntil=2;
  Check(Act(s,a,"interact","box",1).Code=="moving"&&!box.Used,"search blocked during movement");
  var command=new Command{Op="interact",Target="box",Sequence=s.Members[a.MemberId].LastSequence+1};
  Check(s.Execute(a.MemberId,command,2).Ok&&s.Execute(a.MemberId,command,2).Ok&&s.World.Inventory["wood"]==5,"duplicate search command yields loot once");
  Check(Act(s,b,"interact","box",2).Code=="already_used"&&s.World.Inventory["wood"]==5,"second player cannot search same container again");
  Check(s.World.Events.Count(e=>e.Kind=="loot")==1&&s.View().Events.Last().Items["wood"]==2&&s.View().Containers["box"].Loot.Count==0,"one public loot receipt and hidden unopened loot tables");
  Check(Act(s,watcher,"interact","box",2).Code=="spectator_read_only","spectator search rejected");
  string path=Path.Combine(Path.GetTempPath(),"astra-search-"+Guid.NewGuid()+".json");Persistence.Save(s,path,2);var loaded=Persistence.Load(path,10);
  Check(Act(loaded,b,"interact","box",10).Code=="already_used"&&loaded.World.Inventory["wood"]==5,"searched state survives save and load");File.Delete(path);
 }
 static void Main(){
  UpgradeTest();SearchTest();
  var s=Fixture();var a=Join(s,"Первый");var b=Join(s,"Второй");var observer=Join(s,"Наблюдатель","spectator");
  Check(a.Ok&&b.Ok&&observer.Ok&&s.World.Actors.Count==2,"independent players; spectator has no actor");
  Check(Act(s,a,"move","b").Ok&&s.World.Actors[b.ActorId].Room=="a"&&s.World.Actors[b.ActorId].Food==100,"movement and hunger independent");
  Check(Act(s,a,"attack","e").Code=="out_of_range","cross-room attacks rejected");
  Check(Act(s,b,"attack","e",0).Ok&&Act(s,b,"attack","e",0.999).Code=="cooldown"&&Act(s,b,"attack","e",1).Ok,"miss consumes exactly one-second cooldown");
  Check(Act(s,b,"attack","e",2,-1).Code=="invalid_zone","invalid body zone rejected");
  s.World.Actors[a.ActorId].Health=40;s.World.Actors[b.ActorId].Health=40;
  Check(Act(s,a,"use","med").Ok&&Act(s,b,"use","med").Code=="item_unavailable"&&s.World.Actors[b.ActorId].Health==40,"one medkit consumed once");
  Check(Act(s,a,"craft","r").Ok&&Act(s,b,"craft","r").Code=="missing_ingredients_or_equipped"&&s.World.Inventory["wood"]==1,"craft conflict cannot duplicate resources");
  Check(Act(s,a,"equip","sword").Ok&&Act(s,b,"equip","sword").Code=="item_unavailable","equipment reservation exclusive");
  Check(Act(s,a,"drop","sword").Ok&&s.World.Actors[a.ActorId].Weapon=="hands"&&s.World.Inventory["sword"]==0,"valuable equipped item can be dropped");
  string drop=s.World.Drops.Keys.First();Check(Act(s,b,"pickup",drop).Code=="out_of_range"&&Act(s,a,"pickup",drop).Ok&&Act(s,a,"pickup",drop).Code=="already_taken","pickup location and single ownership");
  Check(Act(s,observer,"move","a").Code=="spectator_read_only","spectator cannot alter world");
  var cmd=new Command{Op="chat",Text="Привет 🌍",Sequence=s.Members[a.MemberId].LastSequence+1};var first=s.Execute(a.MemberId,cmd,4);var repeat=s.Execute(a.MemberId,cmd,4);
  Check(first.Ok&&repeat.Ok&&s.World.Chat.Count==1&&s.World.Chat[0].Text=="Привет 🌍","Unicode chat and duplicate command idempotency");
  Check(s.Execute(a.MemberId,new Command{Op="chat",Text="bad",Sequence=1},4).Code=="sequence_mismatch","stale sequence not executed");
  var resumed=s.Join(new Command{Op="join",Token=a.Token},false);Check(resumed.Ok&&resumed.ActorId==a.ActorId&&s.World.Actors.Count==2,"reconnect retains actor and sequence");
  Check(s.Join(new Command{Op="join",Token="forged"},false).Code=="invalid_resume_token","forged resume rejected");
  Check(s.Join(new Command{Op="join",Name="intruder",Role="admin"},false).Code=="invalid_role","invalid role rejected");
  s.World.Enemies["e"].Room="b";s.World.Rooms["b"].Known=false;
  Check(!s.View().Enemies.ContainsKey("e"),"unexplored enemies hidden");
  s.World.Actors[a.ActorId].NextAttack=10.7;
  string path=Path.Combine(Path.GetTempPath(),"astra-test-"+Guid.NewGuid()+".json");Persistence.Save(s,path,10);var loaded=Persistence.Load(path,100);
  Check(Math.Abs(loaded.World.Actors[a.ActorId].NextAttack-100.7)<0.000001&&loaded.World.Drops.Count==0&&loaded.World.Inventory["sword"]==1,"save roundtrip and cooldown rebasing");
  Check(loaded.Execute(a.MemberId,cmd,100).Ok&&loaded.World.Chat.Count==1,"duplicate result persists through save/load");
  Persistence.Save(s,path,10);Check(File.Exists(path+".bak"),"atomic save backup created");File.Delete(path);File.Delete(path+".bak");
  s.World.Actors[a.ActorId].Health=0;s.Tick(20);Check(!s.World.GameOver&&Act(s,a,"use","med").Code=="dead","individual death cannot act; team continues");
  s.World.Actors[b.ActorId].Health=0;s.Tick(21);Check(s.World.GameOver,"all players dead ends run despite spectator");
  var many=Fixture();for(int i=0;i<16;i++)Check(Join(many,"p"+i).Ok,"configured player slot "+i);Check(!Join(many,"overflow").Ok&&Join(many,"watch","spectator").Ok,"spectators do not consume player limit");
  SlotTest();SleepTest();TravelTest();CraftTest();MouseRouteTest();TurnBasedCombatTest();TransportTest();Console.WriteLine("TOTAL "+passed+" passed");
 }
 static void TurnBasedCombatTest(){
  var s=Fixture();var first=Join(s,"fighter");var second=Join(s,"roommate");
  Actor player=s.World.Actors[first.ActorId],other=s.World.Actors[second.ActorId];
  player.Health=player.MaxHealth=10000;other.Health=other.MaxHealth=10000;
  s.Tick(500);
  Check(player.Health==10000&&other.Health==10000&&s.World.Events.Count==0,"monsters never auto-attack while players merely share their room");
  var enemy=s.World.Enemies["e"];
  enemy.Health=1000000;enemy.Damage=1;
  int retaliations=0;bool allAccepted=true;
  for(int i=0;i<120;i++){
   double t=501+i*1.1;
   allAccepted&=Act(s,first,"attack","e",t,0).Ok;
   s.Tick(t+0.70);
   foreach(var ev in s.World.Events)if(ev.Kind=="enemy_attack"||ev.Kind=="enemy_miss")retaliations++;
   s.World.Events.Clear();
  }
  Check(allAccepted,"all sequential attacks accepted after their cooldown");
  Check(retaliations>=35&&retaliations<=85,"enemy retaliation occurs roughly 50 percent of player attack turns");
  Check(other.Health==10000,"retaliation targets only the player who attacked");
  player.Stats["dexterity"]=100;player.Stats["dexterity_factor"]=1;
  int landed=0;
  for(int i=0;i<70;i++){
   double t=700+i*1.1;Act(s,first,"attack","e",t,0);s.Tick(t+0.70);
   foreach(var ev in s.World.Events)if(ev.Kind=="enemy_attack")landed++;
   s.World.Events.Clear();
  }
  Check(landed==0,"native dexterity evasion makes enemy counterattacks miss");
  var one=Fixture();var alone=Join(one,"alone");one.World.Actors[alone.ActorId].Health=0;
  one.Tick(42);Check(one.World.GameOver&&one.World.Events.Exists(ev=>ev.Kind=="game_over"),"last player's death ends the coop game and emits event");
 }
  static void SlotTest(){var s=Fixture();var a=Join(s,"a");var b=Join(s,"b");
  Check(Act(s,a,"slot","sword",0,1).Ok&&s.World.Actors[a.ActorId].QuickWeapon2=="sword"&&s.World.Actors[b.ActorId].QuickWeapon2=="","quick slots independent");
  Check(Act(s,a,"slot","sword",0,2).Code=="invalid_slot","invalid quick slot rejected");
  Check(Act(s,a,"equip","sword").Ok&&Act(s,b,"slot","sword",0,0).Ok&&Act(s,b,"equip","sword").Code=="item_unavailable","shortcut does not duplicate or steal equipped weapon");
  Check(Json.Copy(s.World).Actors[a.ActorId].QuickWeapon2=="sword","quick slot serialized with actor");
 }
 static void SleepTest(){
  var s=Fixture();var a=Join(s,"sleeper");var b=Join(s,"awake");s.World.SleepHealthPerFood=2;
  Check(Act(s,a,"sleep",null,0,2).Code=="requires_home","sleep only at home");
  var actor=s.World.Actors[a.ActorId];actor.Room="Home";actor.Health=20;actor.Food=25;
  Check(Act(s,a,"sleep",null,0,11).Code=="invalid_sleep_hours"&&actor.Food==25,"invalid sleep cannot consume food");
  Check(Act(s,a,"sleep",null,0,3).Ok&&actor.Food==5&&actor.Health==60&&s.World.Actors[b.ActorId].Food==100,"sleep uses native conversion and independent actor resources");
 }
 static void TravelTest(){
  var s=Fixture();s.World.Rooms["a"].TravelSeconds["b"]=3.5;var a=Join(s,"traveller");
  Check(Act(s,a,"move","b",10).Ok,"native route duration accepted");
  Check(Act(s,a,"use","med",13.49).Code=="moving"&&s.World.Inventory["med"]==1,"no item use before native route arrival");
  s.World.Enemies["e"].Room="b";s.Tick(13.49);Check(s.World.Actors[a.ActorId].Health==100,"enemy cannot hit character before arrival");
  Check(Act(s,a,"use","med",13.5).Ok,"actions resume exactly at arrival");
  string path=Path.Combine(Path.GetTempPath(),"astra-travel-"+Guid.NewGuid()+".json");Persistence.Save(s,path,11);var loaded=Persistence.Load(path,100);
  Check(Math.Abs(loaded.World.Actors[a.ActorId].MovingUntil-102.5)<0.00001,"save preserves remaining travel duration");File.Delete(path);
 }
 static void CraftTest(){
  var s=Fixture();var a=Join(s,"cook");var b=Join(s,"other");var r=s.World.Recipes["r"];r.NeedHome=true;r.RequiredFacility="kitchen";r.RequiredLevel=2;
  Check(Act(s,a,"craft","r").Code=="requires_home"&&s.World.Inventory["wood"]==3,"craft away from home preserves resources");
  s.World.Actors[a.ActorId].Room="Home";
  Check(Act(s,a,"craft","r").Code=="requires_home_upgrade"&&s.World.Inventory["wood"]==3,"craft enforces facility level");
  s.World.HomeProgress["kitchen"]=2;r.Ingredients.Clear();r.Ingredients["apple_f1"]=1;r.Ingredients["any_fruit"]=2;
  s.World.Inventory["apple_f1"]=1;s.World.Inventory["pear_f1"]=1;
  Check(Act(s,a,"craft","r").Code=="missing_ingredients_or_equipped"&&s.World.Inventory["apple_f1"]==1&&s.World.Inventory["pear_f1"]==1,"wildcard failure atomic; exact ingredient not reused");
  s.World.Inventory["pear_f1"]=2;
  Check(Act(s,a,"craft","r").Ok&&s.World.Inventory["apple_f1"]==0&&s.World.Inventory["pear_f1"]==0,"wildcard consumes exact remaining quantities");
  s.World.Actors[b.ActorId].Room="Home";Check(Act(s,b,"craft","r").Code=="missing_ingredients_or_equipped"&&s.World.Inventory["med"]==2,"second crafter cannot reuse consumed wildcard ingredients");
  Check(s.View().HomeProgress["kitchen"]==2&&s.View().Recipes["r"].NeedHome,"API exposes craft requirements and facility levels");
 }

 static void MouseRouteTest(){
  var w=new World();foreach(string id in new[]{"Home","floor_99/room_center","floor_99/room_left","floor_98/room_center","floor_97/room_center","sealed"})w.Rooms[id]=new Room{Id=id};
  Link(w,"Home","floor_99/room_center");Link(w,"floor_99/room_center","floor_99/room_left");
  Link(w,"floor_99/room_center","floor_98/room_center");Link(w,"floor_98/room_center","floor_97/room_center");
  var path=MouseRoute.Find(w,"Home","floor_97/room_center");
  Check(path!=null&&path.SequenceEqual(new[]{"floor_99/room_center","floor_98/room_center","floor_97/room_center"}),"mouse route plans successive server-valid edges");
  Check(MouseRoute.Find(w,"Home","Home").Count==0,"clicking current room does not issue a move");
  w.Rooms["floor_98/room_center"].Locked=true;
  Check(MouseRoute.Find(w,"Home","floor_97/room_center")==null,"mouse route cannot cross locked rooms");
  Check(MouseRoute.Find(w,"Home","sealed")==null,"mouse route rejects disconnected destinations");
  Check(MouseRoute.Find(w,"Home","missing")==null,"mouse route rejects unknown destinations");
  w.Rooms["floor_98/room_center"].Locked=false;
  Check(MouseRoute.Find(w,"Home","floor_99/room_left").SequenceEqual(new[]{"floor_99/room_center","floor_99/room_left"}),"mouse route supports lateral room clicks");
 }
 static void Link(World w,string a,string b){w.Rooms[a].Neighbours.Add(b);w.Rooms[b].Neighbours.Add(a);}
 static void TransportTest(){var s=Fixture();using(var server=new Server(10)){
  var probe=new TcpListener(IPAddress.Loopback,0);probe.Start();int port=((IPEndPoint)probe.LocalEndpoint).Port;probe.Stop();server.Listen(IPAddress.Loopback,port,false);
  Exception error=null;bool done=false;var worker=new Thread(delegate(){try{using(var c=new TcpClient("127.0.0.1",port))using(var stream=c.GetStream()){
   c.ReceiveTimeout=4000;Wire.Write(stream,Json.Write(new Command{Op="join",Name="socket",Role="player"}));Reply welcome=Json.Read<Reply>(Wire.Read(stream,Wire.MaxReply));if(!welcome.Ok)throw new Exception(welcome.Code);
   Wire.Write(stream,Json.Write(new Command{Op="chat",Text="TCP Юникод",Sequence=1}));if(!Json.Read<Reply>(Wire.Read(stream,Wire.MaxReply)).Ok)throw new Exception("chat failed");
   Wire.Write(stream,Json.Write(new Command{Op="state"}));if(Json.Read<Reply>(Wire.Read(stream,Wire.MaxReply)).State.Chat.Count!=1)throw new Exception("state failed");
  }}catch(Exception e){error=e;}finally{done=true;}});worker.Start();var timer=System.Diagnostics.Stopwatch.StartNew();while(!done&&timer.ElapsedMilliseconds<6000){server.Pump(s,0,32);Thread.Sleep(5);}worker.Join(1000);if(error!=null)Console.WriteLine(error);Check(done&&error==null,"real TCP handshake, command and state");
 }
 using(var ms=new MemoryStream(new byte[]{127,255,255,255})){bool rejected=false;try{Wire.Read(ms,8192);}catch(IOException){rejected=true;}Check(rejected,"oversized frame rejected before allocation");}
 }
}

