using System;
using System.IO;
using System.Reflection;
using System.Collections.Generic;
using AstraCoop;
using MelonLoader;
using UnityEngine;
[assembly:MelonInfo(typeof(RuntimeProbe),"Astra runtime verification","1.0","Tests")]
[assembly:MelonGame("DefaultCompany","SKYHILL")]
public class RuntimeProbe:MelonMod {
 float next;bool initialized;string root;int step;long serial;
 static string PoseHash(SkeletonAnimation skeleton){var values=new List<float>();foreach(var bone in skeleton.skeleton.Bones){values.Add(bone.WorldX);values.Add(bone.WorldY);values.Add(bone.WorldRotation);}return Session.Hash(Json.Write(values));}
 BindingFlags flags=BindingFlags.NonPublic|BindingFlags.Instance;
 public override void OnApplicationStart(){root=Environment.CurrentDirectory;}
 public override void OnUpdate(){
  if(File.Exists(Path.Combine(root,"probe-stop"))){Application.Quit();return;}
  if(Time.realtimeSinceStartup<next)return;next=Time.realtimeSinceStartup+0.1f;
  try{
   var mod=(Mod)typeof(Mod).GetField("instance",BindingFlags.NonPublic|BindingFlags.Static).GetValue(null);if(mod==null)return;
   var session=(Session)typeof(Mod).GetField("session",flags).GetValue(mod);
   if(!initialized&&session!=null&&Mod.Active){initialized=true;File.WriteAllText(Path.Combine(root,"probe-ready.json"),Json.Write(session.World));LoggerInstance.Msg("PROBE READY");}
   string input=Path.Combine(root,"probe-command.json");if(!File.Exists(input))return;string request=File.ReadAllText(input);File.Delete(input);var c=Json.Read<Command>(request);var bridge=(NativeBridge)typeof(Mod).GetField("bridge",flags).GetValue(mod);object result=null;
   if(c.Op=="enemycheck"){
    var objects=(Dictionary<string,BaseInteractiveComponent>)typeof(NativeBridge).GetField("objects",flags).GetValue(bridge);var checkedTypes=new HashSet<string>();var report=new Dictionary<string,string>();
    foreach(var pair in objects){var enemy=pair.Value as BaseEnemy;if(enemy==null||!checkedTypes.Add(enemy.name))continue;
     for(Transform t=enemy.transform;t!=null&&t.name!="Level";t=t.parent)t.gameObject.SetActive(true);
     var visual=new MultiplayerEnemy(enemy);var state=new Enemy{Id=pair.Key,Health=100};visual.Sync(state);var skeleton=enemy.GetComponent<EnemyAnimsAssistant>().mainAnimation.getSkeletonAnimation();skeleton.timeScale=0;
     visual.Advance(0.25f);if(skeleton.state.GetCurrent(0)==null||skeleton.state.GetCurrent(0).Time<=0)throw new Exception(enemy.name+" idle frozen");
     visual.Present(new GameEvent{Id=1,Kind="enemy_attack"},state);visual.Advance(0.15f);if(skeleton.state.GetCurrent(0).Time<=0||visual.AnimationName=="idle")throw new Exception(enemy.name+" hit frozen");string hit=visual.AnimationName;
     visual.Advance(20);if(visual.AnimationName!="idle")throw new Exception(enemy.name+" no return to idle");
     visual.Present(new GameEvent{Id=2,Kind="attack_hit"},state);visual.Advance(0.1f);string hurt=visual.AnimationName;visual.Advance(20);
     state.Health=0;visual.Sync(state);visual.Advance(0.1f);string death=visual.AnimationName;visual.Advance(20);if(!visual.IsCorpse)throw new Exception(enemy.name+" no corpse");float time=visual.AnimationTime;visual.Advance(3);if(visual.AnimationTime!=time)throw new Exception(enemy.name+" corpse restarts");
     skeleton.Reset();visual.Advance(0.1f);if(skeleton.state.GetCurrent(0)==null||skeleton.state.GetCurrent(0).Animation.Name!=visual.AnimationName)throw new Exception(enemy.name+" corpse reset on hover");
     string corpse=visual.AnimationName;var joined=new MultiplayerEnemy(enemy);joined.Sync(state);if(!joined.IsCorpse||joined.AnimationName=="idle")throw new Exception(enemy.name+" late join standing");
     report[enemy.name]="idle > "+hit+" > idle > "+hurt+" > idle > "+death+" > "+corpse+"; paused clock restored; corpse stable; late join corpse";
    }
    result=report;File.WriteAllText(Path.Combine(root,"enemy-check.json"),Json.Write(report));
   }
   if(c.Op=="enemyread"){
    var objects=(Dictionary<string,BaseInteractiveComponent>)typeof(NativeBridge).GetField("objects",flags).GetValue(bridge);var enemy=(BaseEnemy)objects[c.Target];var skeleton=enemy.GetComponent<EnemyAnimsAssistant>().mainAnimation.getSkeletonAnimation();var track=skeleton.state.GetCurrent(0);result=new Dictionary<string,string>{{"pose",PoseHash(skeleton)},{"active",enemy.gameObject.activeInHierarchy.ToString()},{"self",enemy.gameObject.activeSelf.ToString()},{"delta",Time.deltaTime.ToString()},{"scale",skeleton.timeScale.ToString()},{"global",Time.timeScale.ToString()},{"clip",track==null?"none":track.Animation.Name},{"time",track==null?"0":track.Time.ToString(System.Globalization.CultureInfo.InvariantCulture)}};
   }
   if(c.Op=="enemyevent"){
    var enemy=session.World.Enemies[c.Target];if(c.Text=="enemy_death")enemy.Health=0;session.World.Events.Add(new GameEvent{Id=++session.World.EventSequence,ActorId=c.Text=="enemy_attack"?enemy.Id:null,TargetId=enemy.Id,Kind=c.Text});session.World.Revision++;result="ok";
   }
   if(c.Op=="lootcheck"){
    var welcome=session.Join(new Command{Name="Loot QA",Role="player"},false);var actor=session.World.Actors[welcome.ActorId];var counts=new Dictionary<string,int>();int searched=0;
    foreach(Enemy e in session.World.Enemies.Values)e.Health=0;
    foreach(var box in session.World.Containers.Values){if(box.Used||!box.NativeLoot)continue;actor.Room=box.Room;var reply=session.Execute(welcome.MemberId,new Command{Op="interact",Target=box.Id,Sequence=session.Members[welcome.MemberId].LastSequence+1},session.World.ServerTime);if(!reply.Ok)throw new Exception(reply.Code);searched++;foreach(var pair in box.Loot){string type=session.World.Items[pair.Key].Type;int count;counts.TryGetValue(type,out count);counts[type]=count+pair.Value;}if(searched>=150)break;}
File.WriteAllText(Path.Combine(root,"loot-native.json"),Json.Write(counts));result=counts;
   }
   if(c.Op=="dump")result=session.World;
   if(c.Op=="set"){var actor=session.World.Actors[c.Target];actor.Room=c.Text;session.World.Rooms[c.Text].Known=true;actor.TravelKind="lift";actor.MovingUntil=0;actor.NextMove=0;actor.Health=actor.MaxHealth=100000;actor.Food=actor.MaxFood=100000;session.World.Revision++;result=actor;}
   if(c.Op=="grant"){session.World.Inventory[c.Target]=c.Zone;session.World.Revision++;result="ok";}
   if(c.Op=="reveal"){foreach(Room r in session.World.Rooms.Values)r.Known=true;session.World.Revision++;result=session.View();}
   if(c.Op=="open"){
    var field=typeof(NativeBridge).GetField("objects",flags);var objects=(Dictionary<string,BaseInteractiveComponent>)field.GetValue(bridge);var id=(string)typeof(Mod).GetField("actorId",flags).GetValue(mod);var actor=session.World.Actors[id];
    result=bridge.OpenInteractive(objects[c.Target],session.View(),actor);
   }
   if(c.Op=="hostplayer"){
    var welcome=session.Join(new Command{Name="Native host",Role="player"},false);typeof(Mod).GetField("actorId",flags).SetValue(mod,welcome.ActorId);typeof(Mod).GetField("memberId",flags).SetValue(mod,welcome.MemberId);typeof(Mod).GetField("follow",flags).SetValue(mod,welcome.ActorId);typeof(Mod).GetField("sequence",flags).SetValue(mod,welcome.NextSequence);result=welcome;
   }
   if(c.Op=="close"){NotificationCenter.getI.postNotification("closeQuest",null);result="closed";}
   if(c.Op=="shot"){Application.CaptureScreenshot(Path.Combine(root,c.Text));result="ok";}
   if(c.Op=="click"){
    var objects=(Dictionary<string,BaseInteractiveComponent>)typeof(NativeBridge).GetField("objects",flags).GetValue(bridge);objects[c.Target].action();result="ok";
   }
   if(c.Op=="accept"){var all=Resources.FindObjectsOfTypeAll(typeof(SpecialQuest_ChangeMan));foreach(SpecialQuest_ChangeMan q in all)if(q.gameObject.activeInHierarchy){typeof(SpecialQuest_ChangeMan).GetMethod("accept",flags).Invoke(q,null);result="accepted";break;}}
   if(c.Op=="password"){foreach(SpecialQuest_LastPC q in Resources.FindObjectsOfTypeAll(typeof(SpecialQuest_LastPC)))if(q.gameObject.activeInHierarchy){typeof(SpecialQuest_LastPC).GetField("answer",flags).SetValue(q,c.Text);typeof(SpecialQuest_LastPC).GetMethod("answered",flags).Invoke(q,null);result="entered";break;}}
   if(c.Op=="save"){Persistence.Save(session,Path.Combine(root,"probe-save.json"),session.World.ServerTime);result="saved";}
   File.WriteAllText(Path.Combine(root,"probe-result.json"),Json.Write(result));
  }catch(Exception e){LoggerInstance.Error(e.ToString());File.WriteAllText(Path.Combine(root,"probe-result.json"),Json.Write(e.ToString()));}
 }
}
