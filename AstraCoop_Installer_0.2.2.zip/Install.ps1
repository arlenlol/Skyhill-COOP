[CmdletBinding()]
param([string]$GamePath)
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
try {
 if(-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  $argsList='-NoProfile -ExecutionPolicy Bypass -File "'+$PSCommandPath+'"'
  if($GamePath){$argsList+=' -GamePath "'+$GamePath.Replace('"','')+'"'}
  $elevated=Start-Process powershell.exe -Verb RunAs -ArgumentList $argsList -Wait -PassThru
  exit $elevated.ExitCode
 }
 [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
 if(-not $GamePath){
  $candidates=@((Join-Path $root 'Skyhill'),(Join-Path ${env:ProgramFiles(x86)} 'Steam\steamapps\common\Skyhill'))
  $steam=(Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction SilentlyContinue).SteamPath
  if($steam){$candidates+=Join-Path $steam 'steamapps\common\Skyhill';$vdf=Join-Path $steam 'steamapps\libraryfolders.vdf';if(Test-Path $vdf){foreach($m in [regex]::Matches((Get-Content $vdf -Raw),'"path"\s+"([^"]+)"')){$candidates+=Join-Path ($m.Groups[1].Value.Replace('\\','\')) 'steamapps\common\Skyhill'}}}
  $GamePath=$candidates|Where-Object {Test-Path (Join-Path $_ 'Skyhill.exe')}|Select-Object -First 1
 }
 if(-not $GamePath){Add-Type -AssemblyName System.Windows.Forms;$dialog=New-Object Windows.Forms.OpenFileDialog;$dialog.Title='Select Skyhill.exe';$dialog.Filter='SKYHILL|Skyhill.exe';if($dialog.ShowDialog() -ne 'OK'){throw 'Game selection cancelled'};$GamePath=Split-Path $dialog.FileName}
 $GamePath=(Resolve-Path -LiteralPath $GamePath).Path
 if(-not (Test-Path (Join-Path $GamePath 'Skyhill.exe')) -or -not (Test-Path (Join-Path $GamePath 'Skyhill_Data\Managed\Assembly-CSharp.dll'))){throw 'Select the original Mono SKYHILL installation.'}
 if(Get-Process Skyhill -ErrorAction SilentlyContinue){throw 'Close SKYHILL before installing.'}
 $cache=Join-Path $root 'downloads';New-Item -ItemType Directory -Force $cache|Out-Null
 function Fetch($url,$file){Write-Host "Downloading $url";Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $file}
 $base='https://github.com/LavaGang/MelonLoader/releases/download/v0.5.7/'
 $zip=Join-Path $cache 'MelonLoader.x86.zip';$sum=Join-Path $cache 'MelonLoader.x86.sha512'
 Fetch ($base+'MelonLoader.x86.zip') $zip;Fetch ($base+'MelonLoader.x86.sha512') $sum
 $expected=[regex]::Match((Get-Content $sum -Raw),'(?i)[a-f0-9]{128}').Value
 if(-not $expected -or (Get-FileHash $zip -Algorithm SHA512).Hash -ne $expected){throw 'MelonLoader checksum mismatch'}
 $manifest=Get-Content (Join-Path $root 'mod-sha256.json') -Raw|ConvertFrom-Json
 foreach($name in @('AstraCoop.dll','AstraCoop.Core.dll')){if((Get-FileHash (Join-Path $root "Mods\$name") -Algorithm SHA256).Hash -ne $manifest.$name){throw "Damaged mod: $name"}}
 $backup=Join-Path $GamePath ('AstraCoop-Backups\'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'));New-Item -ItemType Directory -Force $backup|Out-Null
 foreach($name in @('MelonLoader','version.dll','dobby.dll','Mods\AstraCoop.dll','Mods\AstraCoop.Core.dll')){$old=Join-Path $GamePath $name;if(Test-Path -LiteralPath $old){$dest=Join-Path $backup $name;New-Item -ItemType Directory -Force (Split-Path $dest)|Out-Null;Copy-Item -LiteralPath $old -Destination $dest -Recurse}}
 Expand-Archive -LiteralPath $zip -DestinationPath $GamePath -Force
 New-Item -ItemType Directory -Force (Join-Path $GamePath 'Mods')|Out-Null
 Copy-Item -LiteralPath (Join-Path $root 'Mods\AstraCoop.dll'),(Join-Path $root 'Mods\AstraCoop.Core.dll') -Destination (Join-Path $GamePath 'Mods') -Force
 $installed=$false
 foreach($key in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*','HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*')){if(Get-ItemProperty $key -ErrorAction SilentlyContinue|Where-Object {$_.DisplayName -match 'Radmin VPN'}){$installed=$true}}
 foreach($basePath in @(${env:ProgramFiles(x86)},$env:ProgramFiles)){if($basePath -and (Test-Path (Join-Path $basePath 'Radmin VPN\RvRvpnGui.exe'))){$installed=$true}}
 if(Get-Service -Name RvControlSvc -ErrorAction SilentlyContinue){$installed=$true}
 if($installed){Write-Host 'Radmin VPN already installed; skipping download.'}else{
  $page=Invoke-WebRequest -UseBasicParsing 'https://www.radmin-vpn.com/ru/'
  $url=[regex]::Match($page.Content,'https://download\.radmin-vpn\.com/download/files/[^"<>\s]+\.exe').Value
  if(-not $url){throw 'Official Radmin download link not found.'}
  $installer=Join-Path $cache 'RadminVPN.exe';Fetch $url $installer
  $signature=Get-AuthenticodeSignature -LiteralPath $installer
  if($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'Famatech'){throw 'Radmin publisher signature could not be verified.'}
  Write-Host 'Complete the official Radmin VPN setup window.'
  $p=Start-Process -FilePath $installer -Wait -PassThru
  if($p.ExitCode -notin @(0,3010)){throw "Radmin setup failed or cancelled: $($p.ExitCode)"}
 }
 Write-Host "READY. Start Skyhill.exe from: $GamePath" -ForegroundColor Green
 Write-Host "Backups: $backup"
 Write-Host 'Join the same Radmin VPN network with your friends, then open F9 in SKYHILL.'
 Read-Host 'Press Enter to close';exit 0
}catch{Write-Host $_.Exception.Message -ForegroundColor Red;Read-Host 'Installation stopped. Press Enter to close';exit 1}
